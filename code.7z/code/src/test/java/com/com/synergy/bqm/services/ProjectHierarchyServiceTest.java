package com.com.synergy.bqm.services;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.Rollback;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.synergy.bqm.constants.HierarchyType;
import com.synergy.bqm.models.ProjectHierarchy;
import com.synergy.bqm.services.ProjectHierarchyService;
import com.synergy.bqm.services.ProjectService;

@EnableTransactionManagement
@Rollback(false)
public class ProjectHierarchyServiceTest extends BaseServiceTest {

	@Autowired
	ProjectHierarchyService projectHierarchyService;

	@Autowired
	ProjectService projectService;

	@Test
	public void create() {
		ProjectHierarchy projectHierarchyLevel1 = buildProjectHierarchyLevel1();
		try {
			projectHierarchyService.createProjectHierarchy(projectHierarchyLevel1);

			ProjectHierarchy projectHierarchyLevel2_1 = buildProjectHierarchyLevel2_1();
			projectHierarchyService.createProjectHierarchy(projectHierarchyLevel2_1);

			ProjectHierarchy projectHierarchyLevel2_2 = buildProjectHierarchyLevel2_2();
			projectHierarchyService.createProjectHierarchy(projectHierarchyLevel2_2);

			ProjectHierarchy projectHierarchyLevel2_3 = buildProjectHierarchyLevel2_3();
			projectHierarchyService.createProjectHierarchy(projectHierarchyLevel2_3);

			ProjectHierarchy projectHierarchyLevel3_1_1 = buildProjectHierarchyLevel3_1_1();
			projectHierarchyService.createProjectHierarchy(projectHierarchyLevel3_1_1);

			ProjectHierarchy projectHierarchyLevel3_1_2 = buildProjectHierarchyLevel3_1_2();
			projectHierarchyService.createProjectHierarchy(projectHierarchyLevel3_1_2);

			ProjectHierarchy projectHierarchyLevel3_1_3 = buildProjectHierarchyLevel3_1_3();
			projectHierarchyService.createProjectHierarchy(projectHierarchyLevel3_1_3);

			ProjectHierarchy projectHierarchyLevel3_1_4 = buildProjectHierarchyLevel3_1_4();
			projectHierarchyService.createProjectHierarchy(projectHierarchyLevel3_1_4);

			ProjectHierarchy projectHierarchyLevel3_2_1 = buildProjectHierarchyLevel3_2_1();
			projectHierarchyService.createProjectHierarchy(projectHierarchyLevel3_2_1);

			ProjectHierarchy projectHierarchyLevel3_2_2 = buildProjectHierarchyLevel3_2_2();
			projectHierarchyService.createProjectHierarchy(projectHierarchyLevel3_2_2);

			ProjectHierarchy projectHierarchyLevel3_2_3 = buildProjectHierarchyLevel3_2_3();
			projectHierarchyService.createProjectHierarchy(projectHierarchyLevel3_2_3);

			ProjectHierarchy projectHierarchyLevel3_2_4 = buildProjectHierarchyLevel3_2_4();
			projectHierarchyService.createProjectHierarchy(projectHierarchyLevel3_2_4);
		} catch (Exception e) {
			System.out.println("exception");
		}

	}

	private ProjectHierarchy buildProjectHierarchyLevel1() {

		ProjectHierarchy projectHierarchy = new ProjectHierarchy();
		projectHierarchy.setProject(projectService.getProjectByProjectId(1));
		projectHierarchy.setHierarchyName("TOWER-1");
		projectHierarchy.setHierarchyType(HierarchyType.TOWER.toString());
		projectHierarchy.setProjectHierarchyId(1);

		return projectHierarchy;
	}

	private ProjectHierarchy buildProjectHierarchyLevel2_1() {
		ProjectHierarchy projectHierarchy = new ProjectHierarchy();
		projectHierarchy.setProject(projectService.getProjectByProjectId(1));
		projectHierarchy.setHierarchyName("GF");
		projectHierarchy.setHierarchyType(HierarchyType.FLOOR.toString());
		projectHierarchy.setProjectHierarchyId(2);
		projectHierarchy.setProjectHierarchy(projectHierarchyService.getProjectHierarchyByHierarchyId(1));

		return projectHierarchy;
	}

	private ProjectHierarchy buildProjectHierarchyLevel2_2() {
		ProjectHierarchy projectHierarchy = new ProjectHierarchy();
		projectHierarchy.setProject(projectService.getProjectByProjectId(1));
		projectHierarchy.setHierarchyName("FF");
		projectHierarchy.setHierarchyType(HierarchyType.FLOOR.toString());
		projectHierarchy.setProjectHierarchyId(3);
		projectHierarchy.setProjectHierarchy(projectHierarchyService.getProjectHierarchyByHierarchyId(1));

		return projectHierarchy;
	}

	private ProjectHierarchy buildProjectHierarchyLevel2_3() {
		ProjectHierarchy projectHierarchy = new ProjectHierarchy();
		projectHierarchy.setProject(projectService.getProjectByProjectId(1));
		projectHierarchy.setHierarchyName("SF");
		projectHierarchy.setHierarchyType(HierarchyType.FLOOR.toString());
		projectHierarchy.setProjectHierarchyId(4);
		projectHierarchy.setProjectHierarchy(projectHierarchyService.getProjectHierarchyByHierarchyId(1));

		return projectHierarchy;
	}

	private ProjectHierarchy buildProjectHierarchyLevel3_1_1() {
		ProjectHierarchy projectHierarchy = new ProjectHierarchy();
		projectHierarchy.setProject(projectService.getProjectByProjectId(1));
		projectHierarchy.setHierarchyName("GF-1");
		projectHierarchy.setHierarchyType(HierarchyType.UNIT.toString());
		projectHierarchy.setProjectHierarchyId(5);
		projectHierarchy.setProjectHierarchy(projectHierarchyService.getProjectHierarchyByHierarchyId(2));

		return projectHierarchy;
	}

	private ProjectHierarchy buildProjectHierarchyLevel3_1_2() {
		ProjectHierarchy projectHierarchy = new ProjectHierarchy();
		projectHierarchy.setProject(projectService.getProjectByProjectId(1));
		projectHierarchy.setHierarchyName("GF-2");
		projectHierarchy.setHierarchyType(HierarchyType.UNIT.toString());
		projectHierarchy.setProjectHierarchyId(6);
		projectHierarchy.setProjectHierarchy(projectHierarchyService.getProjectHierarchyByHierarchyId(2));

		return projectHierarchy;
	}

	private ProjectHierarchy buildProjectHierarchyLevel3_1_3() {
		ProjectHierarchy projectHierarchy = new ProjectHierarchy();
		projectHierarchy.setProject(projectService.getProjectByProjectId(1));
		projectHierarchy.setHierarchyName("GF-3");
		projectHierarchy.setHierarchyType(HierarchyType.UNIT.toString());
		projectHierarchy.setProjectHierarchyId(7);
		projectHierarchy.setProjectHierarchy(projectHierarchyService.getProjectHierarchyByHierarchyId(2));

		return projectHierarchy;
	}

	private ProjectHierarchy buildProjectHierarchyLevel3_1_4() {
		ProjectHierarchy projectHierarchy = new ProjectHierarchy();
		projectHierarchy.setProject(projectService.getProjectByProjectId(1));
		projectHierarchy.setHierarchyName("GF-4");
		projectHierarchy.setHierarchyType(HierarchyType.UNIT.toString());
		projectHierarchy.setProjectHierarchyId(8);
		projectHierarchy.setProjectHierarchy(projectHierarchyService.getProjectHierarchyByHierarchyId(2));

		return projectHierarchy;
	}

	private ProjectHierarchy buildProjectHierarchyLevel3_2_1() {
		ProjectHierarchy projectHierarchy = new ProjectHierarchy();
		projectHierarchy.setProject(projectService.getProjectByProjectId(1));
		projectHierarchy.setHierarchyName("FF-1");
		projectHierarchy.setHierarchyType(HierarchyType.UNIT.toString());
		projectHierarchy.setProjectHierarchyId(9);
		projectHierarchy.setProjectHierarchy(projectHierarchyService.getProjectHierarchyByHierarchyId(3));

		return projectHierarchy;
	}

	private ProjectHierarchy buildProjectHierarchyLevel3_2_2() {
		ProjectHierarchy projectHierarchy = new ProjectHierarchy();
		projectHierarchy.setProject(projectService.getProjectByProjectId(1));
		projectHierarchy.setHierarchyName("FF-2");
		projectHierarchy.setHierarchyType(HierarchyType.UNIT.toString());
		projectHierarchy.setProjectHierarchyId(10);
		projectHierarchy.setProjectHierarchy(projectHierarchyService.getProjectHierarchyByHierarchyId(3));

		return projectHierarchy;
	}

	private ProjectHierarchy buildProjectHierarchyLevel3_2_3() {
		ProjectHierarchy projectHierarchy = new ProjectHierarchy();
		projectHierarchy.setProject(projectService.getProjectByProjectId(1));
		projectHierarchy.setHierarchyName("FF-3");
		projectHierarchy.setHierarchyType(HierarchyType.UNIT.toString());
		projectHierarchy.setProjectHierarchyId(11);
		projectHierarchy.setProjectHierarchy(projectHierarchyService.getProjectHierarchyByHierarchyId(3));

		return projectHierarchy;
	}

	private ProjectHierarchy buildProjectHierarchyLevel3_2_4() {
		ProjectHierarchy projectHierarchy = new ProjectHierarchy();
		projectHierarchy.setProject(projectService.getProjectByProjectId(1));
		projectHierarchy.setHierarchyName("FF-4");
		projectHierarchy.setHierarchyType(HierarchyType.UNIT.toString());
		projectHierarchy.setProjectHierarchyId(12);
		projectHierarchy.setProjectHierarchy(projectHierarchyService.getProjectHierarchyByHierarchyId(3));

		return projectHierarchy;
	}

}
