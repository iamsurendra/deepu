package com.com.synergy.bqm.mongoDAO;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.synergy.bqm.documents.ChecklistTemplate;
import com.synergy.bqm.documents.InfoQuestionTypeTemplate;
import com.synergy.bqm.documents.SectionTemplate;
import com.synergy.bqm.documents.SelectionQuestionTypeTemplate;
import com.synergy.bqm.documents.SubsectionTemplate;
import com.synergy.bqm.documents.TextQuestionTypeTemplate;
import com.synergy.bqm.mongoRepositories.CheckListTemplateRepository;

public class CheckListRepositoryTest extends MongoRepositoryTest {

	@Autowired
	CheckListTemplateRepository checkListRepository;

	@Test
	public void testSaveCheckList() {

		ChecklistTemplate checklist = new ChecklistTemplate();
		checklist.setChecklistName("Execution  Check list for Plumbing & Sanitary Works type");
		checklist.setChecklistType("Plumbing");

		SectionTemplate firstSection = new SectionTemplate();
		firstSection.setSectionName("Sanitary Fixtures & CP Fittings");
	/*firstSection.setSectionDescription(
				"Ensure Fixture/Fitting installation ,testing ,  terminations of the water supply & sanitary connections");*/

		SubsectionTemplate firstSubsection = new SubsectionTemplate();
		firstSubsection.setSubsectionName("European Water Closet ");
		firstSection.getSubsectionList().add(firstSubsection);

		SubsectionTemplate secondSubsection = new SubsectionTemplate();
		secondSubsection.setSubsectionName("Wash Basin");
		firstSection.getSubsectionList().add(secondSubsection);

		List<String> yesOrNoOrNAOptionList = new ArrayList<String>();
		yesOrNoOrNAOptionList.add("YES");
		yesOrNoOrNAOptionList.add("NO");
		yesOrNoOrNAOptionList.add("N/A");

		String yesOrNoOrNAOption = "yesOrNoOrNAOption";
		SelectionQuestionTypeTemplate firstLineItem_subsection1 = new SelectionQuestionTypeTemplate();
		firstLineItem_subsection1.setLineItemQuestion("Check for Cistern Tank  & Flush Valve");
		firstLineItem_subsection1.setOptionType(yesOrNoOrNAOption);
		firstLineItem_subsection1.getQuestionOptions().addAll(yesOrNoOrNAOptionList);
		firstSubsection.getQuestionList().add(firstLineItem_subsection1);

		SelectionQuestionTypeTemplate secondLineItem_subsection1 = new SelectionQuestionTypeTemplate();
		secondLineItem_subsection1.setLineItemQuestion("Check for 110mm dia. Soil piping");
		secondLineItem_subsection1.setOptionType(yesOrNoOrNAOption);
		secondLineItem_subsection1.getQuestionOptions().addAll(yesOrNoOrNAOptionList);
		firstSubsection.getQuestionList().add(secondLineItem_subsection1);

		SelectionQuestionTypeTemplate firstLineItem_subsection2 = new SelectionQuestionTypeTemplate();
		firstLineItem_subsection2.setLineItemQuestion("Check for Pillar Cock/Basin Mixer");
		firstLineItem_subsection2.setOptionType(yesOrNoOrNAOption);
		firstLineItem_subsection2.getQuestionOptions().addAll(yesOrNoOrNAOptionList);
		secondSubsection.getQuestionList().add(firstLineItem_subsection2);

		SelectionQuestionTypeTemplate secondLineItem_subsection2 = new SelectionQuestionTypeTemplate();
		secondLineItem_subsection2.setLineItemQuestion("Check for Waste Pipe & Bottle Trap Connections");
		secondLineItem_subsection2.setOptionType(yesOrNoOrNAOption);
		secondLineItem_subsection2.getQuestionOptions().addAll(yesOrNoOrNAOptionList);
		secondSubsection.getQuestionList().add(secondLineItem_subsection2);

		SectionTemplate secondSection = new SectionTemplate();
		secondSection.setSectionName("Water Supply System ");
		//secondSection.setSectionDescription("Ensure water supply connections , pressure testing");

		SubsectionTemplate firstSubsection2 = new SubsectionTemplate();
		firstSubsection2.setSubsectionName("European Water Closet ");
		secondSection.getSubsectionList().add(firstSubsection);

		TextQuestionTypeTemplate firstLineItem_section2_subsection1 = new TextQuestionTypeTemplate();
		firstLineItem_section2_subsection1.setLineItemQuestion("Note Pressure Testing for concelaed pipes");
		firstLineItem_section2_subsection1.setUpperLimit("100");
		firstLineItem_section2_subsection1.setLowerLimit("10");
		firstSubsection2.getQuestionList().add(firstLineItem_section2_subsection1);

		InfoQuestionTypeTemplate firstSection_Question1 = new InfoQuestionTypeTemplate();
		firstSection_Question1.setLineItemQuestion("Enter Equipment Number");
		firstSection_Question1.setLineItemToolTip("equipment number is on the pipe of the basin");
		firstSection.getQuestionList().add(firstSection_Question1);

		InfoQuestionTypeTemplate firstSection_Question2 = new InfoQuestionTypeTemplate();
		firstSection_Question2.setLineItemQuestion("Enter Equipment Manufacturer");
		secondSection.getQuestionList().add(firstSection_Question2);

		checklist.getSectionList().add(firstSection);
		checklist.getSectionList().add(secondSection);
		checkListRepository.save(checklist);
	}

}
