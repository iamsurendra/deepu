/**
 * 
 */
package com.com.synergy.bqm.services;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.Rollback;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.synergy.bqm.models.Project;
import com.synergy.bqm.services.ProjectService;

/**
 * @author karthik
 *
 */
@EnableTransactionManagement
@Rollback(false)
public class ProjectServiceTest extends BaseServiceTest {

	
	@Autowired
	ProjectService projectService;
	
	
	@Test
	public void create() {
		Project project = buildProject();
		projectService.createProject(project);

	}

	
	private Project buildProject()
	{
		Project project = new Project();
		project.setProjectId(2);
		project.setProjectName("PRESTIGE");
		project.setProjectManager(1);
		project.setProjectClient(1);
		
		return project;
	}
}
