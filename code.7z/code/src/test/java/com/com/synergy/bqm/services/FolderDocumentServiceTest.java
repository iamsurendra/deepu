package com.com.synergy.bqm.services;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.Rollback;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.synergy.bqm.models.FolderDocument;
import com.synergy.bqm.services.FolderDocumentService;
import com.synergy.bqm.services.FolderService;
@EnableTransactionManagement
@Rollback(false)
public class FolderDocumentServiceTest  extends BaseServiceTest{

	@Autowired
	FolderService folderService;
	
	@Autowired
	FolderDocumentService folderDocumentService;
	
	
	@Test
	public void create() {
		FolderDocument folderDocument = buildFolderDocument();
	//	folderDocumentService.createFolderDocumenty(folderDocument);

	}
	
	private FolderDocument buildFolderDocument()
	{
		FolderDocument folderDocument = new FolderDocument();
		folderDocument.setDocumentId(1);
		folderDocument.setFolder(folderService.getFolderByFolderId(1));
		folderDocument.setDocumentLink("c:\\desktop");
		folderDocument.setDocumentName("design");
		
		return folderDocument;
		
	}

}
