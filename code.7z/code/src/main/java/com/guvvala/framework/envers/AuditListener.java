
package com.guvvala.framework.envers;

import org.hibernate.envers.RevisionListener;

import com.guvvala.framework.util.ThreadLocalUtil;
import com.synergy.bqm.models.RevisionHistory;

/**
 * 
 * @author Guvala
 *
 */
public class AuditListener implements RevisionListener {
	public void newRevision(Object revisionEntity) {
		RevisionHistory revisionHistory = (RevisionHistory) revisionEntity;
		//TODO need to fetch user name
		revisionHistory.setUserId(ThreadLocalUtil.getUserName());
	}
}
