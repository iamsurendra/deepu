package com.guvvala.framework.util;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import com.guvvala.framework.logging.AppLogger;
import com.guvvala.framework.logging.Log;

public class ControllerInterceptors extends HandlerInterceptorAdapter {

	private static @Log AppLogger logger;

	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
			throws Exception {
		if (handler instanceof HandlerMethod) {
			AppUser principal = (AppUser) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
			AppWebUtils.loadThreadLocalUtils(principal);
		}
		return true;
	}

}