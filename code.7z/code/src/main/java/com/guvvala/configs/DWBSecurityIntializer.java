package com.guvvala.configs;

import org.springframework.security.web.context.AbstractSecurityWebApplicationInitializer;

public class DWBSecurityIntializer extends AbstractSecurityWebApplicationInitializer {

}
