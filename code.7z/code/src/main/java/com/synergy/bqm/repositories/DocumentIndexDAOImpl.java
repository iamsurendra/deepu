package com.synergy.bqm.repositories;

import java.util.List;

import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.guvvala.framework.dao.BaseDAOImpl;
import com.synergy.bqm.models.DocumentIndex;

@Repository
public class DocumentIndexDAOImpl extends BaseDAOImpl<DocumentIndex, Integer> implements DocumentIndexDAO {

	public DocumentIndexDAOImpl() {
		super(DocumentIndex.class);
		// TODO Auto-generated constructor stub
	}

	public List<DocumentIndex> getDocumentIndexListByProjectId(Integer projectId) {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<DocumentIndex> criteriaQuery = criteriaBuilder.createQuery(DocumentIndex.class);
		Root<DocumentIndex> root = criteriaQuery.from(DocumentIndex.class);
		criteriaQuery.select(root).where(criteriaBuilder.equal(root.get("projectId"), projectId));
		return entityManager.createQuery(criteriaQuery).getResultList();
	}

	public List<DocumentIndex> getDocumentIndexListByProjectIdDocumentPathNull(Integer projectId) {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<DocumentIndex> criteriaQuery = criteriaBuilder.createQuery(DocumentIndex.class);
		Root<DocumentIndex> root = criteriaQuery.from(DocumentIndex.class);
		criteriaQuery.select(root).where(criteriaBuilder.equal(root.get("projectId"), projectId),
				criteriaBuilder.isNull(root.get("documentPath")));
		return entityManager.createQuery(criteriaQuery).getResultList();
	}

	public DocumentIndex getDocumentIndexByDocumentId(Integer documentId) {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<DocumentIndex> criteriaQuery = criteriaBuilder.createQuery(DocumentIndex.class);
		Root<DocumentIndex> root = criteriaQuery.from(DocumentIndex.class);
		criteriaQuery.select(root).where(criteriaBuilder.equal(root.get("documentId"), documentId));
		List<DocumentIndex> documentIndexs = entityManager.createQuery(criteriaQuery).getResultList();
		if (!documentIndexs.isEmpty()) {
			return documentIndexs.get(0);
		} else {
			return null;

		}
	}

	public List<DocumentIndex> getDocumentIndexByActivityId(Integer activityId) {
		CriteriaBuilder builder = entityManager.getCriteriaBuilder();
		CriteriaQuery<DocumentIndex> criteriaQuery = builder.createQuery(DocumentIndex.class);
		Root<DocumentIndex> root = criteriaQuery.from(DocumentIndex.class);
		criteriaQuery.select(builder.construct(DocumentIndex.class, root.get("id"), root.get("name")));
		criteriaQuery.where(root.get("activityType").in(activityId));
		return entityManager.createQuery(criteriaQuery).getResultList();
	}

	public Boolean checkDuplicateActivity(String name, Integer departmentId, Integer activitytype) {
		TypedQuery<Long> query = entityManager.createQuery("SELECT count (e) from DocumentIndex e where name='" + name
				+ "' and departmentId='" + departmentId + "' and activityType='" + activitytype + "'", Long.class);
		if (query.getSingleResult() == 0) {

			return false;
		} else {

			return true;
		}
	}

}
