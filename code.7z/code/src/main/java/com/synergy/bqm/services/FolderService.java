package com.synergy.bqm.services;

import java.io.IOException;
import java.util.List;
import java.util.Set;

import javax.servlet.http.HttpServletResponse;

import org.springframework.web.multipart.MultipartFile;

import com.synergy.bqm.json.FolderTreeDTO;
import com.synergy.bqm.models.Folder;
import com.synergy.bqm.models.FolderDocument;

public interface FolderService {

	Folder createFolder(Folder folder);

	Folder getFolderByFolderId(Integer folderId);

	public String getFolderName(Integer folderId);

	List<Folder> getTemplateFolders();

	public void createFoldersForProject(Integer projectId, List<FolderTreeDTO> folderTreeDTO);

	List<Folder> getFolderInfoByProjectId(Integer projectId);

	void saveFile(MultipartFile file, Integer projectId, Integer folderId, boolean editMode, String documentDescription,
			Double version, boolean falg) throws IOException;

	FolderDocument saveIndexFile(MultipartFile file, Integer projectId, Integer folderId, boolean editMode,
			String documentDescription, Double version, boolean falg) throws IOException;

	void saveMultipleFiles(List<MultipartFile> file, Integer projectId, Integer folderId, boolean editMode,
			String documentDescription, Double version) throws IOException;

	void deleteFolder(Folder folder);

	public Folder updateFolder(Folder folder);

	public void deleteDocument(List<Integer> documentIdList, Integer projectId);

	public void downloadfile(HttpServletResponse response, Integer documentIds) throws IOException;

	public Folder folderMoving(Folder folder);

	public void deleteChildFolderAndDocument(Set<Folder> set);

	public List<Folder> getFolderInfo(Integer projectId);
}
