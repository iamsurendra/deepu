package com.synergy.bqm.repositories;

import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.guvvala.framework.dao.BaseDAOImpl;
import com.synergy.bqm.models.Vendor;


@Repository
public class VendorDAOImpl extends BaseDAOImpl<Vendor, Long> implements VendorDAO {

	public VendorDAOImpl() {
		super(Vendor.class);
		// TODO Auto-generated constructor stub
	}

	
	public Vendor getVendorInfoByVendorId(Long vendorId) {
		TypedQuery<Vendor> query = entityManager
				.createQuery("SELECT f from Vendor f where vendorId ='" + vendorId + "'", Vendor.class);
		return query.getSingleResult();
	}
	
}
