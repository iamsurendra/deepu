package com.synergy.bqm.models;

import java.io.Serializable;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;

import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.PostLoad;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.guvvala.framework.model.BaseModel;
import com.guvvala.framework.util.DateUtils;

@Entity
@Table(name = "folder_template_names")
@NamedQuery(name = "FolderTemplateNames.findAll", query = "SELECT f FROM FolderTemplateNames f")

public class FolderTemplateNames extends BaseModel implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue
	@Column(name = "template_id")
	private Integer templateId;

	@Column(name = "template_name")
	private String templateName;

	@Transient
	private String createdDt;

	@Transient
	private String updatedDt;

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER, orphanRemoval = true)
	@JoinColumn(name = "template_id")
	// @JoinTable(name="folder_templates",joinColumns =
	// @JoinColumn(name="template_id"),inverseJoinColumns = @JoinColumn(name =
	// "template_id"))
	private Set<FolderTemplate> folderTemplates;

	@Transient
	private String createdUser;

	@Transient
	private String upDatedUser;

	// getters and setters

	public Integer getTemplateId() {
		return templateId;
	}

	public Set<FolderTemplate> getFolderTemplates() {
		return folderTemplates;
	}

	public void setFolderTemplates(Set<FolderTemplate> folderTemplates) {
		this.folderTemplates = folderTemplates;
	}

	public void setTemplateId(Integer templateId) {
		this.templateId = templateId;
	}

	public String getTemplateName() {
		return templateName;
	}

	public void setTemplateName(String templateName) {
		this.templateName = templateName;
	}

	public String getCreatedDt() {
		return createdDt;
	}

	public void setCreatedDt(String createdDt) {
		this.createdDt = createdDt;
	}

	public String getUpdatedDt() {
		return updatedDt;
	}

	public void setUpdatedDt(String updatedDt) {
		this.updatedDt = updatedDt;
	}

	public String getCreatedUser() {
		return createdUser;
	}

	public void setCreatedUser(String createdUser) {
		this.createdUser = createdUser;
	}

	public String getUpDatedUser() {
		return upDatedUser;
	}

	public void setUpDatedUser(String upDatedUser) {
		this.upDatedUser = upDatedUser;
	}

	@PostLoad
	void postload() {
		setCreatedDt(DateUtils.convertToSimpleDateTimeFormat(getCreatedDate()));
		setUpdatedDt(DateUtils.convertToSimpleDateTimeFormat(getUpdatedDate()));

	}
}
