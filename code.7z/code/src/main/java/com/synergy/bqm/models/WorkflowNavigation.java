package com.synergy.bqm.models;

import java.io.Serializable;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;




@Entity
@Table(name = "workflow_navigation")
public class WorkflowNavigation  implements Serializable {
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private  WorkflowNavigationKey  workflowNavigationKey;

	public WorkflowNavigationKey getWorkflowNavigationKey() {
		return workflowNavigationKey;
	}

	public void setWorkflowNavigationKey(WorkflowNavigationKey workflowNavigationKey) {
		this.workflowNavigationKey = workflowNavigationKey;
	}
   
	
	
	
	
}
