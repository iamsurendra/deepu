package com.synergy.bqm.models;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.PostLoad;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import com.guvvala.framework.util.DateUtils;
import com.synergy.bqm.json.DocumentChecklistDTO;

@Entity
@Table(name = "document_index_v")
public class DocumentIndexVw implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "id")
	private Integer id;

	@Column(name = "name")
	private String name;

	@Column(name = "percentage_of_completed")
	private Integer percentageOfCompleted;

	@Column(name = "hierarchy_Id")
	private Integer hierarchyId;

	@Column(name = "hierarchy")
	private String hierarchy;

	@Column(name = "department_Id")
	private Integer departmentId;

	@Column(name = "department")
	private String department;

	@Column(name = "project_id")
	private Integer projectId;

	@Column(name = "project")
	private String project;

	@Column(name = "activity_Id")
	private Integer activityId;

	@Column(name = "document_id")
	private Integer documentId;

	@Column(name = "activity")
	private String activityType;

	@Column(name = "reference_drawing_path")
	private String referenceDrawingPath;

	@Column(name = "drawing_no")
	private String drawingNo;

	@Column(name = "reference_drawing")
	private Integer referenceDrawing;

	@Column(name = "date_of_completion")
	@Temporal(TemporalType.TIMESTAMP)
	private Date dateOfCompletion;

	@Column(name = "dependent_activity_Id")
	private Integer dependentActivityId;

	@Column(name = "dependent_activity")
	private String dependentActivity;

	@Column(name = "workflow_Id")
	private Integer workflowId;

	@Column(name = "workflow")
	private String workflow;

	@Column(name = "state_Id")
	private Integer stateId;

	@Column(name = "workflow_state")
	private String workflowState;

	@Column(name = "current_responsible_Id")
	private Integer currentResponsibleId;

	@Column(name = "current_responsible_user")
	private String currentResponsibleUser;

	@Column(name = "document_path")
	private String documentPath;

	@Column(name = "document_name")
	private String documentName;

	@Column(name = "in_active")
	private Integer inActive;

	@Column(name = "previous_state_user")
	private String previousStateUser;

	@Column(name = "mail_Id")
	private String mailId;

	@Column(name = "phoneNumber")
	private String phoneNumber;

	@Column(name = "created_by")
	private String createdBy;

	@Column(name = "updated_by")
	private String updatedBy;

	@Column(name = "created_dt")
	private Date createdDt;

	@Column(name = "updated_dt")
	private Date updatedDt;

	@Column(name = "description")
	private String description;

	@Column(name = "activity_stage")
	private Integer activityStage;

	@Column(name = "folder_Id")
	private Integer documentFolderId;

	@Transient
	private String role;

	@Transient
	List<DocumentChecklistDTO> documentChecklistDto = new ArrayList<>();

	@Transient
	private Long indexCount;
	
	@Transient
	public String dateOfCompletionString;
	
	@Transient
	public String updatedDtString;

	public DocumentIndexVw(Long indexCount, Integer activityStage, Integer stateId, Integer workflowId) {
		this.indexCount = indexCount;
		this.activityStage = activityStage;
		this.stateId = stateId;
		this.workflowId = workflowId;
	}

	public DocumentIndexVw(Long indexCount, String department, String workflowState, Integer activityStage) {
		this.indexCount = indexCount;
		this.workflowState = workflowState;
		this.department = department;
		this.activityStage = activityStage;
	}

	public DocumentIndexVw() {

	}
	// Getters & Setters

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Integer getHierarchyId() {
		return hierarchyId;
	}

	public void setHierarchyId(Integer hierarchyId) {
		this.hierarchyId = hierarchyId;
	}

	public String getHierarchy() {
		return hierarchy;
	}

	public void setHierarchy(String hierarchy) {
		this.hierarchy = hierarchy;
	}

	public Integer getDepartmentId() {
		return departmentId;
	}

	public void setDepartmentId(Integer departmentId) {
		this.departmentId = departmentId;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public Integer getProjectId() {
		return projectId;
	}

	public void setProjectId(Integer projectId) {
		this.projectId = projectId;
	}

	public String getProject() {
		return project;
	}

	public void setProject(String project) {
		this.project = project;
	}

	public Integer getActivityId() {
		return activityId;
	}

	public void setActivityId(Integer activityId) {
		this.activityId = activityId;
	}

	public String getActivityType() {
		return activityType;
	}

	public void setActivityType(String activityType) {
		this.activityType = activityType;
	}

	public String getDrawingNo() {
		return drawingNo;
	}

	public void setDrawingNo(String drawingNo) {
		this.drawingNo = drawingNo;
	}

	public Integer getReferenceDrawing() {
		return referenceDrawing;
	}

	public void setReferenceDrawing(Integer referenceDrawing) {
		this.referenceDrawing = referenceDrawing;
	}

	public Date getDateOfCompletion() {
		return dateOfCompletion;
	}

	public void setDateOfCompletion(Date dateOfCompletion) {
		this.dateOfCompletion = dateOfCompletion;
	}

	public Integer getDependentActivityId() {
		return dependentActivityId;
	}

	public void setDependentActivityId(Integer dependentActivityId) {
		this.dependentActivityId = dependentActivityId;
	}

	public Integer getWorkflowId() {
		return workflowId;
	}

	public void setWorkflowId(Integer workflowId) {
		this.workflowId = workflowId;
	}

	public String getWorkflow() {
		return workflow;
	}

	public void setWorkflow(String workflow) {
		this.workflow = workflow;
	}

	public Integer getStateId() {
		return stateId;
	}

	public void setStateId(Integer stateId) {
		this.stateId = stateId;
	}

	public String getWorkflowState() {
		return workflowState;
	}

	public void setWorkflowState(String workflowState) {
		this.workflowState = workflowState;
	}

	public Integer getCurrentResponsibleId() {
		return currentResponsibleId;
	}

	public void setCurrentResponsibleId(Integer currentResponsibleId) {
		this.currentResponsibleId = currentResponsibleId;
	}

	public String getCurrentResponsibleUser() {
		return currentResponsibleUser;
	}

	public void setCurrentResponsibleUser(String currentResponsibleUser) {
		this.currentResponsibleUser = currentResponsibleUser;
	}

	public String getDocumentPath() {
		return documentPath;
	}

	public void setDocumentPath(String documentPath) {
		this.documentPath = documentPath;
	}

	public String getDocumentName() {
		return documentName;
	}

	public void setDocumentName(String documentName) {
		this.documentName = documentName;
	}

	public Integer getInActive() {
		return inActive;
	}

	public void setInActive(Integer inActive) {
		this.inActive = inActive;
	}

	public String getPreviousStateUser() {
		return previousStateUser;
	}

	public void setPreviousStateUser(String previousStateUser) {
		this.previousStateUser = previousStateUser;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Date getCreatedDt() {
		return createdDt;
	}

	public void setCreatedDt(Date createdDt) {
		this.createdDt = createdDt;
	}

	public Date getUpdatedDt() {
		return updatedDt;
	}

	public void setUpdatedDt(Date updatedDt) {
		this.updatedDt = updatedDt;
	}

	public String getDependentActivity() {
		return dependentActivity;
	}

	public void setDependentActivity(String dependentActivity) {
		this.dependentActivity = dependentActivity;
	}

	public Integer getPercentageOfCompleted() {
		return percentageOfCompleted;
	}

	public void setPercentageOfCompleted(Integer percentageOfCompleted) {
		this.percentageOfCompleted = percentageOfCompleted;
	}

	public String getMailId() {
		return mailId;
	}

	public void setMailId(String mailId) {
		this.mailId = mailId;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public List<DocumentChecklistDTO> getDocumentChecklistDto() {
		return documentChecklistDto;
	}

	public void setDocumentChecklistDto(List<DocumentChecklistDTO> documentChecklistDto) {
		this.documentChecklistDto = documentChecklistDto;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getReferenceDrawingPath() {
		return referenceDrawingPath;
	}

	public void setReferenceDrawingPath(String referenceDrawingPath) {
		this.referenceDrawingPath = referenceDrawingPath;
	}

	public Integer getDocumentId() {
		return documentId;
	}

	public void setDocumentId(Integer documentId) {
		this.documentId = documentId;
	}

	public Long getIndexCount() {
		return indexCount;
	}

	public void setIndexCount(Long indexCount) {
		this.indexCount = indexCount;
	}

	public Integer getActivityStage() {
		return activityStage;
	}

	public void setActivityStage(Integer activityStage) {
		this.activityStage = activityStage;
	}

	public Integer getDocumentFolderId() {
		return documentFolderId;
	}

	public void setDocumentFolderId(Integer documentFolderId) {
		this.documentFolderId = documentFolderId;
	}

	
	public String getDateOfCompletionString() {
		return dateOfCompletionString;
	}

	public void setDateOfCompletionString(String dateOfCompletionString) {
		this.dateOfCompletionString = dateOfCompletionString;
	}
	public String getUpdatedDtString() {
		return updatedDtString;
	}

	public void setUpdatedDtString(String updatedDtString) {
		this.updatedDtString = updatedDtString;
	}

	@PostLoad
	void postload() {
		setDateOfCompletionString((DateUtils.convertToSimpleDateTimeFormat(getDateOfCompletion())));
		setUpdatedDtString((DateUtils.convertToSimpleDateTimeFormat(getUpdatedDt())));
	}
}
