package com.synergy.bqm.documents;

import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonSubTypes.Type;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonTypeInfo.Id;

@JsonTypeInfo(use = Id.NAME, include = JsonTypeInfo.As.PROPERTY, property = "questionType", visible = true)
@JsonSubTypes({ @Type(value = SelectionQuestionTypeTemplate.class, name = SelectionQuestionTypeTemplate.QUESTION_TYPE),
		@Type(value = TextQuestionTypeTemplate.class, name = TextQuestionTypeTemplate.QUESTION_TYPE),
		@Type(value = InfoQuestionTypeTemplate.class, name = InfoQuestionTypeTemplate.QUESTION_TYPE), })
public abstract class BaseQuestionTypeTemplate {

	private String lineItemQuestion;
	private String lineItemToolTip;
	private String questionType;

	public BaseQuestionTypeTemplate() {
		super();

	}

	public BaseQuestionTypeTemplate(String lineItemQuestion, String lineItemToolTip, String questionType) {
		super();
		this.lineItemQuestion = lineItemQuestion;
		this.lineItemToolTip = lineItemToolTip;
		this.questionType = questionType;
	}

	public String getQuestionType() {
		return questionType;
	}

	public void setQuestionType(String questionType) {
		this.questionType = questionType;
	}

	public String getLineItemQuestion() {
		return lineItemQuestion;
	}

	public void setLineItemQuestion(String lineItemQuestion) {
		this.lineItemQuestion = lineItemQuestion;
	}

	public String getLineItemToolTip() {
		return lineItemToolTip;
	}

	public void setLineItemToolTip(String lineItemToolTip) {
		this.lineItemToolTip = lineItemToolTip;
	}

}
