package com.synergy.bqm.services;

import java.io.IOException;
import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import com.guvvala.framework.util.AppUser;
import com.mongodb.gridfs.GridFSDBFile;
import com.synergy.bqm.json.UserJson;
import com.synergy.bqm.models.User;

public interface UserService {

	List<User> getUserNameList();

	User getUser(String uname);

	boolean uniqueUserName(String userName);

	User getUserForLogin(String user);

	Integer createNewUser(User user);

	User validatePassword(UserJson userJson);

	public void resetpwd(String password, String userName);

	void updateUser(User user);
	
	public void updateUserImage(Integer Id,MultipartFile file) throws IOException;
	
	public void deleteUserImage(Integer userId);

	public Integer forgotPassword(String email,String userName);

	List<User> findAllUsers();
	
	List<User> findAllNormalUsers();

	public Integer makeUserActiveOrInActive(Long userId);

	public User getUserInfoByUserId(Long userId);

	public List<String> getMailIdsByUserIds(List<Long> userIds);
	
	public AppUser getUserForLogin(String userNameOrEmail, String password);
	
	public GridFSDBFile downloadUsertLogo(Integer userId);

	public  Integer  makeUserLockedOrUnlocked(Long userId);
	

	
}
