package com.synergy.bqm.services;

import java.util.List;

import com.synergy.bqm.models.FolderHistoryVw;

public interface FolderHistoryVwService {
	
	public List<FolderHistoryVw> getFolderHistoryByFolderId(Integer folderId);
	
	public List<FolderHistoryVw> getFolderHistoryByParentId(Integer parentId);
}
