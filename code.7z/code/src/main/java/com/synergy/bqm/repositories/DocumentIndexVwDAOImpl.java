package com.synergy.bqm.repositories;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.persistence.Query;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.guvvala.framework.dao.BaseDAOImpl;
import com.synergy.bqm.json.NormalSearchDTO;
import com.synergy.bqm.models.DocumentIndexVw;

@Repository
public class DocumentIndexVwDAOImpl extends BaseDAOImpl<DocumentIndexVw, Integer> implements DocumentIndexVwDAO {

	public DocumentIndexVwDAOImpl() {
		super(DocumentIndexVw.class);

	}

	public List<DocumentIndexVw> getDocumentIndexVwListByProjectId(Integer projectId) {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<DocumentIndexVw> criteriaQuery = criteriaBuilder.createQuery(DocumentIndexVw.class);
		Root<DocumentIndexVw> root = criteriaQuery.from(DocumentIndexVw.class);
		criteriaQuery.select(root).where(criteriaBuilder.equal(root.get("projectId"), projectId));
		return entityManager.createQuery(criteriaQuery).getResultList();
	}

	public List<DocumentIndexVw> getFolderDocumentIndexSearch(Integer projectId, String searchValues)
			throws ParseException {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<DocumentIndexVw> criteriaQuery = criteriaBuilder.createQuery(DocumentIndexVw.class);
		Root<DocumentIndexVw> root = criteriaQuery.from(DocumentIndexVw.class);
		criteriaQuery.select(root);
		List<Predicate> predicates = new ArrayList<>();
		// predicates.add(criteriaBuilder.like((root.get("workflowState")),"%"+searchValues+"%"));
		if (searchValues.matches("-?(0|[0-9]\\d*)")) {
			Integer i = Integer.parseInt(searchValues);
			predicates.add(criteriaBuilder.equal(root.get("activityStage"), i));
		}
		if (searchValues.equals("open")) {
			predicates.add(criteriaBuilder.equal(root.get("activityStage"), 0));
		}
		if (searchValues.equals("Work InProgress")) {
			predicates.add(criteriaBuilder.equal(root.get("activityStage"), 1));
		}
		if (searchValues.equals("Completed")) {
			predicates.add(criteriaBuilder.equal(root.get("activityStage"), 2));
		}
		predicates.add(criteriaBuilder.like((root.get("name")), "%" + searchValues + "%"));
		predicates.add(criteriaBuilder.like(root.get("department"), "%" + searchValues + "%"));
		predicates.add(criteriaBuilder.like(root.get("currentResponsibleUser"), "%" + searchValues + "%"));
		/*
		 * if(searchValues.matches("-?(0|[1-9]\\d*)")){ Integer
		 * i=Integer.parseInt(searchValues);
		 * predicates.add(criteriaBuilder.equal(root.get("project"),i ));
		 * 
		 * }
		 */
		List<Predicate> ProjectId = addpredicatesProjectId(projectId, criteriaBuilder, root);
		Predicate[] conditions = ProjectId.toArray(new Predicate[] {});
		predicates.add(criteriaBuilder.like(root.get("activityType"), "%" + searchValues + "%"));
		criteriaQuery.where(criteriaBuilder.or(predicates.toArray(new Predicate[] {})),
				criteriaBuilder.and(conditions));
		return entityManager.createQuery(criteriaQuery).getResultList();
	}

	public List<DocumentIndexVw> getFolderDocumentIndexNormalSearch(NormalSearchDTO normalSearch) {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<DocumentIndexVw> criteriaQuery = criteriaBuilder.createQuery(DocumentIndexVw.class);
		Root<DocumentIndexVw> root = criteriaQuery.from(DocumentIndexVw.class);
		criteriaQuery.select(root);
		List<Predicate> predicates = new ArrayList<>();
		if (normalSearch.getDepartmentId() != null) {
			predicates.add(criteriaBuilder.equal(root.get("departmentId"), normalSearch.getDepartmentId()));
		}
		if (normalSearch.getActivityId() != null) {
			predicates.add(criteriaBuilder.equal(root.get("activityId"), normalSearch.getActivityId()));

		}
		if (normalSearch.getSubActivityId() != null) {
			predicates.add(criteriaBuilder.equal(root.get("id"), normalSearch.getSubActivityId()));

		}
		if (normalSearch.getProjectId() != null) {
			predicates.add(criteriaBuilder.equal(root.get("projectId"), normalSearch.getProjectId()));

		}
		if (normalSearch.getDepartment() != null && !normalSearch.getDepartment().isEmpty()) {
			predicates.add(criteriaBuilder.equal(root.get("department"), normalSearch.getDepartment()));

		}

		if (normalSearch.getStageId() != null && !normalSearch.getStageId().isEmpty()) {
			predicates
					.add(criteriaBuilder.equal(root.get("activityStage"), Integer.valueOf(normalSearch.getStageId())));

		}

		criteriaQuery.where(criteriaBuilder.and(predicates.toArray(new Predicate[] {})));
		return entityManager.createQuery(criteriaQuery).getResultList();
	}

	List<Predicate> addpredicatesProjectId(Integer projectId, CriteriaBuilder criteriaBuilder,
			Root<DocumentIndexVw> root) {
		List<Predicate> predicates = new ArrayList<>();
		predicates.add(criteriaBuilder.equal(root.get("projectId"), projectId));
		return predicates;
	}

	public List<DocumentIndexVw> getFolderDocumentIndexViewByProjectIdAndPathNull(Integer projectId) {
		CriteriaBuilder builder = entityManager.getCriteriaBuilder();
		CriteriaQuery<DocumentIndexVw> criteriaQuery = builder.createQuery(DocumentIndexVw.class);
		Root<DocumentIndexVw> root = criteriaQuery.from(DocumentIndexVw.class);
		criteriaQuery.select(root).where(builder.equal(root.get("projectId"), projectId),
				builder.isNull(root.get("path")));
		// criteriaQuery.orderBy(builder.asc(root.get("departmentName")));
		return entityManager.createQuery(criteriaQuery).getResultList();

	}

	public List<DocumentIndexVw> getDocumentIndexNotification(Integer userId) {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<DocumentIndexVw> criteriaQuery = criteriaBuilder.createQuery(DocumentIndexVw.class);
		Root<DocumentIndexVw> root = criteriaQuery.from(DocumentIndexVw.class);
		criteriaQuery.select(root).where(criteriaBuilder.equal(root.get("currentResponsibleId"), userId));
		return entityManager.createQuery(criteriaQuery).getResultList();
	}

	public List<DocumentIndexVw> getFolderDocumentListByMainActivityAndProjectId(Integer activityId,
			Integer projectId) {
		CriteriaBuilder builder = entityManager.getCriteriaBuilder();
		CriteriaQuery<DocumentIndexVw> criteriaQuery = builder.createQuery(DocumentIndexVw.class);
		Root<DocumentIndexVw> root = criteriaQuery.from(DocumentIndexVw.class);
		criteriaQuery.select(root).where(builder.equal(root.get("projectId"), projectId),
				builder.equal(root.get("activityId"), activityId));
		return entityManager.createQuery(criteriaQuery).getResultList();

	}

	public List<DocumentIndexVw> countOfDocumentIndexBystate(Integer projectId) {
		CriteriaBuilder builder = entityManager.getCriteriaBuilder();
		CriteriaQuery<DocumentIndexVw> criteriaQuery = builder.createQuery(DocumentIndexVw.class);
		Root<DocumentIndexVw> root = criteriaQuery.from(DocumentIndexVw.class);
		criteriaQuery
				.select(builder.construct(DocumentIndexVw.class, builder.count(root), root.get("activityStage"),
						root.get("stateId"), root.get("workflowId")))
				.where(builder.equal(root.get("projectId"), projectId));
		criteriaQuery.groupBy(root.get("activityStage"));
		Query query = entityManager.createQuery(criteriaQuery);
		List<DocumentIndexVw> result = query.getResultList();
		return result;
	}

	public List<DocumentIndexVw> countOfDocumentIndexByDepartment(Integer projectId) {
		CriteriaBuilder builder = entityManager.getCriteriaBuilder();
		CriteriaQuery<DocumentIndexVw> criteriaQuery = builder.createQuery(DocumentIndexVw.class);
		Root<DocumentIndexVw> root = criteriaQuery.from(DocumentIndexVw.class);
		criteriaQuery
				.select(builder.construct(DocumentIndexVw.class, builder.count(root), root.get("department"),
						root.get("workflowState"), root.get("activityStage")))
				.where(builder.equal(root.get("projectId"), projectId));
		criteriaQuery.groupBy(Arrays.asList(root.get("department"), root.get("activityStage")));
		Query query = entityManager.createQuery(criteriaQuery);
		List<DocumentIndexVw> result = query.getResultList();
		return result;
	}

}
