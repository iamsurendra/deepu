/**
 * 
 */
package com.synergy.bqm.constants;

/**
 * @author karthik
 *
 */
public enum HierarchyType {
	
	TOWER,FLOOR,UNIT;

}
