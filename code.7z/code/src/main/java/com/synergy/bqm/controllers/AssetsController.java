package com.synergy.bqm.controllers;

import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.mongodb.gridfs.GridFSDBFile;
import com.synergy.bqm.services.FolderService;
import com.synergy.bqm.services.ProjectService;
import com.synergy.bqm.services.UserService;

@RestController
@RequestMapping("/images")
public class AssetsController {

	@Autowired
	ProjectService projectService;

	@Autowired
	FolderService folderService;
	
	@Autowired
	UserService userService;
	

	/**
	 * Get Image as byteArray
	 */

	@RequestMapping(value = "/projectlogo/{Id}", method = RequestMethod.GET)
	public void getLogoAsByteArraybyId(@PathVariable("Id") Integer projectId, HttpServletResponse response)
			throws IOException {
		GridFSDBFile file = projectService.downloadProjectLogo(projectId);
		if(file==null){
			return;
		}
		response.setContentType("image/jpg");
		BufferedImage imageRead = ImageIO.read(file.getInputStream());
		ImageIO.write(imageRead, "jpg", response.getOutputStream());
	}
	
	
	@RequestMapping(value = "/userImage/{userId}", method = RequestMethod.GET)
	public void getUserImageAsByteArraybyId(@PathVariable("userId")Integer userId,HttpServletResponse response)
			throws IOException {
		GridFSDBFile file = userService.downloadUsertLogo(userId);
		if(file==null){
			return;
		}
		response.setContentType("image/jpg");
		BufferedImage imageRead = ImageIO.read(file.getInputStream());
		ImageIO.write(imageRead, "jpg", response.getOutputStream());
	}
	
	
}
