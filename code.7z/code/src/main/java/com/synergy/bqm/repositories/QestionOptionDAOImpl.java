package com.synergy.bqm.repositories;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.guvvala.framework.dao.BaseDAOImpl;
import com.synergy.bqm.models.QuestionOption;

@Repository
public class QestionOptionDAOImpl extends BaseDAOImpl<QuestionOption, Integer> implements QuestionOptionDAO {

	public QestionOptionDAOImpl() {
		super(QuestionOption.class);
		// TODO Auto-generated constructor stub
	}

	public List<String> getQuestionType() {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<String> criteriaQuery = criteriaBuilder.createQuery(String.class);
		Root<QuestionOption> root = criteriaQuery.from(QuestionOption.class);
		criteriaQuery.select(root.get("questionType")).distinct(true);
		return entityManager.createQuery(criteriaQuery).getResultList();

	}

	public List<QuestionOption> getQuestionOptionByQuestionType(String questionType) {

		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<QuestionOption> criteriaQuery = criteriaBuilder.createQuery(QuestionOption.class);
		Root<QuestionOption> root = criteriaQuery.from(QuestionOption.class);
		criteriaQuery.select(root);
		criteriaQuery.where(criteriaBuilder.equal(root.get("questionType"), questionType));
		return entityManager.createQuery(criteriaQuery).getResultList();

	}

	public List<String> getQuestionOptionByType(String questionType) {

		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<String> criteriaQuery = criteriaBuilder.createQuery(String.class);
		Root<QuestionOption> root = criteriaQuery.from(QuestionOption.class);
		criteriaQuery.select(root.get("questionOption"));
		criteriaQuery.where(criteriaBuilder.equal(root.get("questionType"), questionType));
		return entityManager.createQuery(criteriaQuery).getResultList();

	}

	public List<QuestionOption> getDistinctQuestionType() {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<QuestionOption> criteriaQuery = criteriaBuilder.createQuery(QuestionOption.class);
		Root<QuestionOption> root = criteriaQuery.from(QuestionOption.class);
		criteriaQuery.select(root.get("questionType")).distinct(true);
		return entityManager.createQuery(criteriaQuery).getResultList();

	}

	public List<String> getQuestionTypes() {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<String> criteriaQuery = criteriaBuilder.createQuery(String.class);
		Root<QuestionOption> root = criteriaQuery.from(QuestionOption.class);
		criteriaQuery.select(root.get("questionType")).distinct(true);
		return entityManager.createQuery(criteriaQuery).getResultList();

	}

	public List<QuestionOption> getQuestionOptionById(List<Long> Ids) {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<QuestionOption> criteriaQuery = criteriaBuilder.createQuery(QuestionOption.class);
		Root<QuestionOption> root = criteriaQuery.from(QuestionOption.class);
		criteriaQuery.select(root);
		criteriaQuery.where(criteriaBuilder.in(root.get("id")).value(Ids));
		return entityManager.createQuery(criteriaQuery).getResultList();

	}

	public Map<String, List<String>> getQuestionAnsInfo() {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<QuestionOption> criteriaQuery = criteriaBuilder.createQuery(QuestionOption.class);
		Root<QuestionOption> root = criteriaQuery.from(QuestionOption.class);
		criteriaQuery.select(
				criteriaBuilder.construct(QuestionOption.class, root.get("questionOption"), root.get("questionType")));

		List<QuestionOption> questionOptions = entityManager.createQuery(criteriaQuery).getResultList();
		Map<String, List<String>> questionMap = new LinkedHashMap<>();
		for (QuestionOption option : questionOptions) {
			List<String> questions = questionMap.get(option.getQuestionType());
			if (questions == null) {
				questions = new ArrayList<>();
			}
			questions.add(option.getQuestionOption());
			questionMap.put(option.getQuestionType(), questions);
		}
		return questionMap;

	}
}
