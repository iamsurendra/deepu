package com.synergy.bqm.documents;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

public class SelectionQuestionType extends BaseAnswerType {

	public static final String ANSWERTYPE = "SELECTION";

	private String optionType;

	private List<String> questionOptions = new ArrayList<String>();
	
	
	
	public SelectionQuestionType() {
	}
	
	@JsonCreator
	public SelectionQuestionType(@JsonProperty("lineItemQuestion") String lineItemQuestion,
			@JsonProperty("lineItemToolTip") String lineItemToolTip, @JsonProperty("answerType") String answerType,
			@JsonProperty("optionType") String optionType) {
		super(lineItemQuestion, lineItemToolTip, answerType);
		this.optionType = optionType;
	}

	public String getOptionType() {
		return optionType;
	}

	public void setOptionType(String optionType) {
		this.optionType = optionType;
	}

	public static String getQuestionType() {
		return ANSWERTYPE;
	}

	public List<String> getQuestionOptions() {
		return questionOptions;
	}

	public void setQuestionOptions(List<String> questionOptions) {
		this.questionOptions = questionOptions;
	}

}
