package com.synergy.bqm.constants;

public class BqmConstants {

	public static final String PASSWORD = "password";
	public static final String LOGIN_NAME = "loginname";
	public static final String FNAME = "fname";
	public static final String EMAIL = "email";
	public static final String MESSAGE = "message";
	public static final String CHECKLIST = "checklist";
	public static final String PREVIOUSSTATEUSER = "previousStateUser";
	public static final String DOCUMENTNAME = "documentName";
	public static final String PATH = "path";
	public static final String PROJECT = "project";
	
	
	public static final String NOTIFICATION_MESSAGE="notificationMsg";
	public static final String PDF_TEMPLATE_TYPE =".pdf";
	public static final String DOCUMENT_TYPE="decumentType";
	
}
