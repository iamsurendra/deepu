package com.synergy.bqm.controllers;

import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.synergy.bqm.json.ProjectStageDTO;
import com.synergy.bqm.json.ProjectStatusDTO;
import com.synergy.bqm.json.ProjectTypeDTO;
import com.synergy.bqm.json.QuestionOptionDTO;
import com.synergy.bqm.models.Project;
import com.synergy.bqm.models.ProjectHierarchy;
import com.synergy.bqm.models.ProjectListVw;
import com.synergy.bqm.models.ProjectMember;
import com.synergy.bqm.models.ProjectStage;
import com.synergy.bqm.models.ProjectStatus;
import com.synergy.bqm.models.ProjectType;
import com.synergy.bqm.models.QuestionOption;
import com.synergy.bqm.services.ProjectHierarchyService;
import com.synergy.bqm.services.ProjectListVwService;
import com.synergy.bqm.services.ProjectMemberService;
import com.synergy.bqm.services.ProjectService;
import com.synergy.bqm.services.ProjectStageService;
import com.synergy.bqm.services.ProjectStatusService;
import com.synergy.bqm.services.ProjectTypeService;
import com.synergy.bqm.services.QuestionOptionService;

@RestController
@RequestMapping("/api/project")
public class ProjectController {

	@Autowired
	ProjectService projectService;

	@Autowired
	ProjectListVwService projectListVwService;

	@Autowired
	ProjectHierarchyService projectHierarchyService;

	@Autowired
	ProjectTypeService projectTypeService;

	@Autowired
	ProjectMemberService projectMemberService;

	@Autowired
	ProjectStageService projectStageService;

	@Autowired
	ProjectStatusService projectStatusService;

	@Autowired
	QuestionOptionService questionOptionService;

	/**
	 * Get All Projects List
	 * 
	 * @throws IOException
	 **/
	@RequestMapping(value = "/getAllProjects/{userId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<ProjectListVw> getAllProjects(@PathVariable("userId") Integer userId) {
		return projectListVwService.getProjectListVwInfo(userId);

	}

	/**
	 * Find All projects based on Active status
	 */
	@RequestMapping(value = "/getAllArchiveProjects", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<Project> getAllArchiveProjects() {
		return projectService.getAllArchiveProjects();
	}

	/*
	 * Create New Project
	 */
	@RequestMapping(value = "/project", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public Project createProject(@RequestBody Project project) {
		return projectService.createProject(project);

	}

	/*
	 * Count of Projects
	 */
	@RequestMapping(value = "/countOfProjects/{userId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public Long countOfProjects(@PathVariable("userId") Integer userId) {
		return (long) projectListVwService.getProjectListVwInfo(userId).size();

	}
	/*
	 * Get Project By ProjectId
	 */

	@RequestMapping(value = "/projectById/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public Project getProjectByProjectId(@PathVariable("id") Integer projectId) {
		return projectService.getProjectByProjectId(projectId);

	}

	/**
	 * Update Project
	 */
	@RequestMapping(value = "/updateProject", method = RequestMethod.POST)
	public void updateProject(@RequestBody Project project) {
		projectService.updateProject(project);

	}

	/**
	 * delete project by changing the archive to true
	 */
	@RequestMapping(value = "/deleteProject/{projectId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public void deleteProject(@PathVariable("projectId") Integer projectId) {
		projectService.deleteProject(projectId);

	}

	/*
	 * Delete ProjectMember
	 */
	@RequestMapping(value = "/deleteProjectMember", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public void deleteProjectMember(@RequestBody ProjectMember projectMember) {
		projectMemberService.deleteProjectMember(projectMember);
	}

	/*
	 * Upload Logo for Project
	 */
	@RequestMapping(value = "/upLoadLogo", method = RequestMethod.POST, produces = MediaType.MULTIPART_FORM_DATA_VALUE)
	public void upDateLogo(@RequestParam(value = "Id", required = false) Integer Id,
			@RequestParam(value = "file", required = false) MultipartFile logo) throws IOException {
		projectService.UpdateLogo(logo, Id);

	}

	/**
	 * Get ProjectHierarchy by ID
	 */

	@RequestMapping(value = "/projectHierarchy/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ProjectHierarchy getProjectHierarchyByHierarchyId(@PathVariable("id") Integer id) {
		return projectHierarchyService.getProjectHierarchyByHierarchyId(id);
	}

	@RequestMapping(value = "/projectTypes", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<String> getprojectTypes() {
		return projectTypeService.getprojectTypes();

	}

	@RequestMapping(value = "subTypes/{type}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<String> getSubTypesByTypes(@PathVariable("type") String type) {
		return projectTypeService.getSubTypesByTypes(type);

	}

	// get details of subtypes by Projecttype

	@RequestMapping(value = "getSubTypesByProjectType/{projectType}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<ProjectType> getSubTypesByProjectType(@PathVariable("projectType") String projectType) {
		return projectTypeService.getSubTypesByProjectType(projectType);
	}

	/*
	 * Get All ProjectStages
	 */
	@RequestMapping(value = "getAllProjectStages", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<ProjectStage> getAllProjectStages() {
		return projectStageService.getAllProjectStages();

	}

	/*
	 * Create Or Update ProjectStages
	 */
	@RequestMapping(value = "createOrUpdateProjectStages", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	public void createOrUpdateProjectStages(@RequestBody ProjectStageDTO projectStageDTO) {
		projectStageService.createOrUpdateProjectStages(projectStageDTO.getProjectStage(),
				projectStageDTO.getDeletedIds());
	}

	/*
	 * Get All ProjectStatus
	 */
	@RequestMapping(value = "getAllProjectStatus", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<ProjectStatus> getAllProjectStatus() {
		return projectStatusService.getAllProjectStatus();

	}

	/*
	 * Create Or Update ProjectStatus
	 */
	@RequestMapping(value = "/createOrUpdateProjectStatus", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	public void createOrUpdateProjectStatus(@RequestBody ProjectStatusDTO projectStatusDTO) {
		projectStatusService.createOrUpdateProjectStatus(projectStatusDTO.getProjectStatus(),
				projectStatusDTO.getDeletedIds());
	}

	/*
	 * Create Or Update ProjectTypes
	 */
	@RequestMapping(value = "/createOrUpdateProjectTypes", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	public void createOrUpdateProjectTypes(@RequestBody ProjectTypeDTO projectTypeDTO) {
		projectTypeService.createOrUpdateProjectTypes(projectTypeDTO);
	}

	// Delete ProjectStage
	@RequestMapping(value = "deleteProjectStage/{Id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public void deleteProjectStage(@PathVariable("Id") Integer Id) {
		projectStageService.deleteProjectStage(Id);
	}

	// Delete ProjectStatus
	@RequestMapping(value = "deleteProjectStatus/{Id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public void deleteProjectStatus(@PathVariable("Id") Integer Id) {
		projectStatusService.deleteProjectStatus(Id);
	}

	// Delete Project SubType
	@RequestMapping(value = "deleteProjectSubType/{Id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public void deleteProjectSubType(@PathVariable("Id") Integer Id) {
		projectTypeService.deleteProjectSubType(Id);
	}

	// create questionOptions

	@RequestMapping(value = "/createQuestionOption", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public void createQuestionOptionType(@RequestBody QuestionOptionDTO questionOption) {
		questionOptionService.createquestionOption(questionOption.getQuestionOption(), questionOption.getIds());
	}

	// find All QuestionOptions
	@RequestMapping(value = "/findAllQuestionOption", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<QuestionOption> findAllQuestionOption() {
		return questionOptionService.getDistinctQuestionType();
	}

	@RequestMapping(value = "getQuestionOptionByType/{type}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<QuestionOption> getQuestionOptionByType(@PathVariable("type") String type) {
		return questionOptionService.getQuestionOptionByType(type);

	}

	@RequestMapping(value = "removeProjectLogo/{projectId}", method = RequestMethod.GET, consumes = MediaType.APPLICATION_JSON_VALUE)
	public void deleteProjectLogo(@PathVariable("projectId") Integer projectId) {
		projectService.deleteProjectLogo(projectId);

	}

}