package com.synergy.bqm.repositories;

import java.util.List;

import com.guvvala.framework.dao.BaseDAO;
import com.synergy.bqm.models.WorkflowStates;

public interface WorkflowStatesDAO extends BaseDAO<WorkflowStates, Integer>{
	
	public List<WorkflowStates> getWorkflowStatesById(Integer workflowId);
	
	public void deleteWorkFlowStatesByIds(List<Integer> workflowIds);
	
	public List<String> getWorkflowStatesNames(List<Integer> Ids);
	
	public List<WorkflowStates> getWorkflowStates(List<Integer> Ids);
	
	public List<Integer> getSeqIds(Integer workflowId);	
	
	public Integer getSeqIdByStateId(Integer stateId);
	
	public Integer getCurrentStatusByWorkflowId(Integer workflowId);
	
	public String getWorkflowState(Integer Id);
	
	public List<WorkflowStates> getOrderBySeqId(Integer workflowId);
	
	
	
}
