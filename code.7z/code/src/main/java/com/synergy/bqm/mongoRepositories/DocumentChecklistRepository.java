package com.synergy.bqm.mongoRepositories;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.synergy.bqm.documents.DocumentChecklist;

public interface DocumentChecklistRepository extends  MongoRepository<DocumentChecklist, String> {

	
	
	
}
