package com.synergy.bqm.models;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class WorkflowNavigationKey implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Column(name = "WORKFLOW_STATE_ID")
	private Integer workflowStateId;

	@Column(name = "NEXT_WORKFLOW_STATE_ID")
	private Integer nextWorkflowStateId;

	public Integer getWorkflowStateId() {
		return workflowStateId;
	}

	public void setWorkflowStateId(Integer workflowStateId) {
		this.workflowStateId = workflowStateId;
	}

	public Integer getNextWorkflowStateId() {
		return nextWorkflowStateId;
	}

	public void setNextWorkflowStateId(Integer nextWorkflowStateId) {
		this.nextWorkflowStateId = nextWorkflowStateId;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((nextWorkflowStateId == null) ? 0 : nextWorkflowStateId.hashCode());
		result = prime * result + ((workflowStateId == null) ? 0 : workflowStateId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		WorkflowNavigationKey other = (WorkflowNavigationKey) obj;
		if (nextWorkflowStateId == null) {
			if (other.nextWorkflowStateId != null)
				return false;
		} else if (!nextWorkflowStateId.equals(other.nextWorkflowStateId))
			return false;
		if (workflowStateId == null) {
			if (other.workflowStateId != null)
				return false;
		} else if (!workflowStateId.equals(other.workflowStateId))
			return false;
		return true;
	}

}
