package com.synergy.bqm.repositories;

import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.guvvala.framework.dao.BaseDAOImpl;
import com.synergy.bqm.models.ProjectType;

@Repository
public class ProjectTypeDAOImpl extends BaseDAOImpl<ProjectType, Integer> implements ProjectTypeDAO {

	public ProjectTypeDAOImpl() {
		super(ProjectType.class);
		// TODO Auto-generated constructor stub
	}

	@Override
	public List<String> getProjectTypes() {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<String> criteriaQuery = criteriaBuilder.createQuery(String.class);
		Root<ProjectType> root = criteriaQuery.from(ProjectType.class);
		criteriaQuery.select(root.get("type")).distinct(true);
		return entityManager.createQuery(criteriaQuery).getResultList();
	}

	@Override
	public List<String> getSubTypesByTypes(String type) {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<String> criteriaQuery = criteriaBuilder.createQuery(String.class);
		Root<ProjectType> makeRoot = criteriaQuery.from(ProjectType.class);
		criteriaQuery.select(makeRoot.get("subType")).distinct(true);
		criteriaQuery.where(criteriaBuilder.equal(makeRoot.get("type"), type));
		return entityManager.createQuery(criteriaQuery).getResultList();
	}

	public List<ProjectType> getSubTypesByProjectType(String type) {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<ProjectType> criteriaQuery = criteriaBuilder.createQuery(ProjectType.class);
		Root<ProjectType> root = criteriaQuery.from(ProjectType.class);
		criteriaQuery.select(root).where(criteriaBuilder.equal(root.get("type"), type));
		return entityManager.createQuery(criteriaQuery).getResultList();

	}
	
	public List<ProjectType> getProjectTypeInfoById(List<Integer> Ids) {
		CriteriaBuilder builder = entityManager.getCriteriaBuilder();
		CriteriaQuery<ProjectType> criteriaQuery = builder.createQuery(ProjectType.class);
		Root<ProjectType> root = criteriaQuery.from(ProjectType.class);
		criteriaQuery.select(root).distinct(true);
		criteriaQuery.where(builder.in(root.get("id")).value(Ids));
		return entityManager.createQuery(criteriaQuery).getResultList();

	}

}
