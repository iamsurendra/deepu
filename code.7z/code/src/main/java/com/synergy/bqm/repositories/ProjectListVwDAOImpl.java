package com.synergy.bqm.repositories;

import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.guvvala.framework.dao.BaseDAOImpl;
import com.synergy.bqm.models.ProjectListVw;

@Repository
public class ProjectListVwDAOImpl extends BaseDAOImpl<ProjectListVw, Integer> implements ProjectListVwDAO{

	public ProjectListVwDAOImpl() {
		super(ProjectListVw.class);
		// TODO Auto-generated constructor stub
	}
	
	public List<ProjectListVw> getProjectInfoByProjectIds(List<Integer> projectIds){
		CriteriaBuilder builder = entityManager.getCriteriaBuilder();
		CriteriaQuery<ProjectListVw> criteriaQuery = builder.createQuery(ProjectListVw.class);
		Root<ProjectListVw> root = criteriaQuery.from(ProjectListVw.class);
		criteriaQuery.select(root);
		criteriaQuery.where(root.get("projectId").in(projectIds));
		return entityManager.createQuery(criteriaQuery).getResultList();

		
	}

}
