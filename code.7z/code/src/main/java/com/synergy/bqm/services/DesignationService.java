package com.synergy.bqm.services;

import java.util.List;

import com.synergy.bqm.json.DesignationDTO;
import com.synergy.bqm.models.Designation;

public interface DesignationService {

	public void createDesignation(Designation designation);

	public List<String> getDesignationNames();

	public List<Designation> findAllDesignations();

	public void updateDesignation(Designation designation);

	public void deleteDesignationById(Designation designation);
	
	public void createAndUpdateDesignation(DesignationDTO designationDTO);

}
