package com.synergy.bqm.services;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.synergy.bqm.models.QuestionOption;
import com.synergy.bqm.repositories.QuestionOptionDAO;

@Service("questionOptionService")
public class QuestionOptionServiceImpl implements QuestionOptionService {

	@Autowired
	QuestionOptionDAO questionOptionDAO;

	@Transactional
	public List<QuestionOption> getDistinctQuestionType() {
		return questionOptionDAO.getDistinctQuestionType();
	}

	@Transactional
	public List<String> getQuestionOptionByQuestionType(String questionType) {
		return questionOptionDAO.getQuestionOptionByType(questionType);

	}

	@Transactional
	public List<QuestionOption> findAllQuestionOption() {
		return questionOptionDAO.findAll();

	}
	
	public List<String> getQuestionTypes(){
		return questionOptionDAO.getQuestionTypes();
	}

	@Transactional
	public List<QuestionOption> getQuestionOptionByType(String Type) {
		return questionOptionDAO.getQuestionOptionByQuestionType(Type);

	}

	@Transactional
	public void createquestionOption(List<QuestionOption> questionOption, List<Long> deletedIds) {
		if (!deletedIds.isEmpty()) {

			// Deleted QuestionOptions List
			List<QuestionOption> options = questionOptionDAO.getQuestionOptionById(deletedIds);
			for (QuestionOption option : options) {
				questionOptionDAO.delete(option);
			}
		}
		if (questionOption !=null && !questionOption.isEmpty()) {
			for (QuestionOption option : questionOption) {
				if (option.getId() == null) {
					questionOptionDAO.create(option);
				} else {
					questionOptionDAO.update(option);
				}
			}
		}

	}
	@Transactional
	public Map<String,List<String>> getQuestionAnsInfo(){
		return questionOptionDAO.getQuestionAnsInfo();
		
	}

}
