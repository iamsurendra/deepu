package com.synergy.bqm.services;

import java.util.List;

import com.synergy.bqm.json.CheckListServiceDTO;
import com.synergy.bqm.models.ChecklistService;

public interface CheckListServicesService {

	public List<ChecklistService> getAllChecklistType();

	public List<String> getCheckListServices();

	public void createAndUpdateChecklistService(CheckListServiceDTO checkListServiceDTO);
}
