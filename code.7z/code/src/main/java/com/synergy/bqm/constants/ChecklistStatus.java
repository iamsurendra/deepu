package com.synergy.bqm.constants;

import java.util.HashMap;
import java.util.Map;

public enum ChecklistStatus {

	NEW(-1,"New"),
	CHECK(0, "Check"), 
	RE_CHECK(1, "ReCheck"),
	COMPLETED(2, "Completed");

	public final int value;
	public final String stringValue;

	private static final Map<Integer, ChecklistStatus> valueMap = new HashMap<Integer, ChecklistStatus>();
	private static final Map<String, ChecklistStatus> stringMap = new HashMap<String, ChecklistStatus>();

	static {
		for (ChecklistStatus constant : ChecklistStatus.class.getEnumConstants()) {
			valueMap.put(constant.value, constant);
			stringMap.put(constant.stringValue, constant);
		}
	}

	private ChecklistStatus(int value, String stringValue) {
		this.value = value;
		this.stringValue = stringValue;
	}
	

	  public static ChecklistStatus fromString(final String stringValue) {
	        return stringMap.get(stringValue);
	    }

	    public static ChecklistStatus fromInteger(final Integer intValue) {
	        return valueMap.get(intValue);
	    }
}
