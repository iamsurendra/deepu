package com.synergy.bqm.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.synergy.bqm.json.DepartmentDTO;
import com.synergy.bqm.models.Department;
import com.synergy.bqm.services.DepartmentService;

@RestController
@RequestMapping("/api/department")
public class DepartmentController {

	@Autowired
	DepartmentService departmentService;

	@RequestMapping(value = "/createDepartment", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	public void createDepartment(@RequestBody Department department) {
		departmentService.createDepartment(department);
	}

	@RequestMapping(value = "/createOrUpdateDepartments", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	public void createAndUpdateDepartments(@RequestBody DepartmentDTO departmentDTO) {
		departmentService.createAndUpdateDepartments(departmentDTO);
	}

	@RequestMapping(value = "/findAllDepartments", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<Department> findAllDepartments() {
		return departmentService.findAllDepartments();
	}

	@RequestMapping(value = "/findAllDepartmentsForTemplates/{templateId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<Department> findAllDepartmentsForTemplates(@PathVariable("templateId") Integer templateId) {
		return departmentService.getAllDepartmentsByTemplateId(templateId);
	}

	@RequestMapping(value = "/getDepartmentNames", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<String> getAlldepartmentNames() {
		return departmentService.getAlldepartmentNames();
	}

	@RequestMapping(value = "/updateDepartment", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	public void updateDepartment(@RequestBody Department department) {
		departmentService.updateDepartment(department);
	}

	@RequestMapping(value = "/deleteDepartmentById/{Id}", method = RequestMethod.GET, consumes = MediaType.APPLICATION_JSON_VALUE)
	public void deleteDepartmentById(@PathVariable("Id") Integer Id) {
		departmentService.deleteDepartmentById(Id);
	}

}
