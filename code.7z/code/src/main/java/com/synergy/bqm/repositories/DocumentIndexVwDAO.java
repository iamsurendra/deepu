package com.synergy.bqm.repositories;

import java.text.ParseException;
import java.util.List;

import com.guvvala.framework.dao.BaseDAO;
import com.synergy.bqm.json.NormalSearchDTO;
import com.synergy.bqm.models.DocumentIndexVw;

public interface DocumentIndexVwDAO extends BaseDAO<DocumentIndexVw, Integer> {
	
	public List<DocumentIndexVw> getDocumentIndexVwListByProjectId(Integer projectId);
	
	
	public List<DocumentIndexVw>getFolderDocumentIndexSearch(Integer projectId,String searchValues) throws ParseException;

	public List<DocumentIndexVw> getDocumentIndexNotification(Integer userId);
	
	public List<DocumentIndexVw> getFolderDocumentListByMainActivityAndProjectId(Integer activityId,Integer projectId);
	
	public List<DocumentIndexVw>getFolderDocumentIndexNormalSearch(NormalSearchDTO normalSearch);
	
	public List<DocumentIndexVw> countOfDocumentIndexBystate(Integer projectId);
	
	public List<DocumentIndexVw> countOfDocumentIndexByDepartment(Integer projectId);
}
