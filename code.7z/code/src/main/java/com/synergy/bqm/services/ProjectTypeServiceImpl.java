package com.synergy.bqm.services;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.synergy.bqm.json.ProjectTypeDTO;
import com.synergy.bqm.models.Project;
import com.synergy.bqm.models.ProjectType;
import com.synergy.bqm.repositories.ProjectDAO;
import com.synergy.bqm.repositories.ProjectTypeDAO;

@Service("projectTypeService")
public class ProjectTypeServiceImpl implements ProjectTypeService {

	@Autowired
	ProjectTypeDAO projectTypeDAO;

	@Autowired
	ProjectDAO projectDAO;

	@Transactional
	public List<String> getprojectTypes() {

		return projectTypeDAO.getProjectTypes();

	}

	@Transactional
	@Override
	public List<String> getSubTypesByTypes(String type) {
		return projectTypeDAO.getSubTypesByTypes(type);

	}

	@Transactional
	@Override
	public List<ProjectType> getSubTypesByProjectType(String projectType) {
		return projectTypeDAO.getSubTypesByProjectType(projectType);
	}

	@Transactional
	public void deleteProjectSubType(Integer Id) {
		ProjectType type = projectTypeDAO.findOne(Id);
		projectTypeDAO.delete(type);
	}

	@Transactional
	public void createOrUpdateProjectTypes(ProjectTypeDTO projectTypeDTO) {
		if (!projectTypeDTO.getProjectTypeList().isEmpty()) {
			for (ProjectType projectType : projectTypeDTO.getProjectTypeList()) {
				if (projectType.getId() == null) {

					projectTypeDAO.create(projectType);

				} else {
					projectTypeDAO.update(projectType);

				}

			}

		}
		if (!projectTypeDTO.getIds().isEmpty()) {
			List<ProjectType> deleteproject = projectTypeDAO.getProjectTypeInfoById(projectTypeDTO.getIds());
			if (!deleteproject.isEmpty()) {
				List<String> deleteTypeList = new ArrayList<String>();
				for (ProjectType types : deleteproject) {
					deleteTypeList.add(types.getType());
				}
				List<Project> typesList = projectDAO.getProjectInfoByTypes(deleteTypeList);
				for (Project types : typesList) {

					types.setType(null);
					types.setSubType(null);
				}

				for (ProjectType deleteProjectType : deleteproject) {

					projectTypeDAO.delete(deleteProjectType);
				}
			}
		}

	}

}