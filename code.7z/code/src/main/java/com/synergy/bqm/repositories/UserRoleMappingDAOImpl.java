package com.synergy.bqm.repositories;

import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.guvvala.framework.dao.BaseDAOImpl;
import com.synergy.bqm.models.UserRoleMapping;

@Repository
public class UserRoleMappingDAOImpl extends BaseDAOImpl<UserRoleMapping, Integer> implements UserRoleMappingDAO {

	public UserRoleMappingDAOImpl() {
		super(UserRoleMapping.class);
	}

	public List<Integer> getRoleIdsByProjectIdsAndUserIds(Integer projectId, Integer userId) {
		CriteriaBuilder builder = entityManager.getCriteriaBuilder();
		CriteriaQuery<Integer> criteriaQuery = builder.createQuery(Integer.class);
		Root<UserRoleMapping> root = criteriaQuery.from(UserRoleMapping.class);
		criteriaQuery.select(root.get("roleId"));
		criteriaQuery.where(builder.and(builder.equal(root.get("projectId"), projectId)),
				builder.equal(root.get("userId"), userId));
		return entityManager.createQuery(criteriaQuery).getResultList();

	}

}
