package com.synergy.bqm.services;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.guvvala.framework.util.DateUtils;
import com.guvvala.framework.util.ThreadLocalUtil;
import com.mongodb.gridfs.GridFSDBFile;
import com.synergy.bqm.constants.ChecklistStatus;
import com.synergy.bqm.documents.BaseAnswerType;
import com.synergy.bqm.documents.BaseQuestionTypeTemplate;
import com.synergy.bqm.documents.Checklist;
import com.synergy.bqm.documents.ChecklistTemplate;
import com.synergy.bqm.documents.InfoQuestionType;
import com.synergy.bqm.documents.InfoQuestionTypeTemplate;
import com.synergy.bqm.documents.Section;
import com.synergy.bqm.documents.SectionTemplate;
import com.synergy.bqm.documents.SelectionQuestionType;
import com.synergy.bqm.documents.SelectionQuestionTypeTemplate;
import com.synergy.bqm.documents.Subsection;
import com.synergy.bqm.documents.SubsectionTemplate;
import com.synergy.bqm.documents.TextQuestionType;
import com.synergy.bqm.documents.TextQuestionTypeTemplate;
import com.synergy.bqm.models.ProjectHierarchy;
import com.synergy.bqm.mongoRepositories.CheckListRepository;
import com.synergy.bqm.mongoRepositories.CheckListTemplateRepository;
import com.synergy.bqm.mongoRepositories.FileMongoDAO;
import com.synergy.bqm.repositories.ProjectDAO;
import com.synergy.bqm.repositories.ProjectHierarchyDAO;
import com.synergy.bqm.repositories.QuestionOptionDAO;

@Service
public class ChecklistServiceImpl implements ChecklistService {

	@Autowired
	CheckListRepository checkListRepository;

	@Autowired
	CheckListTemplateRepository checkListTemplateRepository;

	@Autowired
	QuestionOptionDAO questionOptionDAO;

	@Autowired
	ProjectDAO projectDAO;

	@Autowired
	FileMongoDAO fileMongoDAO;

	@Autowired
	ProjectHierarchyDAO projectHierarchyDAO;

	@Transactional
	public void importChecklistToParentHierarchy(Integer projectId, List<String> checklistIds,
			Integer projectHierarchyId, Boolean withChild) {
		ProjectHierarchy hierarchy = projectHierarchyDAO.findOne(projectHierarchyId);
		importCheckListToChildHierarchy(projectId, checklistIds, hierarchy.getProjectHierarchyId());

		// checking for child Hierarchy
		if (!hierarchy.getProjectHierarchies().isEmpty() && withChild) {
			for (ProjectHierarchy projectHierarchy : hierarchy.getProjectHierarchies()) {
				importCheckListToChildHierarchy(projectId, checklistIds, projectHierarchy.getProjectHierarchyId());
			}
		}
	}

	private void importCheckListToChildHierarchy(Integer projectId, List<String> checklistIds,
			Integer projectHierarchyId) {
		Map<String, List<String>> questionOptionsMap = questionOptionDAO.getQuestionAnsInfo();
		String projectName = projectDAO.getProjectNameById(projectId);
		ProjectHierarchy hierarchy = projectHierarchyDAO.findOne(projectHierarchyId);
		for (String checklistId : checklistIds) {
			ChecklistTemplate checklistTemplate = checkListTemplateRepository.findOne(checklistId);
			Checklist checklist = new Checklist();
			checklist.setProjectId(projectId);
			checklist.setProjectName(projectName);
			checklist.setChecklistName(checklistTemplate.getChecklistName());
			checklist.setChecklistType(checklistTemplate.getChecklistType());
			checklist.setChecklistService(checklistTemplate.getChecklistService());
			checklist.setHierarchyId(projectHierarchyId);
			checklist.setLocation(hierarchy.getHierarchyName());
			checklist.setStatus(ChecklistStatus.NEW.value);
			checklist.setVersion(0.0);
			checklist.setUpdatedBy(ThreadLocalUtil.getUserName());
			checklist.setUpdatedOn(DateUtils.getCurrentISTDateTime().toString());

			for (SectionTemplate sectionTemplate : checklistTemplate.getSectionList()) {
				Section template = new Section();
				template.setSectionName(sectionTemplate.getSectionName());
				template.setSectionInfo(sectionTemplate.getSectionInfo());
				template.setReference(sectionTemplate.getReference());
				checklist.getSectionList().add(template);
				if (!sectionTemplate.getQuestionList().isEmpty()) {
					template.setAnswerType(sectionTemplate.getQuestionType());
					template.getQuestionList()
							.addAll(getQuestionList(sectionTemplate.getQuestionList(), questionOptionsMap));
				}
				for (SubsectionTemplate subsection : sectionTemplate.getSubsectionList()) {
					Subsection section = new Subsection();
					section.setSubsectionName(subsection.getSubsectionName());
					section.setSubsectionInfo(subsection.getSubsectionInfo());
					section.setReference(subsection.getReference());
					template.getSubsectionList().add(section);
					if (!subsection.getQuestionList().isEmpty()) {
						section.setAnswerType(subsection.getQuestionType());
						section.getQuestionList()
								.addAll(getQuestionList(subsection.getQuestionList(), questionOptionsMap));

					}
				}

			}
			checkListRepository.save(checklist);
		}
	}

	private List<BaseAnswerType> getQuestionList(List<BaseQuestionTypeTemplate> baseQuestionTypeTemplate,
			Map<String, List<String>> questionOptionsMap) {
		List<BaseAnswerType> baseAnswerType = new ArrayList<>();
		for (BaseQuestionTypeTemplate questionTypeTemplate : baseQuestionTypeTemplate) {
			if (questionTypeTemplate instanceof TextQuestionTypeTemplate) {
				TextQuestionType textQuestionType = new TextQuestionType();
				textQuestionType.setLowerLimit(((TextQuestionTypeTemplate) questionTypeTemplate).getLowerLimit());
				textQuestionType.setUpperLimit(((TextQuestionTypeTemplate) questionTypeTemplate).getUpperLimit());
				textQuestionType.setAnswerType(questionTypeTemplate.getQuestionType());
				textQuestionType.setLineItemToolTip(questionTypeTemplate.getLineItemToolTip());
				textQuestionType.setLineItemQuestion(questionTypeTemplate.getLineItemQuestion());
				baseAnswerType.add(textQuestionType);
			} else if (questionTypeTemplate instanceof InfoQuestionTypeTemplate) {
				InfoQuestionType infoQuestionType = new InfoQuestionType();
				infoQuestionType.setAnswerType(questionTypeTemplate.getQuestionType());
				infoQuestionType.setLineItemToolTip(questionTypeTemplate.getLineItemToolTip());
				infoQuestionType.setLineItemQuestion(questionTypeTemplate.getLineItemQuestion());
				baseAnswerType.add(infoQuestionType);
			} else if (questionTypeTemplate instanceof SelectionQuestionTypeTemplate) {
				SelectionQuestionType selectionQuestionType = new SelectionQuestionType();
				selectionQuestionType.setAnswerType(questionTypeTemplate.getQuestionType());
				selectionQuestionType
						.setOptionType(((SelectionQuestionTypeTemplate) questionTypeTemplate).getOptionType());
				selectionQuestionType.setLineItemToolTip(questionTypeTemplate.getLineItemToolTip());
				selectionQuestionType.setLineItemQuestion(questionTypeTemplate.getLineItemQuestion());
				selectionQuestionType.getQuestionOptions()
						.addAll((((SelectionQuestionTypeTemplate) questionTypeTemplate).getQuestionOptions()));
				baseAnswerType.add(selectionQuestionType);
			}
		}
		return baseAnswerType;
	}

	// get Image form mongoDb by Id
	public GridFSDBFile getImageById(String id) {
		GridFSDBFile fs = fileMongoDAO.getById(id);
		return fs;

	}

}
