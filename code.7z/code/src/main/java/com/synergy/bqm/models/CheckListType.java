package com.synergy.bqm.models;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name = "checklist_type")
public class CheckListType implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue
	@Column(name = "checklisttype_id")
	private Integer checkListTypeId;

	@Column(name = "checklisttype_name")
	private String checkListTypeName;

	public Integer getCheckListTypeId() {
		return checkListTypeId;
	}

	public void setCheckListTypeId(Integer checkListTypeId) {
		this.checkListTypeId = checkListTypeId;
	}

	public String getCheckListTypeName() {
		return checkListTypeName;
	}

	public void setCheckListTypeName(String checkListTypeName) {
		this.checkListTypeName = checkListTypeName;
	}

}
