package com.synergy.bqm.services;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.synergy.bqm.models.WorkflowDTO;
import com.synergy.bqm.models.WorkflowType;
import com.synergy.bqm.repositories.WorkflowTypeDAO;

@Service("workflowTypeService")
public class WorkflowTypeServiceImpl implements WorkflowTypeService {
	@Autowired
	WorkflowTypeDAO workflowTypeDAO;

	@Transactional
	public List<String> getWorkflowTypes() {
		return workflowTypeDAO.getWorkflowTypes();

	}

	@Transactional
	@Override
	public List<String> getSubTypesByTypes(String type) {
		return workflowTypeDAO.getSubTypesByTypes(type);

	}

	@Transactional
	@Override
	public List<WorkflowType> getSubTypesByWorkflowType(String workflowType) {
		return workflowTypeDAO.getSubTypesByWorkflowType(workflowType);
	}

	@Transactional
	public void deleteWorkflowSubType(Integer Id) {
		WorkflowType type = workflowTypeDAO.findOne(Id);
		workflowTypeDAO.delete(type);
	}

	@Transactional
	public void createOrUpdateWorkflowTypes(WorkflowDTO workflowDTO) {
		if (!workflowDTO.getWorkFlowTypeList().isEmpty() ) {
			for (WorkflowType workflowType : workflowDTO.getWorkFlowTypeList()) {
				if (workflowType.getId() == null) {
					workflowTypeDAO.create(workflowType);
				} else {
					workflowTypeDAO.update(workflowType);
				}
			}

		}
		if (!workflowDTO.getIds().isEmpty()) { 
			List<WorkflowType> deleteWorkflows = workflowTypeDAO.getWorkflowTypeInfoById(workflowDTO.getIds());
			if (!deleteWorkflows.isEmpty() ) {
				for (WorkflowType deleteWorkflowType : deleteWorkflows) {
					workflowTypeDAO.delete(deleteWorkflowType);
				}
			}
		}

	}

}
