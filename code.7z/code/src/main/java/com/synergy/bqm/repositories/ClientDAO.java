package com.synergy.bqm.repositories;

import java.util.List;

import com.guvvala.framework.dao.BaseDAO;
import com.synergy.bqm.models.Client;

public interface ClientDAO extends BaseDAO<Client, Integer>{

	List<String> getClientNameList();
	public Client getClientInfoByClientId(Integer clientId);
	public Long clienttNameExists(String ClientName);
}
