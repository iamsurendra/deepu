package com.synergy.bqm.controllers;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.synergy.bqm.models.DocumentIndexVw;
import com.synergy.bqm.services.DocumentIndexVwService;

@RestController
@RequestMapping("documentIndexExcel")
public class FolderDocumentIndexExcelExportController {

	@Autowired
	DocumentIndexVwService documentIndexVwService;
	
	
	
	ArrayList<String>ColumnsNames=new ArrayList<>(Arrays.asList("SL NO","SERVICE","PATH","DRAWING TITLE","REVISION","CURRENT STATUS","CURRENT RESPONSIBLE","ESTIMATED DATE"));
	
	
	
	@RequestMapping(value = "downLoadExcel/{Id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public void downloadExcelDocumentIndex(@PathVariable("Id") Integer projectId, HttpServletResponse response)
			throws IOException {
		List<DocumentIndexVw> folderDocumentIndex = documentIndexVwService.getDocumentIndexVwByProjectId(projectId);
		XSSFWorkbook wb = new XSSFWorkbook();
		XSSFSheet sheet = wb.createSheet("Sheet1");
		XSSFRow rowhead = sheet.createRow((short) 0);
		sheet.addMergedRegion(new CellRangeAddress(0, 0, 0, 1));
		sheet.addMergedRegion(new CellRangeAddress(0, 0, 2, 4));
		XSSFFont font = wb.createFont();
		font.setBold(true);
		font.setColor(HSSFColor.BLUE.index);
		XSSFCellStyle style = wb.createCellStyle();
		XSSFCellStyle style2 = wb.createCellStyle();
		style.setFillForegroundColor(HSSFColor.YELLOW.index);
		style.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
		style.setBorderTop((short) 1); // single line border
		style.setBorderBottom((short) 1);
		style.setFont(font);
		// set background for headers
		style2.setFillForegroundColor(HSSFColor.GREY_25_PERCENT.index);
		style2.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
		style2.setBorderTop((short) 1); // single line border
		style2.setBorderBottom((short) 1);
		style2.setFont(font);
		//
		Cell cell1 = rowhead.createCell((short) 0);
		cell1.setCellValue("PROJECT NAME :");
		cell1.setCellStyle(style);
		Cell cell2 = rowhead.createCell((short) 2);
		cell2.setCellValue("JayaBeriConstructions");
		cell2.setCellStyle(style);
		XSSFRow rowhead1 = sheet.createRow((short) 2);
		int j=0;  //loop the cell for columnNames
		for(String Name:ColumnsNames){
		Cell header1 = rowhead1.createCell((short) j);
		header1.setCellValue(Name);
		header1.setCellStyle(style2);
		j++;
			}
		int k = 3;
		int i = 1;
		for (DocumentIndexVw Index : folderDocumentIndex) {

			XSSFRow row = sheet.createRow((short) k);
			row.createCell((short) 0).setCellValue(i);
			row.createCell((short) 1).setCellValue(Index.getDepartment());
			row.createCell((short) 2).setCellValue(Index.getDocumentPath());
			row.createCell((short) 3).setCellValue(Index.getDocumentName());
			row.createCell((short) 4).setCellValue(Index.getPercentageOfCompleted());
			row.createCell((short) 5).setCellValue(Index.getDateOfCompletion());
			row.createCell((short) 6).setCellValue(Index.getDependentActivity());
			row.createCell((short) 7).setCellValue(Index.getMailId());
			k++;
			i++;
		}
		ByteArrayOutputStream outByteStream = new ByteArrayOutputStream();
		wb.write(outByteStream);
		byte[] outArray = outByteStream.toByteArray();
		response.setContentType(MediaType.APPLICATION_OCTET_STREAM_VALUE);
		response.setContentLength(outArray.length);
		response.setHeader("Expires:", "0"); // eliminates browser caching
		response.setHeader("Content-Disposition", "attachment; filename=" + "JayaBeriConstructions" + ".xlsx");
		OutputStream outStream = response.getOutputStream();
		outStream.write(outArray);
		outStream.flush();
	}
}
