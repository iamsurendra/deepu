package com.synergy.bqm.repositories;

import java.util.List;

import com.guvvala.framework.dao.BaseDAO;
import com.synergy.bqm.models.FolderTemplateNames;

public interface FolderTemplateNamesDAO extends BaseDAO<FolderTemplateNames, Integer> {
	
	public Long folderTemplateNameExists(String templateName);
	
	 public List<FolderTemplateNames> getFoldersInfoByFolderIds(List<Integer>templateIds);

}
