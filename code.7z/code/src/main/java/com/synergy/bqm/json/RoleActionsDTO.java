package com.synergy.bqm.json;

import java.util.List;

public class RoleActionsDTO {

	private String menuName;
	private List<MenuActionDTO> menuActions;

	public String getMenuName() {
		return menuName;
	}

	public void setMenuName(String menuName) {
		this.menuName = menuName;
	}

	public List<MenuActionDTO> getMenuActions() {
		return menuActions;
	}

	public void setMenuActions(List<MenuActionDTO> menuActions) {
		this.menuActions = menuActions;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((menuName == null) ? 0 : menuName.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		RoleActionsDTO other = (RoleActionsDTO) obj;
		if (menuName == null) {
			if (other.menuName != null)
				return false;
		} else if (!menuName.equals(other.menuName))
			return false;
		return true;
	}

}
