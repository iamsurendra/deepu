package com.synergy.bqm.repositories;

import java.util.List;

import com.guvvala.framework.dao.BaseDAO;
import com.synergy.bqm.models.FolderDownloadHistory;

public interface FolderDownloadHistoryDAO extends BaseDAO<FolderDownloadHistory, Integer>{
	
	public List<FolderDownloadHistory> getFolderDownloadHistoryBydocumentFolderId(Integer Id);


}
