package com.synergy.bqm.services;

import java.util.List;

import com.synergy.bqm.models.FolderTemplateDeptMapping;

public interface FolderTemplateDeptMappingService {
	
	public void createFolderTemplateMapping(List<FolderTemplateDeptMapping> deptMapping,Integer templateId);
	
	public List<Integer> getTemplateIds(Integer departmentId);

	public List<Integer> getFolderTemplateIds();
}
