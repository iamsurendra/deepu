package com.synergy.bqm.models;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.PostLoad;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.Type;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.guvvala.framework.model.BaseModel;
import com.guvvala.framework.util.DateUtils;
import com.synergy.bqm.json.DocumentChecklistDTO;

@Entity
@Table(name = "document_index")
public class DocumentIndex extends BaseModel implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue
	@Column(name = "id")
	private Integer id;

	@Column(name = "name")
	private String name;

	@Column(name = "hierarchy_Id")
	private Integer hierarchyId;

	@Column(name = "department_Id")
	private Integer departmentId;

	@Column(name = "activity_type")
	private Integer activityType;

	@Column(name = "drawing_no")
	private String drawingNo;

	@Column(name = "project_Id")
	private Integer projectId;

	@Column(name = "reference_drawing")
	private Integer referenceDrawing;

	@Column(name = "reference_drawing_path")
	private String referenceDrawingPath;

	@Column(name = "date_of_completion")
	private Date dateOfCompletion;

	@Column(name = "dependent_activity_Id")
	private Integer dependentActivityId;

	@Column(name = "workflow_Id")
	private Integer workflowId;

	@Column(name = "state_Id")
	private Integer stateId;

	@Column(name = "current_responsible_Id")
	private Integer currentResponsibleId;

	@Column(name = "document_path")
	private String documentPath;

	@Column(name = "document_name")
	private String documentName;

	@Column(name = "in_active")
	@Type(type = "boolean")
	private Boolean inActive;

	@Column(name = "previous_state_user")
	private String previousStateUser;

	@Column(name = "percentage_of_completed")
	private Integer percentageOfCompleted;

	@Column(name = "description")
	private String description;

	@Column(name = "document_id")
	private Integer documentId;

	@Column(name = "activity_stage")
	private Integer activityStage;

	@Column(name = "folder_Id")
	private Integer documentFolderId;

	@Transient
	private String workflowName;

	@Transient
	private String currentState;

	@Transient
	private String completionDate;

	@Transient
	private List<String> referenceDrawingList;

	@Transient
	private List<String> deletedCheckListIds = new ArrayList<>();

	@Transient
	private Integer folderId;

	@Transient
	private List<User> responsibleUsers = new ArrayList<>();

	@Transient
	private List<WorkflowStates> states = new ArrayList<>();

	@Transient
	List<DocumentChecklistDTO> documentChecklist = new ArrayList<>();

	@Transient
	private List<ActivityWorkflowMapping> activityWorkflowMapping = new ArrayList<>();

	@OneToMany(mappedBy = "documentIndex", fetch = FetchType.EAGER)
	@JsonIgnore
	private List<ActivityHistory> activityHistory;

	public DocumentIndex() {

	}

	// getters and setters

	public DocumentIndex(Integer id, String name) {
		super();
		this.id = id;
		this.name = name;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Integer getHierarchyId() {
		return hierarchyId;
	}

	public void setHierarchyId(Integer hierarchyId) {
		this.hierarchyId = hierarchyId;
	}

	public Integer getDepartmentId() {
		return departmentId;
	}

	public void setDepartmentId(Integer departmentId) {
		this.departmentId = departmentId;
	}

	public Integer getActivityType() {
		return activityType;
	}

	public void setActivityType(Integer activityType) {
		this.activityType = activityType;
	}

	public String getDrawingNo() {
		return drawingNo;
	}

	public void setDrawingNo(String drawingNo) {
		this.drawingNo = drawingNo;
	}

	public Integer getProjectId() {
		return projectId;
	}

	public void setProjectId(Integer projectId) {
		this.projectId = projectId;
	}

	public Integer getReferenceDrawing() {
		return referenceDrawing;
	}

	public void setReferenceDrawing(Integer referenceDrawing) {
		this.referenceDrawing = referenceDrawing;
	}

	public Date getDateOfCompletion() {
		return dateOfCompletion;
	}

	public void setDateOfCompletion(Date dateOfCompletion) {
		this.dateOfCompletion = dateOfCompletion;
	}

	public Integer getDependentActivityId() {
		return dependentActivityId;
	}

	public void setDependentActivityId(Integer dependentActivityId) {
		this.dependentActivityId = dependentActivityId;
	}

	public Integer getWorkflowId() {
		return workflowId;
	}

	public void setWorkflowId(Integer workflowId) {
		this.workflowId = workflowId;
	}

	public Integer getStateId() {
		return stateId;
	}

	public void setStateId(Integer stateId) {
		this.stateId = stateId;
	}

	public Integer getCurrentResponsibleId() {
		return currentResponsibleId;
	}

	public void setCurrentResponsibleId(Integer currentResponsibleId) {
		this.currentResponsibleId = currentResponsibleId;
	}

	public String getDocumentPath() {
		return documentPath;
	}

	public void setDocumentPath(String documentPath) {
		this.documentPath = documentPath;
	}

	public String getDocumentName() {
		return documentName;
	}

	public void setDocumentName(String documentName) {
		this.documentName = documentName;
	}

	public Boolean getInActive() {
		return inActive;
	}

	public void setInActive(Boolean inActive) {
		this.inActive = inActive;
	}

	public String getPreviousStateUser() {
		return previousStateUser;
	}

	public void setPreviousStateUser(String previousStateUser) {
		this.previousStateUser = previousStateUser;
	}

	public List<ActivityWorkflowMapping> getActivityWorkflowMapping() {
		return activityWorkflowMapping;
	}

	public void setActivityWorkflowMapping(List<ActivityWorkflowMapping> activityWorkflowMapping) {
		this.activityWorkflowMapping = activityWorkflowMapping;
	}

	public Integer getPercentageOfCompleted() {
		return percentageOfCompleted;
	}

	public void setPercentageOfCompleted(Integer percentageOfCompleted) {
		this.percentageOfCompleted = percentageOfCompleted;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public List<DocumentChecklistDTO> getDocumentChecklist() {
		return documentChecklist;
	}

	public void setDocumentChecklist(List<DocumentChecklistDTO> documentChecklist) {
		this.documentChecklist = documentChecklist;
	}

	public String getReferenceDrawingPath() {
		return referenceDrawingPath;
	}

	public void setReferenceDrawingPath(String referenceDrawingPath) {
		this.referenceDrawingPath = referenceDrawingPath;
	}

	public String getWorkflowName() {
		return workflowName;
	}

	public void setWorkflowName(String workflowName) {
		this.workflowName = workflowName;
	}

	public String getCurrentState() {
		return currentState;
	}

	public void setCurrentState(String currentState) {
		this.currentState = currentState;
	}

	public Integer getFolderId() {
		return folderId;
	}

	public void setFolderId(Integer folderId) {
		this.folderId = folderId;
	}

	public String getCompletionDate() {
		return completionDate;
	}

	public void setCompletionDate(String completionDate) {
		this.completionDate = completionDate;
	}

	public List<String> getDeletedCheckListIds() {
		return deletedCheckListIds;
	}

	public void setDeletedCheckListIds(List<String> deletedCheckListIds) {
		this.deletedCheckListIds = deletedCheckListIds;
	}

	public Integer getDocumentId() {
		return documentId;
	}

	public void setDocumentId(Integer documentId) {
		this.documentId = documentId;
	}

	public List<String> getReferenceDrawingList() {
		return referenceDrawingList;
	}

	public void setReferenceDrawingList(List<String> referenceDrawingList) {
		this.referenceDrawingList = referenceDrawingList;
	}

	public Integer getActivityStage() {
		return activityStage;
	}

	public void setActivityStage(Integer activityStage) {
		this.activityStage = activityStage;
	}

	public Integer getDocumentFolderId() {
		return documentFolderId;
	}

	public void setDocumentFolderId(Integer documentFolderId) {
		this.documentFolderId = documentFolderId;
	}

	public List<ActivityHistory> getActivityHistory() {
		return activityHistory;
	}

	public void setActivityHistory(List<ActivityHistory> activityHistory) {
		this.activityHistory = activityHistory;
	}

	public List<WorkflowStates> getStates() {
		return states;
	}

	public void setStates(List<WorkflowStates> states) {
		this.states = states;
	}

	public List<User> getResponsibleUsers() {
		return responsibleUsers;
	}

	public void setResponsibleUsers(List<User> responsibleUsers) {
		this.responsibleUsers = responsibleUsers;
	}

	@PostLoad
	void postload() {
		setCompletionDate(DateUtils.convertToSimpleDateTimeFormat(getDateOfCompletion()));
	}

}
