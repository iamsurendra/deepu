package com.synergy.bqm.models;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name = "workflow_states")
public class WorkflowStates implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue
	@Column(name = "ID")
	private Integer id;

	@Column(name = "NAME")
	private String name;

	@Column(name = "ROLE_ID")
	private Integer roleId;

	@Column(name = "SEQ_ID")
	private Integer seqId;

	@ManyToOne
	@JoinColumn(name = "WORKFLOW_ID")
	private Workflow workflow;
	

	@Transient
	private List<WorkflowStates> targetStates;

	@Transient
	private String roleName;

	@Transient
	private List<String> workflowStatesNames;
	
	@Transient
	String checklistname;

	public WorkflowStates() {

	}

	// setters & getters


	public WorkflowStates(Integer id, String name) {
		super();
		this.id = id;
		this.name = name;
	}
	
	public Integer getId() {
		return id;
	}


	public String getRoleName() {
		return roleName;
	}

	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Workflow getWorkflow() {
		return workflow;
	}

	public void setWorkflow(Workflow workflow) {
		this.workflow = workflow;
	}

	public Integer getRoleId() {
		return roleId;
	}

	public void setRoleId(Integer roleId) {
		this.roleId = roleId;
	}

	public Integer getSeqId() {
		return seqId;
	}

	public void setSeqId(Integer seqId) {
		this.seqId = seqId;
	}


	public List<String> getWorkflowStatesNames() {
		return workflowStatesNames;
	}

	public void setWorkflowStatesNames(List<String> workflowStatesNames) {
		this.workflowStatesNames = workflowStatesNames;
	}

	public List<WorkflowStates> getTargetStates() {
		return targetStates;
	}

	public void setTargetStates(List<WorkflowStates> targetStates) {
		this.targetStates = targetStates;
	}

	public String getChecklistname() {
		return checklistname;
	}

	public void setChecklistname(String checklistname) {
		this.checklistname = checklistname;
	}


	
	

}
