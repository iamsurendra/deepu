package com.synergy.bqm.models;

import java.io.Serializable;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.PostLoad;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.guvvala.framework.model.BaseModel;
import com.guvvala.framework.util.DateUtils;

/**
 * The persistent class for the project_hierarchy database table.
 * 
 */
@Entity
@Table(name = "project_hierarchy")
@NamedQuery(name = "ProjectHierarchy.findAll", query = "SELECT p FROM ProjectHierarchy p")
public class ProjectHierarchy extends BaseModel implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue
	@Column(name = "project_hierarchy_id")
	private Integer projectHierarchyId;

	@Column(name = "hierarchy_name")
	private String hierarchyName;

	@Column(name = "hierarchy_type")
	private String hierarchyType;

	// bi-directional many-to-one association to Project
	@ManyToOne
	@JsonIgnore
	@JoinColumn(name = "project_id")
	private Project project;

	// bi-directional many-to-one association to ProjectHierarchy
	@ManyToOne
	@JsonIgnore
	@JoinColumn(name = "hierarchy_parent_id")
	private ProjectHierarchy projectHierarchy;

	// bi-directional many-to-one association to ProjectHierarchy
	@OneToMany(mappedBy = "projectHierarchy", cascade = CascadeType.ALL, fetch = FetchType.EAGER, orphanRemoval = true)
	private List<ProjectHierarchy> projectHierarchies;

	@Column(name = "icon")
	private String icon;

	@Transient
	private Integer noOfUnits;

	@Transient
	private Integer parentId;

	@Transient
	private Integer projectId;

	@Transient
	private String createdDt;

	@Transient
	private String updatedDt;

	// getters && setters

	public Integer getProjectHierarchyId() {
		return projectHierarchyId;
	}

	public void setProjectHierarchyId(Integer projectHierarchyId) {
		this.projectHierarchyId = projectHierarchyId;
	}

	public String getHierarchyName() {
		return hierarchyName;
	}

	public void setHierarchyName(String hierarchyName) {
		this.hierarchyName = hierarchyName;
	}

	public String getHierarchyType() {
		return hierarchyType;
	}

	public void setHierarchyType(String hierarchyType) {
		this.hierarchyType = hierarchyType;
	}

	public Project getProject() {
		return project;
	}

	public void setProject(Project project) {
		this.project = project;
	}

	public ProjectHierarchy getProjectHierarchy() {
		return projectHierarchy;
	}

	public void setProjectHierarchy(ProjectHierarchy projectHierarchy) {
		this.projectHierarchy = projectHierarchy;
	}

	public List<ProjectHierarchy> getProjectHierarchies() {
		return projectHierarchies;
	}

	public void setProjectHierarchies(List<ProjectHierarchy> projectHierarchies) {
		this.projectHierarchies = projectHierarchies;
	}

	public String getIcon() {
		return icon;
	}

	public void setIcon(String icon) {
		this.icon = icon;
	}

	public Integer getNoOfUnits() {
		return noOfUnits;
	}

	public void setNoOfUnits(Integer noOfUnits) {
		this.noOfUnits = noOfUnits;
	}

	public Integer getParentId() {
		return parentId;
	}

	public void setParentId(Integer parentId) {
		this.parentId = parentId;
	}

	public Integer getProjectId() {
		return projectId;
	}

	public void setProjectId(Integer projectId) {
		this.projectId = projectId;
	}

	public String getCreatedDt() {
		return createdDt;
	}

	public void setCreatedDt(String createdDt) {
		this.createdDt = createdDt;
	}

	public String getUpdatedDt() {
		return updatedDt;
	}

	public void setUpdatedDt(String updatedDt) {
		this.updatedDt = updatedDt;
	}

	@PostLoad
	void postload() {
		setCreatedDt(DateUtils.convertToSimpleDateTimeFormat(getCreatedDate()));
		setUpdatedDt(DateUtils.convertToSimpleDateTimeFormat(getUpdatedDate()));

	}
}