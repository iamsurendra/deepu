package com.synergy.bqm.repositories;

import java.util.List;
import com.guvvala.framework.dao.BaseDAO;
import com.synergy.bqm.models.WorkflowType;

public interface WorkflowTypeDAO extends BaseDAO<WorkflowType, Integer> {
	
	public List<String> getWorkflowTypes();

	public List<String> getSubTypesByTypes(String type);

	public List<WorkflowType> getSubTypesByWorkflowType(String type);
	
	public List<WorkflowType> getWorkflowTypeInfoById(List<Integer> Ids);

}
