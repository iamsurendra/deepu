package com.synergy.bqm.models;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class FolderDocumentHistoryVwKey implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Column(name = "document_id")
	private Integer documentId;

	@Column(name = "document_folder_id")
	private Long documentFolderId;

	@Column(name = "LAST_UPD_DT")
	private Date lastUpdatedDT;

	@Column(name = "REVISION_TYPE")
	private Long revisionType;

	public Integer getDocumentId() {
		return documentId;
	}

	public void setDocumentId(Integer documentId) {
		this.documentId = documentId;
	}

	public Long getDocumentFolderId() {
		return documentFolderId;
	}

	public void setDocumentFolderId(Long documentFolderId) {
		this.documentFolderId = documentFolderId;
	}

	public Date getLastUpdatedDT() {
		return lastUpdatedDT;
	}

	public void setLastUpdatedDT(Date lastUpdatedDT) {
		this.lastUpdatedDT = lastUpdatedDT;
	}

	public Long getRevisionType() {
		return revisionType;
	}

	public void setRevisionType(Long revisionType) {
		this.revisionType = revisionType;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((documentFolderId == null) ? 0 : documentFolderId.hashCode());
		result = prime * result + ((documentId == null) ? 0 : documentId.hashCode());
		result = prime * result + ((lastUpdatedDT == null) ? 0 : lastUpdatedDT.hashCode());
		result = prime * result + ((revisionType == null) ? 0 : revisionType.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		FolderDocumentHistoryVwKey other = (FolderDocumentHistoryVwKey) obj;
		if (documentFolderId == null) {
			if (other.documentFolderId != null)
				return false;
		} else if (!documentFolderId.equals(other.documentFolderId))
			return false;
		if (documentId == null) {
			if (other.documentId != null)
				return false;
		} else if (!documentId.equals(other.documentId))
			return false;
		if (lastUpdatedDT == null) {
			if (other.lastUpdatedDT != null)
				return false;
		} else if (!lastUpdatedDT.equals(other.lastUpdatedDT))
			return false;
		if (revisionType == null) {
			if (other.revisionType != null)
				return false;
		} else if (!revisionType.equals(other.revisionType))
			return false;
		return true;
	}

}
