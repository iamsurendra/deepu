package com.synergy.bqm.json;

import java.util.List;

import com.synergy.bqm.models.Designation;

public class DesignationDTO {

	List<Designation> designationList;
	List<Integer> deletedIds;

	public List<Integer> getDeletedIds() {
		return deletedIds;
	}

	public void setDeletedIds(List<Integer> deletedIds) {
		this.deletedIds = deletedIds;
	}

	public List<Designation> getDesignationList() {
		return designationList;
	}

	public void setDesignationList(List<Designation> designationList) {
		this.designationList = designationList;
	}

}
