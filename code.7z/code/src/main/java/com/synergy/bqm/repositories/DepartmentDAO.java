package com.synergy.bqm.repositories;

import java.util.List;

import com.guvvala.framework.dao.BaseDAO;
import com.synergy.bqm.models.Department;

public interface DepartmentDAO extends BaseDAO<Department, Integer>{
	
	public List<String> getDepartmentNames();
	
	public List<Department> getDepartmentInfoById(List<Integer> Ids);

}
