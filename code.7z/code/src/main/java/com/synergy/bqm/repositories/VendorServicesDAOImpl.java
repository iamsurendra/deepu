package com.synergy.bqm.repositories;

import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.guvvala.framework.dao.BaseDAOImpl;
import com.synergy.bqm.models.VendorServices;

@Repository
public class VendorServicesDAOImpl extends BaseDAOImpl<VendorServices, Integer> implements VendorServicesDAO {

	public VendorServicesDAOImpl() {
		super(VendorServices.class);
	}

	public List<VendorServices> getVendorServiceInfoById(List<Long> Ids) {
		CriteriaBuilder builder = entityManager.getCriteriaBuilder();
		CriteriaQuery<VendorServices> criteriaQuery = builder.createQuery(VendorServices.class);
		Root<VendorServices> root = criteriaQuery.from(VendorServices.class);
		criteriaQuery.select(root).distinct(true);
		criteriaQuery.where(builder.not(builder.in(root.get("vendorServiceId")).value(Ids)));
		return entityManager.createQuery(criteriaQuery).getResultList();

	}

}
