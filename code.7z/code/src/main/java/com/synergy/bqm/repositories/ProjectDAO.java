package com.synergy.bqm.repositories;

import java.util.List;

import com.guvvala.framework.dao.BaseDAO;
import com.synergy.bqm.models.Project;

public interface ProjectDAO extends BaseDAO<Project, Integer>{
	
	public List<Project> getAllArchiveProjects();
		
	public Long projectNameExists(String projectName);
	
	public Long countOfProjects();
	
	public List<Project> getProjectInfoByClientId(Integer id);
	
	public List<Project> getProjectInfoByStageName(List<String> Names);
	
	public List<Project> getProjectInfoByStatus(List<String> statusNames);
	
	public List<Project> getProjectInfoByTypes(List<String> types);
	
	public String getProjectNameById(Integer id);
}
