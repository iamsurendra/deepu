package com.synergy.bqm.repositories;

import java.util.List;

import com.guvvala.framework.dao.BaseDAO;
import com.synergy.bqm.models.ProjectType;

public interface ProjectTypeDAO extends BaseDAO<ProjectType, Integer>{
	
	public List<String> getProjectTypes();

	public List<String> getSubTypesByTypes(String type);

	public List<ProjectType> getSubTypesByProjectType(String type);
	
	public List<ProjectType> getProjectTypeInfoById(List<Integer> Ids);
}
