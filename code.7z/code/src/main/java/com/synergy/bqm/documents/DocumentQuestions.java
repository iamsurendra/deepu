package com.synergy.bqm.documents;

public class DocumentQuestions {
	
	
	private String lineItemQuestion;
	
	private boolean answer;

	public String getLineItemQuestion() {
		return lineItemQuestion;
	}

	public void setLineItemQuestion(String lineItemQuestion) {
		this.lineItemQuestion = lineItemQuestion;
	}

	public boolean isAnswer() {
		return answer;
	}

	public void setAnswer(boolean answer) {
		this.answer = answer;
	}
	
	
	
	
	

}
