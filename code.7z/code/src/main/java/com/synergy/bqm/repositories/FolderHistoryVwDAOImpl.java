package com.synergy.bqm.repositories;

import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.guvvala.framework.dao.BaseDAOImpl;
import com.synergy.bqm.models.FolderHistoryVw;
import com.synergy.bqm.models.FolderHistoryVwKey;

@Repository
public class FolderHistoryVwDAOImpl extends BaseDAOImpl<FolderHistoryVw, FolderHistoryVwKey>
		implements FolderHistoryVwDAO {

	public FolderHistoryVwDAOImpl() {
		super(FolderHistoryVw.class);
		// TODO Auto-generated constructor stub
	}
	
	
	public List<FolderHistoryVw> getFolderHistoryByFolderId(Integer folderId){
		CriteriaBuilder builder = entityManager.getCriteriaBuilder();
		CriteriaQuery<FolderHistoryVw> criteriaQuery = builder.createQuery(FolderHistoryVw.class);
		Root<FolderHistoryVw> root = criteriaQuery.from(FolderHistoryVw.class);
		criteriaQuery.select(root)
				.where(builder.equal(root.get("folderId"), folderId));
		return entityManager.createQuery(criteriaQuery).getResultList();
		
		
	}

	public List<FolderHistoryVw> getFolderHistoryByParentId(Integer parentId){
		CriteriaBuilder builder = entityManager.getCriteriaBuilder();
		CriteriaQuery<FolderHistoryVw> criteriaQuery = builder.createQuery(FolderHistoryVw.class);
		Root<FolderHistoryVw> root = criteriaQuery.from(FolderHistoryVw.class);
		criteriaQuery.select(root).where(builder.equal(root.get("parentFolderId"), parentId));
		return entityManager.createQuery(criteriaQuery).getResultList();
		
	}
}
