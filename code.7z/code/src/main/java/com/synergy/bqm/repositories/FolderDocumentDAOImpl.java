package com.synergy.bqm.repositories;

import java.util.List;

import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.guvvala.framework.dao.BaseDAOImpl;
import com.synergy.bqm.models.FolderDocument;

@Repository
public class FolderDocumentDAOImpl extends BaseDAOImpl<FolderDocument, Integer> implements FolderDocumentDAO {

	public FolderDocumentDAOImpl() {
		super(FolderDocument.class);
		// TODO Auto-generated constructor stub
	}

	public Long checkDocumentNameExisit(Integer documentfolderid, String documentName, Double version) {
		TypedQuery<Long> query = entityManager
				.createQuery(
						"SELECT count(*) from FolderDocument  where document_folder_id ='" + documentfolderid
								+ "' and documentName ='" + documentName + "' and version ='" + version + "'",
						Long.class);

		return query.getSingleResult();
	}

	public FolderDocument getfolderDocumentObjcet(Integer documentfolderid, String documentName) {
		TypedQuery<FolderDocument> query = entityManager
				.createQuery("SELECT f from FolderDocument f where document_folder_id ='" + documentfolderid
						+ "' and documentName ='" + documentName + "'", FolderDocument.class);

		return query.getSingleResult();
	}

	public List<FolderDocument> getFolderDocumentInfo(Integer Id) {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<FolderDocument> criteriaQuery = criteriaBuilder.createQuery(FolderDocument.class);
		Root<FolderDocument> root = criteriaQuery.from(FolderDocument.class);
		criteriaQuery.select(root).where(criteriaBuilder.equal(root.get("folder").get("folderId"), Id));
		return entityManager.createQuery(criteriaQuery).getResultList();

	}
	
	public List<Integer> getFolderDocumentIds(Integer Id) {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<Integer> criteriaQuery = criteriaBuilder.createQuery(Integer.class);
		Root<FolderDocument> root = criteriaQuery.from(FolderDocument.class);
		criteriaQuery.select(root.get("documentId")).where(criteriaBuilder.equal(root.get("folder").get("folderId"), Id));
		return entityManager.createQuery(criteriaQuery).getResultList();

	}

	@Override
	public FolderDocument getlistOfDocumentUrls(Integer Ids) {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<FolderDocument> criteriaQuery = criteriaBuilder.createQuery(FolderDocument.class);
		Root<FolderDocument> addressRoot = criteriaQuery.from(FolderDocument.class);
		criteriaQuery.select(addressRoot);
		criteriaQuery.where(criteriaBuilder.equal(addressRoot.get("documentId"), Ids));
		return entityManager.createQuery(criteriaQuery).getSingleResult();
	}
	
	public List<String> getListOfDocumentIds(List<Integer> Ids){
		CriteriaBuilder builder = entityManager.getCriteriaBuilder();
		CriteriaQuery<String> criteriaQuery = builder.createQuery(String.class);
		Root<FolderDocument> root = criteriaQuery.from(FolderDocument.class);
		criteriaQuery.select(root.get("documentLink"));
		criteriaQuery.where(root.get("documentId").in(Ids));
		return entityManager.createQuery(criteriaQuery).getResultList();
		
	}

	public List<Double> getVersion(Integer documentfolderid, String documentName) {
		TypedQuery<Double> query = entityManager
				.createQuery(
						"SELECT version from FolderDocument  where document_folder_id ='" + documentfolderid
								+ "' and documentName ='" + documentName + "' ORDER BY version DESC ",
								Double.class);

		return query.getResultList();
	}

	public List<FolderDocument> listOfFolderDocuments(Integer documentfolderid, String documentName) {
		TypedQuery<FolderDocument> query = entityManager
				.createQuery(
						"SELECT f from FolderDocument f where document_folder_id ='" + documentfolderid
								+ "' and documentName ='" + documentName + "' ORDER BY version DESC ",
								FolderDocument.class);

		return query.getResultList();
	}
}
