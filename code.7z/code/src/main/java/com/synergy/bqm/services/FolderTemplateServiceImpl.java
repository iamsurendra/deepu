package com.synergy.bqm.services;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.guvvala.framework.errorHandler.AppException;
import com.synergy.bqm.constants.MessagesEnum;
import com.synergy.bqm.models.FolderTemplate;
import com.synergy.bqm.models.FolderTemplateNames;
import com.synergy.bqm.repositories.FolderTemplateDAO;
import com.synergy.bqm.repositories.FolderTemplateNamesDAO;

@Service("folderTemplateService")
public class FolderTemplateServiceImpl implements FolderTemplateService {

	@Autowired
	FolderTemplateDAO folderTemplateDAO;
	
	@Autowired
	FolderTemplateNamesDAO folderTemplateNamesDAO;

	/*
	 * To Create Folder and child Folder For Template
	 */
	@Transactional
	public FolderTemplate createFolder(FolderTemplate folderTemplate) {
		if (folderTemplate.getParentId() == 0) {

			Long count = folderTemplateDAO.checkFolderNameExists(folderTemplate.getTemplateId(),
					folderTemplate.getFolderName());
			if (count == null || count == 0) {
				return folderTemplateDAO.create(folderTemplate);
			} else {
				throw new AppException(MessagesEnum.DUPLICATE_FOLDER_NAME);
			}
		} else {
			Long count = folderTemplateDAO.checkChildFolderNameExits(
					folderTemplate.getParentId(), folderTemplate.getFolderName());
			if (count == null || count == 0) {
				List<FolderTemplate> parentFolder = folderTemplateDAO.getFolderInfoByFolderIdAndTemplateId(
						folderTemplate.getTemplateId(), folderTemplate.getParentId());
				FolderTemplate firstParent = parentFolder.get(0);
				FolderTemplate child = new FolderTemplate();
			child.setTemplateId(null);
				child.setFolderTemplate(firstParent);
				child.setFolderName(folderTemplate.getFolderName());
				return folderTemplateDAO.create(child);

			} else {
				throw new AppException(MessagesEnum.DUPLICATE_FOLDER_NAME);

			}
		}
	}

	 
	 
	 
	/*
	 * Update FolderName and childFolderName
	 */ @Transactional
	public FolderTemplate updateFolder(FolderTemplate folderTemplate) {
		if (folderTemplate.getParentId() == 0) {
			Long count = folderTemplateDAO.checkFolderNameExists(folderTemplate.getTemplateId(),
					folderTemplate.getFolderName());
			if (count == null || count == 0) {
				FolderTemplate originalObject = folderTemplateDAO.findOne(folderTemplate.getFolderId());
				originalObject.setFolderName(folderTemplate.getFolderName());
				return folderTemplateDAO.update(originalObject);
			} else {
				throw new AppException(MessagesEnum.DUPLICATE_FOLDER_NAME);

			}
		} else {
			Long count = folderTemplateDAO.checkChildFolderNameExits(
					folderTemplate.getParentId(), folderTemplate.getFolderName());
			if (count == null || count == 0) {
				FolderTemplate originalObject = folderTemplateDAO.findOne(folderTemplate.getFolderId());
				originalObject.setFolderName(folderTemplate.getFolderName());
				return folderTemplateDAO.update(originalObject);

			} else {
				throw new AppException(MessagesEnum.DUPLICATE_FOLDER_NAME);

			}
		}
	}

	

	/*
	 * Retrieving Child Folders By FolderId and Temp
	 */ @Transactional
	public List<FolderTemplate> getChildFolderNameByTemplateId(Integer templateId, Integer folderId) {
		return folderTemplateDAO.getChildFolderNameByTemplateId(templateId, folderId);

	}
	 
	 @Transactional
	 public List<FolderTemplate> getChildFolderByFolderId(Integer folderId){
		return folderTemplateDAO.getFolderInfoByParentId(folderId);
		 
	 }

	/*
	 * Retrieving FolderName By TemplateId
	 */
	@Transactional
	public List<FolderTemplate> getFolderNameByTemplateId(Integer templateId) {
		return folderTemplateDAO.getFolderNameByTemplateId(templateId);

	}

	/*
	 * Child Folder Moving to another Parent Folder
	 */
	@Transactional
	public FolderTemplate folderMoving(FolderTemplate folderTemplate) {
		FolderTemplate folder = folderTemplateDAO.getFolderInfoByFolderId(folderTemplate.getFolderId());
		FolderTemplate parentFolderTemplate = folderTemplateDAO.findOne(folderTemplate.getParentId());
		if (folderTemplateDAO.getFoldeNamesByParentIds(parentFolderTemplate.getFolderId())
				.contains(folder.getFolderName())) {
			throw new AppException(MessagesEnum.DUPLICATE_FOLDER_NAME);

		}
		folder.setFolderTemplate(parentFolderTemplate);
		return folderTemplateDAO.update(folder);

	}
/*
 * 	Delete Folders
*/	
	@Transactional
	public void deleteFolder(Integer folderId) {
		FolderTemplate originalEntity = folderTemplateDAO.findOne(folderId);
		folderTemplateDAO.delete(originalEntity);
		
	}

	@Transactional
	public void reCreatFolderTemplate(Integer templateId, String templateName) {
		Long count = folderTemplateNamesDAO.folderTemplateNameExists(templateName);
		if (count>0) {
			throw new AppException(MessagesEnum.DUPLICATE_TEMPLATE_NAME);
		}
		FolderTemplateNames folderTemplateNames = new FolderTemplateNames();
		folderTemplateNames.setTemplateName(templateName);
		FolderTemplateNames templateNames = folderTemplateNamesDAO.create(folderTemplateNames);
		List<FolderTemplate> parentFolders = folderTemplateDAO.getFirstLevelFolderInfoByTemplateId(templateId);
		for (FolderTemplate folders : parentFolders) {
			FolderTemplate folderTemplate = new FolderTemplate();
			folderTemplate.setFolderName(folders.getFolderName());
			folderTemplate.setTemplateId(templateNames.getTemplateId());
		 // folderTemplate.setFolderTemplates(folders.getFolderTemplates());
		 //   folderTemplate.setFolderTemplate(folders.getFolderTemplate());
			FolderTemplate parentObject = folderTemplateDAO.create(folderTemplate);
			createChild(folders, templateNames, parentObject);
		}

	}

	public void createChild(FolderTemplate folders, FolderTemplateNames templateNames, FolderTemplate parentObject) {
		for (FolderTemplate folderTemplate : folders.getFolderTemplates()) {
			FolderTemplate childFolder = new FolderTemplate();
			childFolder.setFolderName(folderTemplate.getFolderName());
			childFolder.setTemplateId(null);
			childFolder.setFolderTemplate(parentObject);
			FolderTemplate folder = folderTemplateDAO.create(childFolder);
			if (!folderTemplate.getFolderTemplates().isEmpty()) {
				createChild(folderTemplate, templateNames, folder);
			}
		}
	}
	
	@Transactional
	public List<FolderTemplate> getFolderInfoListByFolderId(Integer folderId) {
		return folderTemplateDAO.getFolderInfoListByFolderId(folderId);

	}
	
	@Transactional
	public List<String>getFoldeNamesByParentIds (Integer parentFolderId){
		
		return folderTemplateDAO.getFoldeNamesByParentIds(parentFolderId);
	}

}
