package com.synergy.bqm.services;

import java.util.List;
import java.util.Map;

import com.synergy.bqm.models.QuestionOption;

public interface QuestionOptionService {

	
	public void createquestionOption(List<QuestionOption> questionOption,List<Long> deletedIds);
	
	public List<QuestionOption> findAllQuestionOption();
	
	public List<QuestionOption> getQuestionOptionByType(String Type);
	
	public List<QuestionOption> getDistinctQuestionType();
	
	public List<String> getQuestionOptionByQuestionType(String questionType);
	
	public List<String> getQuestionTypes();
	
	public Map<String,List<String>> getQuestionAnsInfo();
}
