package com.synergy.bqm.json;

import java.util.*;

import com.synergy.bqm.models.Folder;
import com.synergy.bqm.models.FolderDocument;
import com.synergy.bqm.models.FolderTemplate;

public class FolderTreeDTO {

	private String label;
	private String icon;
	private FolderTemplate data;
	private Folder folderData;
	private FolderDocument documentData;
	private boolean leaf;
	private boolean expanded;
	private boolean selectable;
	private Set<FolderTreeDTO> children;

	// getters and setters
	public String getLabel() {
		return label;
	}

	public void setLabel(String label) {
		this.label = label;
	}

	public String getIcon() {
		return icon;
	}

	public void setIcon(String icon) {
		this.icon = icon;
	}

	public FolderTemplate getData() {
		return data;
	}

	public void setData(FolderTemplate data) {
		this.data = data;
	}

	public Folder getFolderData() {
		return folderData;
	}

	public void setFolderData(Folder folderData) {
		this.folderData = folderData;
	}

	public boolean isLeaf() {
		return leaf;
	}

	public void setLeaf(boolean leaf) {
		this.leaf = leaf;
	}

	public Set<FolderTreeDTO> getChildren() {
		return children;
	}

	public void setChildren(Set<FolderTreeDTO> children) {
		this.children = children;
	}

	public boolean isExpanded() {
		return expanded;
	}

	public void setExpanded(boolean expanded) {
		this.expanded = expanded;
	}

	public boolean isSelectable() {
		return selectable;
	}

	public void setSelectable(boolean selectable) {
		this.selectable = selectable;
	}

	public FolderDocument getDocumentData() {
		return documentData;
	}

	public void setDocumentData(FolderDocument documentData) {
		this.documentData = documentData;
	}

}
