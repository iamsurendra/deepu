package com.synergy.bqm.services;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.guvvala.framework.util.DateUtils;
import com.synergy.bqm.models.FolderDocumentHistoryVw;
import com.synergy.bqm.models.FolderDownloadHistory;
import com.synergy.bqm.repositories.FolderDocumentHistoryViewDAO;
import com.synergy.bqm.repositories.FolderDownloadHistoryDAO;

@Service("folderDocumentHistoryVwService")
public class FolderDocumentHistoryVwServiceImpl implements FolderDocumentHistoryVwService {

	@Autowired
	FolderDocumentHistoryViewDAO folderDocumentHistoryViewDAO;

	@Autowired
	FolderDownloadHistoryDAO folderDownloadHistoryDAO;

	@Transactional
	public List<FolderDocumentHistoryVw> getFolderDocumentHistoryByFolderId(Integer folderId) {

		List<FolderDocumentHistoryVw> folderDocumentHistoryVw = folderDocumentHistoryViewDAO
				.getFolderDocumentHistoryByFolderId(folderId);
		List<FolderDownloadHistory> downloadHistories = folderDownloadHistoryDAO
				.getFolderDownloadHistoryBydocumentFolderId(folderId);
		for (FolderDownloadHistory downloadHistory : downloadHistories) {
			FolderDocumentHistoryVw documentHistoryVw = new FolderDocumentHistoryVw();
			documentHistoryVw.setDocumentId(downloadHistory.getDocumentId());
			documentHistoryVw.setDocumentName(downloadHistory.getDocumentName());
			documentHistoryVw.setDocumentDescription(downloadHistory.getDocumentDescription());
			documentHistoryVw.setRevisionType(3l);
			documentHistoryVw.setFileType(downloadHistory.getFileType());
			documentHistoryVw.setDocumentFolderId(downloadHistory.getDocumentFolderId());
			documentHistoryVw.setLastUpdatedDT(downloadHistory.getDownloadedDate());
			documentHistoryVw.setVersion(downloadHistory.getVersion());
			documentHistoryVw.setUpdatedDt(DateUtils.convertToSimpleDateTimeFormat(downloadHistory.getDownloadedDate()));
			documentHistoryVw.setLastUpdatedBy(downloadHistory.getDownloadedBy());
			folderDocumentHistoryVw.add(documentHistoryVw);
		}
		return folderDocumentHistoryVw;
	}
}
