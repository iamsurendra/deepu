package com.synergy.bqm.controllers;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.synergy.bqm.services.UserService;

@RestController
@RequestMapping("/forgotPassword")
public class ForgotPasswordController {

	@Autowired
	UserService userService;
	
	
	
	/*
	 * forgot password
	 */
	@RequestMapping(value = "/resetPassword", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	public Integer forgotPassword(@RequestBody Map<String, String> userJson) {
		return userService.forgotPassword(userJson.get("email"), userJson.get("userName"));
	}

}
