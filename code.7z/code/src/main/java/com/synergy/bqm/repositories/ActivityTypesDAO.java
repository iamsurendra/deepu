package com.synergy.bqm.repositories;

import java.util.List;

import com.guvvala.framework.dao.BaseDAO;
import com.synergy.bqm.models.ActivityTypes;


public interface ActivityTypesDAO extends BaseDAO<ActivityTypes, Integer>{

	
	public List<ActivityTypes> getActivityTypesById(List<Integer> Ids);
	
	public void deleteActivitesByIds(List<Integer> Ids) ;
	
	
}
