package com.synergy.bqm.services;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.guvvala.framework.errorHandler.AppException;
import com.synergy.bqm.constants.MessagesEnum;
import com.synergy.bqm.models.ProjectHierarchy;
import com.synergy.bqm.repositories.ProjectDAO;
import com.synergy.bqm.repositories.ProjectHierarchyDAO;

@Service("projectHierarchyService")
public class ProjectHierarchyServiceImpl implements ProjectHierarchyService {

	@Autowired
	ProjectHierarchyDAO projectHierarchyDAO;

	@Autowired
	ProjectDAO projectDAO;

	@Transactional
	public List<ProjectHierarchy> createProjectHierarchy(ProjectHierarchy projectHierarchy) {
		List<ProjectHierarchy> projectHierarchyList = new ArrayList<ProjectHierarchy>();

		List<ProjectHierarchy> hierarchies = projectHierarchyDAO.getHierarchyIfo(projectHierarchy.getHierarchyName(),
				projectHierarchy.getParentId(), projectHierarchy.getProjectId());
		Integer count = hierarchies.size() + 1;

		if (!hierarchies.isEmpty()) {
			for (int i = 1; i <= projectHierarchy.getNoOfUnits(); i++) {

				ProjectHierarchy hierarchy = new ProjectHierarchy();
				hierarchy.setHierarchyName(projectHierarchy.getHierarchyName() +"_"+ Integer.toString(count));
				hierarchy.setHierarchyType(projectHierarchy.getHierarchyName());
				if (projectHierarchy.getParentId() != null) {
					hierarchy.setProjectHierarchy(projectHierarchyDAO.findOne(projectHierarchy.getParentId()));
				}
				hierarchy.setProjectHierarchies(new ArrayList<>());
				hierarchy.setProject(projectDAO.findOne(projectHierarchy.getProjectId()));
				projectHierarchyList.add(projectHierarchyDAO.create(hierarchy));
				count++;
			}
		} else {
			for (int i = 1; i <= projectHierarchy.getNoOfUnits(); i++) {
				ProjectHierarchy hierarchy = new ProjectHierarchy();
				hierarchy.setHierarchyName(projectHierarchy.getHierarchyName() +"_"+ Integer.toString(i));
				hierarchy.setHierarchyType(projectHierarchy.getHierarchyName());
				if (projectHierarchy.getParentId() != null) {
					hierarchy.setProjectHierarchy(projectHierarchyDAO.findOne(projectHierarchy.getParentId()));
				}
				hierarchy.setProjectHierarchies(new ArrayList<>());
				hierarchy.setProject(projectDAO.findOne(projectHierarchy.getProjectId()));
				projectHierarchyList.add(projectHierarchyDAO.create(hierarchy));
			}
		}
		return projectHierarchyList;
	}

	@Transactional
	public void updateHierarchy(ProjectHierarchy projectHierarchy) {
		ProjectHierarchy hierarchy = projectHierarchyDAO.findOne(projectHierarchy.getProjectHierarchyId());
		List<ProjectHierarchy> hierarchies = projectHierarchyDAO.findExistingHierarchyName(
				projectHierarchy.getHierarchyName(), projectHierarchy.getParentId(),
				hierarchy.getProject().getProjectId());
		if (!hierarchies.isEmpty()) {
			throw new AppException(MessagesEnum.DUPLICATE_ENTRY);
		}
		hierarchy.setHierarchyName(projectHierarchy.getHierarchyName());
		hierarchy.setHierarchyType(projectHierarchy.getHierarchyType());

		projectHierarchyDAO.update(hierarchy);
	}

	@Transactional
	public ProjectHierarchy getProjectHierarchyByHierarchyId(Integer id) {
		return projectHierarchyDAO.findOne(id);
	}

	@Transactional
	public void deleteHierarchyById(Integer Id) {
		ProjectHierarchy hierarchy = projectHierarchyDAO.findOne(Id);
		hierarchy.setProjectHierarchy(null);
		hierarchy.setProject(null);
		projectHierarchyDAO.delete(hierarchy);
	}

	@Override
	@Transactional
	public List<ProjectHierarchy> getProjectHierarchyByProjectId(Integer projectId) {
		return projectHierarchyDAO.getProjectHierarchyInfoByProjectId(projectId);
	}

	@Transactional
	public List<String> getHierarchyList(Integer hierarchyId) {
		List<String> levels = new ArrayList<>();
		getParentHierarchy(hierarchyId, levels);
		Collections.reverse(levels);
		return levels;
	}

	/*
	 * Getting Hierarchy from child to parent
	 */
	private List<String> getParentHierarchy(Integer Id, List<String> levels) {
		ProjectHierarchy parentHierarchy = projectHierarchyDAO.findOne(Id);
		levels.add(parentHierarchy.getHierarchyName());

		if (parentHierarchy.getProjectHierarchy() != null) {
			getParentHierarchy(parentHierarchy.getProjectHierarchy().getProjectHierarchyId(), levels);
		}
		return levels;

	}

}
