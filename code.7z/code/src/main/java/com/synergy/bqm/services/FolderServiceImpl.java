package com.synergy.bqm.services;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Set;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.fileupload.disk.DiskFileItem;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.commons.CommonsMultipartFile;
import com.guvvala.framework.errorHandler.AppException;
import com.guvvala.framework.util.DateUtils;
import com.guvvala.framework.util.ThreadLocalUtil;
import com.mongodb.gridfs.GridFSDBFile;
import com.synergy.bqm.constants.MessagesEnum;
import com.synergy.bqm.json.FolderTreeDTO;
import com.synergy.bqm.models.DocumentIndex;
import com.synergy.bqm.models.Folder;
import com.synergy.bqm.models.FolderDepartmentMapping;
import com.synergy.bqm.models.FolderDocument;
import com.synergy.bqm.models.FolderDownloadHistory;
import com.synergy.bqm.models.FolderTemplateDeptMapping;
import com.synergy.bqm.models.Project;
import com.synergy.bqm.models.ProjectMember;
import com.synergy.bqm.models.WorkflowStates;
import com.synergy.bqm.mongoRepositories.FileMongoDAO;
import com.synergy.bqm.repositories.DocumentIndexDAO;
import com.synergy.bqm.repositories.FolderDAO;
import com.synergy.bqm.repositories.FolderDepartmentMappingDAO;
import com.synergy.bqm.repositories.FolderDocumentDAO;
import com.synergy.bqm.repositories.FolderDownloadHistoryDAO;
import com.synergy.bqm.repositories.FolderTemplateDAO;
import com.synergy.bqm.repositories.FolderTemplateDeptMappingDAO;
import com.synergy.bqm.repositories.FolderTemplateNamesDAO;
import com.synergy.bqm.repositories.ProjectDAO;
import com.synergy.bqm.repositories.ProjectMemberDAO;
import com.synergy.bqm.repositories.WorkflowStatesDAO;

@Service("folderService")
public class FolderServiceImpl implements FolderService {

	@Autowired
	FolderDAO folderDAO;

	@Autowired
	FolderDocumentDAO folderDocumentDAO;

	@Autowired
	FolderTemplateDAO folderTemplateDAO;

	@Autowired
	FolderTemplateNamesDAO folderTemplateNamesDAO;

	@Autowired
	ProjectDAO projectDAO;

	@Autowired
	FolderDownloadHistoryDAO dolderDownloadHistoryDAO;

	@Autowired
	FileMongoDAO fileMongoDAO;

	@Autowired
	ProjectMemberDAO projectMemberDAO;

	@Autowired
	FolderTemplateDeptMappingDAO folderTemplateDeptMappingDAO;

	@Autowired
	FolderDepartmentMappingDAO folderDepartmentMappingDAO;
	
	@Autowired
	WorkflowStatesDAO workflowStatesDAO;
	
	@Autowired
	DocumentIndexDAO documentIndexDAO;

	@Transactional
	public Folder createFolder(Folder folder) {
		Folder object = new Folder();
		object.setFolderName(folder.getFolderName());
		Integer departmentId = getDepartmentId(folder.getProjectId());

		if (folder.getParentId() != null) {
			if (folderDAO.checkChildFolderNameExits(folder.getProjectId(), folder.getParentId(),
					folder.getFolderName()) > 0) {
				throw new AppException(MessagesEnum.DUPLICATE_FOLDER_NAME);

			}
			Folder parentObject = folderDAO.findOne(folder.getParentId());
			object.setFolder(parentObject);
		}
		if (folder.getParentId() == null) {
			List<Integer> parentIds = folderDepartmentMappingDAO.getFolderIds(departmentId);
			if (!parentIds.isEmpty()) {
				if (folderDAO.checkFolderNameExists(folder.getProjectId(), folder.getFolderName(), parentIds) > 0) {
					throw new AppException(MessagesEnum.DUPLICATE_FOLDER_NAME);
				}
			} else {
				if (folderDAO.checkFolderNameExists(folder.getProjectId(), folder.getFolderName()) > 0) {
					throw new AppException(MessagesEnum.DUPLICATE_FOLDER_NAME);
				}
			}
		}
		Project project = projectDAO.findOne(folder.getProjectId());
		object.setProject(project);
		object.setProjectId(folder.getProjectId());

		Folder folderObject = folderDAO.create(object);
		if (folder.getParentId() == null) {
			FolderDepartmentMapping departmentMapping = new FolderDepartmentMapping();
			departmentMapping.setDepartmentId(departmentId);
			departmentMapping.setFolderId(folderObject.getFolderId());
			folderDepartmentMappingDAO.create(departmentMapping);
		}
		project.setUpdatedDate(DateUtils.getCurrentISTDateTime());
		project.setUpdatedBy(ThreadLocalUtil.getUserName());
		projectDAO.update(project);
		return folderObject;
	}

	@Transactional
	public Folder updateFolder(Folder folder) {
		Folder updateFolder = folderDAO.findOne(folder.getFolderId());
		updateFolder.setFolderName(folder.getFolderName());
		Folder Object = folderDAO.update(updateFolder);
		Project project = projectDAO.findOne(folder.getProjectId());
		project.setUpdatedDate(DateUtils.getCurrentISTDateTime());
		project.setUpdatedBy(ThreadLocalUtil.getUserName());
		return Object;

	}

	@Transactional
	public Folder getFolderByFolderId(Integer folderId) {
		return folderDAO.findOne(folderId);
	}

	@Transactional
	public String getFolderName(Integer folderId) {
		return folderDAO.findOne(folderId).getFolderName();
	}

	@Transactional
	public List<Folder> getTemplateFolders() {
		return folderDAO.getTemplateFolders();
	}

	@Transactional
	public void deleteFolder(Folder folder) {

		if (!folder.getFolders().isEmpty()) {
			// deleting child and documents
			deleteChildFolderAndDocument(folder.getFolders());
		}
		List<FolderDocument> document = folderDocumentDAO.getFolderDocumentInfo(folder.getFolderId());
		if (!document.isEmpty()) {
			for (FolderDocument folderDocument : document) {
				// deleting document in mongoDb
				fileMongoDAO.deletefiles(folderDocument.getDocumentLink());
				folderDocumentDAO.delete(folderDocument);
			}
		}
		Integer projectId = folder.getProject().getProjectId();
		folder.setFolder(null);
		folder.setProject(null);
		folderDAO.delete(folder);
		Integer departmentId = getDepartmentId(projectId);
		if (folderDepartmentMappingDAO.getFolderIds(departmentId).contains(folder.getFolderId())) {
			folderDepartmentMappingDAO
					.delete(folderDepartmentMappingDAO.getDeletedFolder(folder.getFolderId(), departmentId));
		}
		Project project = projectDAO.findOne(projectId);
		project.setUpdatedDate(DateUtils.getCurrentISTDateTime());
		project.setUpdatedBy(ThreadLocalUtil.getUserName());
		projectDAO.update(project);

	}

	public void deleteChildFolderAndDocument(Set<Folder> set) {

		for (Folder folder : set) {
			if (folder.getFolders().isEmpty()) {
				List<FolderDocument> documents = folderDocumentDAO.getFolderDocumentInfo(folder.getFolderId());
				if (!documents.isEmpty()) {
					for (FolderDocument folderDocument : documents) {
						// deleting document in mongoDb
						if (folderDocument.getDocumentId() != null && folderDocument.getDocumentLink() != null) {
							fileMongoDAO.deletefiles(folderDocument.getDocumentLink());
							// folderDocumentDAO.delete(folderDocument);
						}
					}
				}

			} else {
				deleteChildFolderAndDocument(folder.getFolders());
			}
		}

	}

	@Transactional
	public void createFoldersForProject(Integer projectId, List<FolderTreeDTO> folderTreeDTO) {
		Project projectObject = projectDAO.findOne(projectId);
		for (FolderTreeDTO treeDTO : folderTreeDTO) {
			Folder folder = new Folder();
			folder.setFolderName(treeDTO.getLabel());
			folder.setProject(projectObject);
			Folder parentFolder = folderDAO.create(folder);
			if (!treeDTO.getChildren().isEmpty()) {
				createChildFolder(treeDTO, projectObject, parentFolder);
			}
			List<FolderTemplateDeptMapping> deptMappings = folderTemplateDeptMappingDAO
					.getDepartmentTemplateMapping(treeDTO.getData().getTemplateId());
			for (FolderTemplateDeptMapping deptMapping : deptMappings) {
				FolderDepartmentMapping departmentMapping = new FolderDepartmentMapping();
				departmentMapping.setDepartmentId(deptMapping.getDepartmentId());
				departmentMapping.setFolderId(parentFolder.getFolderId());
				folderDepartmentMappingDAO.create(departmentMapping);
			}
		}
		projectObject.setUpdatedDate(DateUtils.getCurrentISTDateTime());
		projectObject.setUpdatedBy(ThreadLocalUtil.getUserName());
		projectObject.setTemplate(Boolean.TRUE);
		projectDAO.update(projectObject);
	}

	public void createChildFolder(FolderTreeDTO treeDTO, Project project, Folder parentFolder) {
		for (FolderTreeDTO children : treeDTO.getChildren()) {
			Folder child = new Folder();
			child.setFolderName(children.getLabel());
			child.setProject(project);
			child.setFolder(parentFolder);
			Folder folder = folderDAO.create(child);
			if (!children.getChildren().isEmpty()) {
				createChildFolder(children, project, folder);
			}

		}

	}

	/*
	 * Child Folder Moving to another Parent Folder
	 */
	@Transactional
	public Folder folderMoving(Folder folder) {
		Folder childFolder = folderDAO.findOne(folder.getFolderId());
		Folder parentFolder = folderDAO.findOne(folder.getParentId());
		if (folderDAO.getFoldeNamesByParentIds(parentFolder.getFolderId()).contains(childFolder.getFolderName())) {

			throw new AppException(MessagesEnum.DUPLICATE_FOLDER_NAME);

		}
		childFolder.setFolder(parentFolder);
		Folder object = folderDAO.update(childFolder);
		Project project = projectDAO.findOne(folder.getProjectId());
		projectDAO.update(project);
		return object;

	}

	private Integer getDepartmentId(Integer projectId) {
		Long userId = ThreadLocalUtil.getUserId();
		return projectMemberDAO.getProjectMemberInfo(projectId, userId.intValue());

	}

	@Transactional
	public List<Folder> getFolderInfo(Integer projectId) {
		return folderDAO.getFolderInfoByProjectId(projectId);

	}

	@Transactional
	public List<Folder> getFolderInfoByProjectId(Integer projectId) {
		List<Folder> folders = new ArrayList<>();
		Long userId = ThreadLocalUtil.getUserId();
		ProjectMember projectMember = projectMemberDAO.getProjectMember(projectId, userId.intValue());
		if (projectMember.getCompleteAccess()) {
			folders.addAll(folderDAO.getFolderInfoByProjectId(projectId));
		} else {
			List<Integer> folderIds = folderDepartmentMappingDAO.getFolderIds(getDepartmentId(projectId));
			if (!folderIds.isEmpty()) {
				List<Folder> templatefolders = folderDAO.getFolderInfoByProjectIdAndTemplateId(projectId, folderIds);
				folders.addAll(templatefolders);
			}

		}
		return folders;
	}

	/** get file extenstion when multiple dots in file Name code */
	private static String getFileExtension(File file) {
		String fileName = file.getName();
		if (fileName.lastIndexOf(".") != -1 && fileName.lastIndexOf(".") != 0)
			return fileName.substring(fileName.lastIndexOf(".") + 1);
		else
			return "";
	}

	@Transactional
	public void saveFile(MultipartFile file, Integer folderId, Integer projectId, boolean editMode,
			String documentDescription, Double version, boolean indexFile) throws IOException {
		fileUpload(file, folderId, projectId, editMode, documentDescription, version, indexFile);
	}

	@Transactional
	public FolderDocument saveIndexFile(MultipartFile file, Integer folderId, Integer projectId, boolean editMode,
			String documentDescription, Double version, boolean indexFile) throws IOException {
		return fileUpload(file, folderId, projectId, editMode, documentDescription, version, indexFile);
	}

	private FolderDocument fileUpload(MultipartFile file, Integer folderId, Integer projectId, boolean editMode,
			String documentDescription, Double version, boolean indexFile) throws IOException {

		FolderDocument document = new FolderDocument();
		// check the document is already exists with other versions
		List<FolderDocument> folderDocuments = folderDocumentDAO.listOfFolderDocuments(folderId,
				file.getOriginalFilename());

		// Splitting fileName and Extension
		String[] fileName = file.getOriginalFilename().split("\\.(?=[^\\.]+$)");
		// version Increment
		Double newVersion = null;

		if (!folderDocuments.isEmpty()) {
			newVersion = folderDocuments.get(0).getVersion() + 1.00;

		}

		// Concating version to fileName

		String fileNameWithVersion = folderDocuments.isEmpty() ? fileName[0] + "_0.00" + "." + fileName[1]
				: fileName[0] + "_" + newVersion + "." + fileName[1];

		// String fileName1 = fileName[0] + "." + fileName[1];
		if (!file.isEmpty()) {
			String id = fileMongoDAO.store(file.getInputStream(), fileNameWithVersion, file.getContentType(), null);
			try {

				Folder originalObject = folderDAO.findOne(folderId);

				FolderDocument folderDoc = editMode
						? folderDocumentDAO.getfolderDocumentObjcet(folderId, file.getOriginalFilename())
						: new FolderDocument();

				folderDoc.setDocumentName(file.getOriginalFilename());
				folderDoc.setDocumentLink(id);
				folderDoc.setFolder(originalObject);
				File f = new File(file.getOriginalFilename());
				String extension = getFileExtension(f);
				folderDoc.setFileType(extension);
				folderDoc.setIndexFile(indexFile);
				folderDoc.setDocumentDescription(documentDescription);

				// EditMode false means new File Adding
				if (editMode == false) {
					folderDoc.setVersion(folderDocuments.isEmpty() ? 0.00 : folderDocuments.get(0).getVersion() + 1.00);
					document = folderDocumentDAO.create(folderDoc);
				} else {
					fileMongoDAO.deletefiles(folderDocuments.get(0).getDocumentLink());
					document = folderDocumentDAO.update(folderDoc);
				}
				// Updating Project and Folder
				folderDAO.update(originalObject);
				Project project = projectDAO.findOne(projectId);
				project.setUpdatedDate(DateUtils.getCurrentISTDateTime());
				project.setUpdatedBy(ThreadLocalUtil.getUserName());
				projectDAO.update(project);

			} catch (Exception e) {
				System.out.println("You failed to upload " + file.getOriginalFilename() + " => " + e.getMessage());
			}
		} else {
			System.out.println("You failed to upload " + file.getOriginalFilename() + " because the file was empty.");

		}
		return document;

	}

	@Transactional
	public void downloadfile(HttpServletResponse response, Integer documentIds) throws IOException {
		FolderDocument folderDocument = folderDocumentDAO.getlistOfDocumentUrls(documentIds);
		String urls = folderDocument.getDocumentLink();
		GridFSDBFile fs = fileMongoDAO.getById(urls);
		// java.io.PrintWriter out = response.getWriter();
		response.setContentType(MediaType.APPLICATION_OCTET_STREAM_VALUE);
		response.setHeader("Content-Disposition", "attachment; filename=" + folderDocument.getDocumentName());
		InputStream fileInputStream = fs.getInputStream();
		ServletOutputStream os = response.getOutputStream();
		byte[] bufferData = new byte[1024];
		int read = 0;
		while ((read = fileInputStream.read(bufferData)) != -1) {
			os.write(bufferData, 0, read);
		}
		os.flush();
		os.close();
		fileInputStream.close();
		FolderDownloadHistory history = new FolderDownloadHistory();
		history.setDocumentId(folderDocument.getDocumentId());
		history.setDocumentDescription(folderDocument.getDocumentDescription());
		history.setDocumentName(folderDocument.getDocumentName());
		history.setFileType(folderDocument.getFileType());
		history.setDocumentLink(folderDocument.getDocumentLink());
		history.setDocumentFolderId(folderDocument.getFolder().getFolderId());
		history.setVersion(folderDocument.getVersion() != null ? folderDocument.getVersion() : 0.0);
		history.setDownloadedBy(ThreadLocalUtil.getUserName());
		history.setDownloadedDate(DateUtils.getCurrentISTDateTime());
		dolderDownloadHistoryDAO.create(history);

	}

	@Transactional
	public void deleteDocument(List<Integer> documentIdList, Integer projectId) {

		for (Integer documentId : documentIdList) {
			FolderDocument folderDocument = folderDocumentDAO.findOne(documentId);
			folderDocumentDAO.delete(folderDocument);
			DocumentIndex documentIndex = documentIndexDAO.getDocumentIndexByDocumentId(documentId);
			if (documentIndex != null) {
				documentIndex.setPercentageOfCompleted(0);
				documentIndex.setCurrentResponsibleId(null);
				documentIndex.setDocumentName(null);
				documentIndex.setDocumentPath(null);
				documentIndex.setDocumentFolderId(null);
				documentIndex.setDocumentId(null);
				//documentIndex.setStateId(null);
				List<WorkflowStates> workflowState = workflowStatesDAO.getOrderBySeqId(documentIndex.getWorkflowId());
				if(!workflowState.isEmpty()){
					documentIndex.setStateId(workflowState.get(0).getId());
				}
				
				
				documentIndex.setPreviousStateUser(null);
				documentIndex.setDateOfCompletion(null);
				documentIndex.setActivityStage(0);
				documentIndexDAO.update(documentIndex);
			}
			fileMongoDAO.deletefiles(folderDocument.getDocumentLink());
			Folder folder = folderDocument.getFolder();
			folder.setUpdatedDate(new Date());
			folder.setUpdatedBy(ThreadLocalUtil.CURRENT_USER);
			folderDAO.update(folder);
			Project project = projectDAO.findOne(projectId);
			projectDAO.update(project);
		}

	}

	@Override
	@Transactional
	public void saveMultipleFiles(List<MultipartFile> filesList, Integer projectId, Integer folderId, boolean editMode,
			String documentDescription, Double version) throws IOException {
		for (MultipartFile file : filesList) {

			CommonsMultipartFile commonsMultipartFile = (CommonsMultipartFile) file;
			DiskFileItem fileItem = (DiskFileItem) commonsMultipartFile.getFileItem();

			// splitting file name to get the folder path list
			String[] folderPathList = fileItem.getName().split("/");
			Folder parentFolder = null;
			// iterating through folders list
			for (int i = 0; i < folderPathList.length; i++) {
				// check the index is last index then it is considered as
				// file name
				if (i == folderPathList.length - 1) {

					// if parent folder is null consider it as root parent
					Folder folder = folderDAO.findOne(folderId);

					// check the document is already exists with other versions
					List<FolderDocument> folderDocuments = folderDocumentDAO.listOfFolderDocuments(
							parentFolder != null ? parentFolder.getFolderId() : folder.getFolderId(),
							file.getOriginalFilename());

					// Splitting fileName and Extension
					String[] fileName = file.getOriginalFilename().split("\\.(?=[^\\.]+$)");

					// version Increment
					Double newVersion = null;
					if (!folderDocuments.isEmpty()) {
						newVersion = folderDocuments.get(0).getVersion() + 1.00;
					}
					// Concating version to fileName
					String fileNameWithVersion = folderDocuments.isEmpty() ? fileName[0] + "_0.00" + "." + fileName[1]
							: fileName[0] + "_" + newVersion + "." + fileName[1];

					String id = fileMongoDAO.store(file.getInputStream(), fileNameWithVersion, file.getContentType(),
							null);

					FolderDocument folderDocument = new FolderDocument();
					folderDocument.setFolder(parentFolder != null ? parentFolder : folder);
					folderDocument.setDocumentName(folderPathList[folderPathList.length - 1]);
					folderDocument.setDocumentLink(id);

					// if document list is empty set version as 0.00 other wise
					// increment with high version
					folderDocument
							.setVersion(folderDocuments.isEmpty() ? 0.00 : folderDocuments.get(0).getVersion() + 1.00);

					String filtextention = file.getOriginalFilename();
					File f = new File(filtextention);
					String extenston = getFileExtension(f);
					folderDocument.setFileType(extenston);

					folderDocumentDAO.create(folderDocument);
				}
				// else create the folder structure until the last index
				// create folder
				else {
					// check if the folder exits in parent folder id

					Folder mappedFolderId = folderDAO.getFolderInfoByParentIdAndFolderName(
							parentFolder == null ? folderId : parentFolder.getFolderId(), folderPathList[i]);
					if (mappedFolderId != null) {
						parentFolder = mappedFolderId;
					}
					// else create folder
					else {
						Folder existingFolder = folderDAO.findOne(folderId);
						Project project = projectDAO.findOne(projectId);

						Folder folder = new Folder();
						// parent folder id is null attach it to root
						// folderid otherwise attach to parentfolder id
						folder.setProjectId(projectId);
						folder.setFolder(parentFolder == null ? existingFolder : parentFolder);
						folder.setFolderName(folderPathList[i]);
						folder.setProject(project);

						parentFolder = folderDAO.create(folder);
					}

				}
			}

		}

	}

}
