package com.synergy.bqm.repositories;

import java.util.List;

import com.guvvala.framework.dao.BaseDAO;
import com.synergy.bqm.models.Folder;

public interface FolderDAO extends BaseDAO<Folder, Integer> {

	List<Folder> getTemplateFolders();

	public Long checkTemplateIdExists(Integer templateId);

	List<Folder> getFolderInfoByProjectId(Integer projectId);
	
	public List<String>getFoldeNamesByParentIds(Integer parentFolderId) ;
	
	public Long checkFolderNameExists(Integer projectId, String folderName);
		
	public Long checkChildFolderNameExits(Integer projectId, Integer parentFolderId, String folderName);
	
	public Folder getFolderInfoByParentIdAndFolderName(Integer folderId, String folderName);
	
	public List<Folder> getFolderInfoByProjectIdAndTemplateId(Integer projectId,List<Integer> templateIds);
	
	public List<Folder> getFolderInfoByProjectIdAndDepartmentId(Integer projectId,Integer departmentId);
	
	public Long checkFolderNameExists(Integer projectId, String folderName,List<Integer> folderId);
}
