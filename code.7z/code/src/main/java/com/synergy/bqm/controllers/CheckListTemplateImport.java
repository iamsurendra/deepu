package com.synergy.bqm.controllers;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.guvvala.framework.errorHandler.AppException;
import com.guvvala.framework.util.BaseImporter;
import com.guvvala.framework.util.ExcelImporter;
import com.synergy.bqm.constants.MessagesEnum;
import com.synergy.bqm.documents.BaseQuestionTypeTemplate;
import com.synergy.bqm.documents.ChecklistTemplate;
import com.synergy.bqm.documents.InfoQuestionTypeTemplate;
import com.synergy.bqm.documents.SectionTemplate;
import com.synergy.bqm.documents.SelectionQuestionTypeTemplate;
import com.synergy.bqm.documents.SubsectionTemplate;
import com.synergy.bqm.documents.TextQuestionTypeTemplate;
import com.synergy.bqm.mongoRepositories.CheckListTemplateRepository;
import com.synergy.bqm.services.CheckListServicesService;
import com.synergy.bqm.services.CheckListTypeService;
import com.synergy.bqm.services.QuestionOptionService;

@RestController
@RequestMapping("/api/checkListTemplateImport")
public class CheckListTemplateImport extends BaseImporter {

	public static final String CHECKLIST_NAME = "CHECKLIST_NAME";
	public static final String CHECKLIST_TYPE = "CHECKLIST_TYPE";
	public static final String CHECKLIST_SERVICE = "CHECKLIST_SERVICE";
	public static final String REFERENCE = "REFERENCE";
	public static final String SECTION_NAME = "SECTION_NAME";
	public static final String SECTION_INFO = "SECTION_INFO";
	public static final String UPPER_LIMIT = "UPPER_LIMIT";
	public static final String LOWER_LIMIT = "LOWER_LIMIT";
	public static final String SUB_SECTION_NAME = "SUB_SECTION_NAME";
	public static final String SUB_SECTION_INFO = "SUB_SECTION_INFO";
	public static final String QUESTION_TYPE = "QUESTION_TYPE";
	public static final String QUESTION = "QUESTION";
	public static final String QUESTION_INFO = "QUESTION_INFO";

	@Autowired
	QuestionOptionService questionOptionService;

	@Autowired
	CheckListTemplateRepository checkListRepository;
	
	@Autowired
	CheckListTypeService checkListTypeService;
	
	@Autowired
	CheckListServicesService checkListServicesService;

	@RequestMapping(value = "/importCheckListTemplateexcel", method = RequestMethod.POST, consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
	public String importCheckListTemplateexcel(@RequestParam("file") MultipartFile file) throws IOException {
		
		XSSFWorkbook workbook = new XSSFWorkbook(file.getInputStream());
		ChecklistTemplate checklist = importChecklists(workbook);
		List<String> checklistTypes = checkListTypeService.getCheckListTypeName();
		List<String> checkListServices = checkListServicesService.getCheckListServices();
		if(!checkListServices.contains(checklist.getChecklistService())){
			throw new AppException(MessagesEnum.INVALID_CHECKLIST_SERVICE);

		}
		if(!checklistTypes.contains(checklist.getChecklistType())){
			throw new AppException(MessagesEnum.INVALID_CHECKLIST_TYPE);

		}
		ChecklistTemplate checkListObj = checkListRepository.checkDuplicateCheckList(checklist.getChecklistName(),checklist.getChecklistType(),checklist.getChecklistService());
		if (checkListObj != null) {

			throw new AppException(MessagesEnum.DUPLICATCHECKLISTTEMPLATE);
		}
		ChecklistTemplate template = checkListRepository.save(checklist);
		String id = template.getId();
		return id;

	}

	/* public static void main(String[] args) { */
	public ChecklistTemplate importChecklists(Workbook workbook) {
		// String filename = "D:\\BQM\\checklisttemplate.xlsx";
		ChecklistTemplate checklist = buildChecklistInfo(workbook);
		buildSectionInfo(workbook, checklist);
		buildQuestions(workbook, checklist);
		return checklist;

	}

	/**
	 * This method is used to capture checklist name and type it referes to the
	 * first sheet of the work book
	 * 
	 * @param workbook
	 * @return
	 */
	private ChecklistTemplate buildChecklistInfo(Workbook workbook) {
		Sheet infoSheet = workbook.getSheetAt(0);
		Row infoHeaderRow = infoSheet.getRow(infoSheet.getFirstRowNum());
		Row infoDataRow = infoSheet.getRow(infoSheet.getFirstRowNum() + 1);
		if (infoDataRow == null || ExcelImporter.isBlankRow(infoDataRow)) {
			throw new AppException(MessagesEnum.EXCELNODATA);

		}
		String infoSheetName = infoSheet.getSheetName();
		Map<String, Integer> headersMap = ExcelImporter.getHeadersMap(infoHeaderRow, infoSheetName);
		ChecklistTemplate checklist = new ChecklistTemplate();
		for (int rowIndex = infoSheet.getFirstRowNum() + 1; rowIndex <= ExcelImporter
				.getLastNonEmptyRow(infoSheet); rowIndex++)

		{
			currentRow = infoSheet.getRow(rowIndex);
			String header = null;
			if (currentRow == null || ExcelImporter.isBlankRow(currentRow)) {
				throw new AppException(MessagesEnum.EXCELBLANKROW, rowIndex + 1, infoSheetName);
			}
			for (Map.Entry<String, Integer> column : headersMap.entrySet()) {
				Cell cell = currentRow.getCell(column.getValue());
				if (cell != null) {
					columnIndex = cell.getColumnIndex();
				}
				try {
					header = column.getKey();
					switch (header) {
					case CHECKLIST_NAME:
						String checklistName = getCheckStringEmpty(cell, header, rowIndex);
						checklist.setChecklistName(checklistName);
						break;
					case CHECKLIST_TYPE:
						String checklistType = getCheckStringEmpty(cell, header, rowIndex);
						checklist.setChecklistType(checklistType);
						break;
					case CHECKLIST_SERVICE:
						String checklistService = getCheckStringEmpty(cell, header, rowIndex);
						checklist.setChecklistService(checklistService);
					}
				} catch (AppException ap) {
					throw ap;
				} catch (Throwable th) {
					throw new AppException(true, th, MessagesEnum.EXCELCELLCONVERSIONERROR, rowIndex + 1, header);
				}
			}

		}
		return checklist;
	}

	/**
	 * This method is used to build sections and subsections . The reference is
	 * the one which holds questions at subsection/section level. If section
	 * level reference is null then there are questions under a sub section ,
	 * else question is present directly under section
	 * 
	 * @param workbook
	 * @param checklist
	 */
	private void buildSectionInfo(Workbook workbook, ChecklistTemplate checklist) {
		Sheet sectionSheet = workbook.getSheetAt(1);
		Row sectionHeaderRow = sectionSheet.getRow(sectionSheet.getFirstRowNum());
		Row sectionDataRow = sectionSheet.getRow(sectionSheet.getFirstRowNum() + 1);
		if (sectionDataRow == null || ExcelImporter.isBlankRow(sectionDataRow))

		{
			throw new AppException(MessagesEnum.EXCELNODATA);
		}

		String sectionSheetName = sectionSheet.getSheetName();
		Map<String, Integer> headersMap = ExcelImporter.getHeadersMap(sectionHeaderRow, sectionSheetName);
		for (int rowIndex = sectionSheet.getFirstRowNum() + 1; rowIndex <= ExcelImporter
				.getLastNonEmptyRow(sectionSheet); rowIndex++)

		{
			SectionTemplate section = new SectionTemplate();
			SubsectionTemplate subsection = new SubsectionTemplate();
			currentRow = sectionSheet.getRow(rowIndex);
			String header = null;
			if (currentRow == null || ExcelImporter.isBlankRow(currentRow)) {
				throw new AppException(MessagesEnum.EXCELBLANKROW, rowIndex + 1, sectionSheetName);
			}
			for (Map.Entry<String, Integer> column : headersMap.entrySet()) {
				Cell cell = currentRow.getCell(column.getValue());
				if (cell != null) {
					columnIndex = cell.getColumnIndex();
				}
				try {
					header = column.getKey();
					switch (header) {

					case SECTION_NAME:
						String sectionName = getCheckStringEmpty(cell, header, rowIndex);
						
						section.setSectionName(sectionName);
						break;
					case SECTION_INFO:
						String sectionInfo = getString(cell);
						section.setSectionInfo(sectionInfo);
						break;
					case SUB_SECTION_NAME:
						// sub section name can be empty
						String subsectionName = getString(cell);
						if (subsectionName != null && !subsectionName.isEmpty())
							subsection.setSubsectionName(subsectionName);
						break;
					case SUB_SECTION_INFO:
						// sub section info can be empty
						String subsectionInfo = getString(cell);
						if (subsectionInfo != null && !subsectionInfo.isEmpty())
							subsection.setSubsectionInfo(subsectionInfo);
						break;
					case QUESTION_TYPE:
						
						String answerType = getCheckStringEmpty(cell, header, rowIndex);
						
						subsection.setQuestionType(answerType);
						break;
					case REFERENCE:
						String reference = getCheckStringNumeric(cell, Integer.class);
						
						subsection.setReference(reference);
						break;

					}
				} catch (AppException ap) {
					throw ap;
				} catch (Throwable th) {
					throw new AppException(true, th, MessagesEnum.EXCELCELLCONVERSIONERROR, rowIndex + 1, header);
				}
			}
			boolean sectionPresent = false;
			SectionTemplate alreadySavedSection = null;
			for (SectionTemplate tempSection : checklist.getSectionList()) {
				if (tempSection.getSectionName().equals(section.getSectionName())) {
					sectionPresent = true;
					alreadySavedSection = tempSection;
				}
			}

			if (!sectionPresent) {
				checklist.getSectionList().add(section);
			} else {
				section = alreadySavedSection;
			}
			if (subsection.getSubsectionName() != null && !subsection.getSubsectionName().isEmpty()) {
				section.getSubsectionList().add(subsection);
			} else {
				// copy the reference and also answer type to section as sub
				// section will not be there
				section.setQuestionType(subsection.getQuestionType());
				section.setReference(subsection.getReference());
			}
		}
	}

	private void buildQuestions(Workbook workbook, ChecklistTemplate checklist) {
		Map<String, List<String>> map = questionOptionService.getQuestionAnsInfo();

		for (SectionTemplate section : checklist.getSectionList()) {
			// since reference is null then questions are present under
			// subsection

			for (SubsectionTemplate subsection : section.getSubsectionList()) {
				subsection.getQuestionList().addAll(
						returnQuestionList(workbook, subsection.getQuestionType(), subsection.getReference(), map));
			}
			// if reference is present then add questions directly under
			// section
			if (section.getReference() != null)
				section.getQuestionList()
						.addAll(returnQuestionList(workbook, section.getQuestionType(), section.getReference(), map));
		}

	}

	private List<BaseQuestionTypeTemplate> returnQuestionList(Workbook workbook, String questionType, String reference,
			Map<String, List<String>> map) {

		Sheet subsectionSheet = workbook.getSheet(reference);
		Row sectionHeaderRow = subsectionSheet.getRow(subsectionSheet.getFirstRowNum());
		Row sectionDataRow = subsectionSheet.getRow(subsectionSheet.getFirstRowNum() + 1);
		if (sectionDataRow == null || ExcelImporter.isBlankRow(sectionDataRow))

		{
			throw new AppException(MessagesEnum.EXCELNODATA);
		}

		String sectionSheetName = subsectionSheet.getSheetName();
		Map<String, Integer> headersMap = ExcelImporter.getHeadersMap(sectionHeaderRow, sectionSheetName);
		List<BaseQuestionTypeTemplate> questionTypeList = new ArrayList<BaseQuestionTypeTemplate>();
		for (int rowIndex = subsectionSheet.getFirstRowNum() + 1; rowIndex <= ExcelImporter
				.getLastNonEmptyRow(subsectionSheet); rowIndex++) {
			BaseQuestionTypeTemplate baseQuestionType = null;
			if (questionType.equals("TEXT")) {
				baseQuestionType = new TextQuestionTypeTemplate();

			} else if (questionType.equals("INFO")) {
				baseQuestionType = new InfoQuestionTypeTemplate();

			} else {
				// TODO make this db call
				/*
				 * List<String> questionOption =
				 * questionOptionService.getQuestionOptionByQuestionType(
				 * questionType);
				 */
				if (!map.containsKey(questionType)) {
					throw new AppException(MessagesEnum.INVALID_SELECTION_TYPE);

				}
				SelectionQuestionTypeTemplate selectionQuestionType = new SelectionQuestionTypeTemplate();
				selectionQuestionType.getQuestionOptions().addAll(map.get(questionType));
				selectionQuestionType.setOptionType(questionType);
				selectionQuestionType.setQuestionType("SELECTION");
				baseQuestionType = selectionQuestionType;

			}
			baseQuestionType.setQuestionType(questionType);
			currentRow = subsectionSheet.getRow(rowIndex);
			String header = null;
			if (currentRow == null || ExcelImporter.isBlankRow(currentRow)) {
				throw new AppException(MessagesEnum.EXCELBLANKROW, rowIndex + 1, sectionSheetName);
			}
			for (Map.Entry<String, Integer> column : headersMap.entrySet()) {
				Cell cell = currentRow.getCell(column.getValue());
				if (cell != null) {
					columnIndex = cell.getColumnIndex();
				}
				try {
					header = column.getKey();
					switch (header) {

					case QUESTION:
						String question = getCheckStringEmpty(cell, header, rowIndex);
						baseQuestionType.setLineItemQuestion(question);
						break;
					case QUESTION_INFO:
						String questionInfo = getString(cell);
						baseQuestionType.setLineItemToolTip(questionInfo);
						break;
					/*
					 * case SECTION_NAME: String sectionName =
					 * getCheckStringEmpty(cell, header, rowIndex);
					 * section.setSectionName(sectionName); break;
					 */
					case LOWER_LIMIT:
						String lowerLimit = getString(cell);
						TextQuestionTypeTemplate textQuestionType = (TextQuestionTypeTemplate) baseQuestionType;
						if (lowerLimit == null) {
							textQuestionType.setLowerLimit("");
						} else {
							textQuestionType.setLowerLimit(lowerLimit);
						}
						break;
					case UPPER_LIMIT:
						String upperLimit = getString(cell);
						TextQuestionTypeTemplate textQuestionType1 = (TextQuestionTypeTemplate) baseQuestionType;
						if (upperLimit == null) {
							textQuestionType1.setUpperLimit("");
						} else {
							textQuestionType1.setUpperLimit(upperLimit);
						}
						break;
					}
				} catch (AppException ap) {
					throw ap;
				} catch (Throwable th) {
					throw new AppException(true, th, MessagesEnum.EXCELCELLCONVERSIONERROR, rowIndex + 1, header);
				}
			}
			questionTypeList.add(baseQuestionType);
		}
		return questionTypeList;
	}

}
