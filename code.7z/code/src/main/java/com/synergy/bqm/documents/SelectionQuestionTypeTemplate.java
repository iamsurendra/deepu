package com.synergy.bqm.documents;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

public class SelectionQuestionTypeTemplate extends BaseQuestionTypeTemplate {

	public static final String QUESTION_TYPE = "SELECTION";

	private String optionType;

	private List<String> questionOptions = new ArrayList<String>();

	public SelectionQuestionTypeTemplate() {
	}

	@JsonCreator
	public SelectionQuestionTypeTemplate(@JsonProperty("lineItemQuestion") String lineItemQuestion,
			@JsonProperty("lineItemToolTip") String lineItemToolTip, @JsonProperty("questionType") String questionType,
			@JsonProperty("optionType") String optionType) {
		super(lineItemQuestion, lineItemToolTip, questionType);
		this.optionType = optionType;
	}

	public List<String> getQuestionOptions() {
		return questionOptions;
	}

	public void setQuestionOptions(List<String> questionOptions) {
		this.questionOptions = questionOptions;
	}

	public String getOptionType() {
		return optionType;
	}

	public void setOptionType(String optionType) {
		this.optionType = optionType;
	}

}
