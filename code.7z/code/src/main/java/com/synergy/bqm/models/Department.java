package com.synergy.bqm.models;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Transient;

/**
 * The persistent class for the departments database table.
 * 
 */
@Entity
@Table(name = "departments")
@NamedQuery(name = "Department.findAll", query = "SELECT d FROM Department d")
public class Department implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue
	@Column(name = "department_id")
	private Integer departmentId;

	@Column(name = "department_name")
	private String departmentName;
	
	@Transient
	private boolean selectedDept;
	
	@Transient
	List<Integer> deletedDepartmentIds;

	public Department() {
	}

	public Integer getDepartmentId() {
		return departmentId;
	}

	public void setDepartmentId(Integer departmentId) {
		this.departmentId = departmentId;
	}

	public String getDepartmentName() {
		return this.departmentName;
	}

	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}

	public List<Integer> getDeletedDepartmentIds() {
		return deletedDepartmentIds;
	}

	public void setDeletedDepartmentIds(List<Integer> deletedDepartmentIds) {
		this.deletedDepartmentIds = deletedDepartmentIds;
	}

	public boolean isSelectedDept() {
		return selectedDept;
	}

	public void setSelectedDept(boolean selectedDept) {
		this.selectedDept = selectedDept;
	}

	
	
}