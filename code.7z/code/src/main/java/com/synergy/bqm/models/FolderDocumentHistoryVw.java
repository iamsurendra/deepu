package com.synergy.bqm.models;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.PostLoad;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.guvvala.framework.util.DateUtils;

@Entity
@Table(name = "folder_document_history_v")
public class FolderDocumentHistoryVw  implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	@JsonIgnore
	private FolderDocumentHistoryVwKey folderDocumentHistoryVwKey;

	@Column(name = "document_id", insertable = false, updatable = false)
	private Integer documentId;

	@Column(name = "document_folder_id", insertable = false, updatable = false)
	private Integer documentFolderId;

	@Column(name = "document_name")
	private String documentName;

	@Column(name = "document_description")
	private String documentDescription;

	@Column(name = "folder_name")
	private String folderName;

	@Column(name = "file_type")
	private String fileType;

	@Column(name = "REVISION_TYPE", insertable = false, updatable = false)
	private Long revisionType;

	@Column(name = "LAST_UPD_DT", insertable = false, updatable = false)
	private Date lastUpdatedDT;

	@Column(name = "LAST_UPD_BY")
	private String lastUpdatedBy;

	@Column(name = "LAST_UPD_BY_USER")
	private String lastUpdatedByUser;

	@Column(name = "version")
	private Double version;

	@Transient
	private String updatedDt;

	public Integer getDocumentId() {
		return documentId;
	}

	public void setDocumentId(Integer documentId) {
		this.documentId = documentId;
	}

	public Integer getDocumentFolderId() {
		return documentFolderId;
	}

	public void setDocumentFolderId(Integer documentFolderId) {
		this.documentFolderId = documentFolderId;
	}

	public String getDocumentName() {
		return documentName;
	}

	public void setDocumentName(String documentName) {
		this.documentName = documentName;
	}

	public String getDocumentDescription() {
		return documentDescription;
	}

	public void setDocumentDescription(String documentDescription) {
		this.documentDescription = documentDescription;
	}

	public Long getRevisionType() {
		return revisionType;
	}

	public void setRevisionType(Long revisionType) {
		this.revisionType = revisionType;
	}

	public Date getLastUpdatedDT() {
		return lastUpdatedDT;
	}

	public void setLastUpdatedDT(Date lastUpdatedDT) {
		this.lastUpdatedDT = lastUpdatedDT;
	}

	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	public FolderDocumentHistoryVwKey getFolderDocumentHistoryVwKey() {
		return folderDocumentHistoryVwKey;
	}

	public void setFolderDocumentHistoryVwKey(FolderDocumentHistoryVwKey folderDocumentHistoryVwKey) {
		this.folderDocumentHistoryVwKey = folderDocumentHistoryVwKey;
	}

	public String getUpdatedDt() {
		return updatedDt;
	}

	public void setUpdatedDt(String updatedDt) {
		this.updatedDt = updatedDt;
	}

	public String getFolderName() {
		return folderName;
	}

	public void setFolderName(String folderName) {
		this.folderName = folderName;
	}

	public String getFileType() {
		return fileType;
	}

	public void setFileType(String fileType) {
		this.fileType = fileType;
	}

	public Double getVersion() {
		return version;
	}

	public void setVersion(Double version) {
		this.version = version;
	}

	public String getLastUpdatedByUser() {
		return lastUpdatedByUser;
	}

	public void setLastUpdatedByUser(String lastUpdatedByUser) {
		this.lastUpdatedByUser = lastUpdatedByUser;
	}

	@PostLoad
	void postload() {
		setUpdatedDt(DateUtils.convertToSimpleDateTimeFormat(getLastUpdatedDT()));
	}

}
