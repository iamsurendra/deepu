package com.synergy.bqm.json;

import java.util.List;

import com.synergy.bqm.models.CheckListType;

public class CheckListTypeDTO {

	List<CheckListType> checklistTypes;
	List<Integer> deletedIds;

	public List<Integer> getDeletedIds() {
		return deletedIds;
	}

	public void setDeletedIds(List<Integer> deletedIds) {
		this.deletedIds = deletedIds;
	}

	public List<CheckListType> getChecklistTypes() {
		return checklistTypes;
	}

	public void setChecklistTypes(List<CheckListType> checklistTypes) {
		this.checklistTypes = checklistTypes;
	}

}
