package com.synergy.bqm.repositories;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.guvvala.framework.dao.BaseDAOImpl;
import com.synergy.bqm.models.Folder;

@Repository
public class FolderDAOImpl extends BaseDAOImpl<Folder, Integer> implements FolderDAO {

	public FolderDAOImpl() {
		super(Folder.class);
		// TODO Auto-generated constructor stub
	}

	/*
	 * (non-Javadoc) For first level template folders project id, project
	 * hierarchy id , parent folder id should be null
	 * 
	 * @see com.synergy.bqm.repositories.FolderDAO#getTemplateFolders()
	 */
	public List<Folder> getTemplateFolders() {
		CriteriaBuilder cb = entityManager.getCriteriaBuilder();
		CriteriaQuery<Folder> cQuery = cb.createQuery(Folder.class);
		Root<Folder> root = cQuery.from(Folder.class);
		cQuery.select(root);
		cQuery.where(cb.and(cb.isNull(root.get("project")), cb.isNull(root.get("projectHierarchy")),
				cb.isNull(root.get("folder"))));
		List<Folder> templateFolders = entityManager.createQuery(cQuery).getResultList();
		return templateFolders;
	}

	public Long checkTemplateIdExists(Integer templateId) {
		TypedQuery<Long> query = entityManager.createQuery("select count(*) from Folder where templateId = :templateId",
				Long.class);
		query.setParameter("templateId", templateId);
		return query.getSingleResult();

	}

	public List<Folder> getFolderInfoByProjectId(Integer projectId) {
		TypedQuery<Folder> query = entityManager.createQuery(
				"SELECT f from Folder f where project_id ='" + projectId + "' and parent_folder_id is null  ",
				Folder.class);

		return query.getResultList();
	}

	public List<Folder> getFolderInfoByProjectIdAndTemplateId(Integer projectId,List<Integer> templateIds){
		CriteriaBuilder builder = entityManager.getCriteriaBuilder();
		CriteriaQuery<Folder> criteriaQuery = builder.createQuery(Folder.class);
		Root<Folder> root = criteriaQuery.from(Folder.class);
		criteriaQuery.select(root);
		List<Predicate> predicates = new ArrayList<Predicate>();
		predicates.add(builder.equal(root.get("project").get("projectId"), projectId));
		predicates.add(builder.in(root.get("folderId")).value(templateIds));
		predicates.add(builder.isNull(root.get("folder").get("folderId")));
		criteriaQuery.where(predicates.toArray(new Predicate[] {}));
		return entityManager.createQuery(criteriaQuery).getResultList();	
	}
	
	public List<Folder> getFolderInfoByProjectIdAndDepartmentId(Integer projectId,Integer departmentId){
		CriteriaBuilder builder = entityManager.getCriteriaBuilder();
		CriteriaQuery<Folder> criteriaQuery = builder.createQuery(Folder.class);
		Root<Folder> root = criteriaQuery.from(Folder.class);
		criteriaQuery.select(root);
		List<Predicate> predicates = new ArrayList<Predicate>();
		predicates.add(builder.equal(root.get("project").get("projectId"), projectId));
		predicates.add(builder.equal(root.get("departmentId"), departmentId));
		predicates.add(builder.isNull(root.get("templateId")));
		predicates.add(builder.isNull(root.get("folder").get("folderId")));
		criteriaQuery.where(predicates.toArray(new Predicate[] {}));
		return entityManager.createQuery(criteriaQuery).getResultList();	
	}
	
	public List<String> getFoldeNamesByParentIds(Integer parentFolderId) {
		CriteriaBuilder builder = entityManager.getCriteriaBuilder();
		CriteriaQuery<String> criteriaQuery = builder.createQuery(String.class);
		Root<Folder> root = criteriaQuery.from(Folder.class);
		criteriaQuery.select(root.get("folderName"))
				.where(builder.equal(root.get("folder").get("folderId"), parentFolderId));
		return entityManager.createQuery(criteriaQuery).getResultList();
	}

	public Long checkFolderNameExists(Integer projectId, String folderName) {
		TypedQuery<Long> query = entityManager.createQuery("SELECT count(*) from Folder  where project_id ='"
				+ projectId + "'and folderName ='" + folderName + "' and parent_folder_id is null ", Long.class);
		return query.getSingleResult();
	}

	public Long checkFolderNameExists(Integer projectId, String folderName,List<Integer> folderIds) {
		TypedQuery<Long> query = entityManager.createQuery("SELECT count(*) from Folder  where project_id ='"
				+ projectId + "'and folderName ='" + folderName + "' and folderId IN :folderIds", Long.class);
		query.setParameter("folderIds", folderIds);
		return query.getSingleResult();
	}

	public Long checkChildFolderNameExits(Integer projectId, Integer parentFolderId, String folderName) {
		TypedQuery<Long> query = entityManager.createQuery("SELECT count(*) from Folder  where project_id ='"
				+ projectId + "' and parent_folder_id ='" + parentFolderId + "' and folderName = '" + folderName + "' ",
				Long.class);

		return query.getSingleResult();
	}
	
	public Folder getFolderInfoByParentIdAndFolderName(Integer folderId, String folderName) {
		TypedQuery<Folder> query = entityManager.createQuery("SELECT f from Folder f  where parent_folder_id ='"
				+ folderId + "' and folderName = '" + folderName + "'", Folder.class);
		
      List<Folder> data = query.getResultList();
      if(data.isEmpty()){
    	  return null;
      }
		return data.get(0);

	}

}
