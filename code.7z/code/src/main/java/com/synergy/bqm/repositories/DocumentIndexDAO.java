package com.synergy.bqm.repositories;

import java.util.List;

import com.guvvala.framework.dao.BaseDAO;
import com.synergy.bqm.models.DocumentIndex;

public interface DocumentIndexDAO extends BaseDAO<DocumentIndex, Integer>{
	
	public List<DocumentIndex> getDocumentIndexListByProjectId(Integer projectId);
	
	public List<DocumentIndex> getDocumentIndexListByProjectIdDocumentPathNull(Integer projectId);
	
	public DocumentIndex getDocumentIndexByDocumentId(Integer documentId);
	
	public List<DocumentIndex> getDocumentIndexByActivityId(Integer activityId);
	
	public Boolean checkDuplicateActivity(String name,Integer departmentId,Integer activitytype);

}
