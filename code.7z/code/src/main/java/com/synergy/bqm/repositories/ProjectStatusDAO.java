package com.synergy.bqm.repositories;

import java.util.List;

import com.guvvala.framework.dao.BaseDAO;
import com.synergy.bqm.models.ProjectStatus;

public interface ProjectStatusDAO  extends BaseDAO<ProjectStatus, Integer>{

	public List<String> getprojectStatusNames();
	
	public List<String> getProjectStatusInfoById(List<Integer> Ids);
	
}
