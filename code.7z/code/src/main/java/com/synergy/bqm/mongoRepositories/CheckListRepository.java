package com.synergy.bqm.mongoRepositories;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import com.synergy.bqm.documents.Checklist;

public interface CheckListRepository extends MongoRepository<Checklist, String> {

	@Query("{ 'projectId' : ?0 }")
	List<Checklist> getCheckListByProjectId(Integer ProjectId);

	@Query("{'location' : ?0, 'checklistName' : ?1, 'checklistType' : ?2, 'checklistService' : ?3, 'projectId' : ?4, 'version' : ?5, 'hierarchyId' : ?6 }")
	Checklist checkDuplicateCheckList(String location, String Name, String type, String service, Integer projectId,
			Double version, Integer hierarchyId);

	@Query("{ 'checklistName' : { $regex: ?0 }, 'hierarchyId' : ?1 }")
	List<Checklist> getChecklists(String regexp, Integer hierarchyId);

	@Query("{ 'hierarchyId' : ?0 }")
	List<Checklist> getChecklistByHierarchy(Integer hierarchyId);
	
	 @Query(value = "{ 'hierarchyId' : ?0 }", fields = "{checklistName: 1, _id : 1}" )
	 List<Checklist> getChecklistById(Integer hierarchyId);
	
	/*@Query(" {$bucket: {groupBy: $status,$checklistService,boundaries: [0, 100], output: output: { count: { $sum: 1}}}}")
	List<Checklist> getchecklistInfo();*/
	

}
