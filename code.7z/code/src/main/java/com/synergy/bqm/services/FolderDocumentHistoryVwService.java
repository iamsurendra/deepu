package com.synergy.bqm.services;

import java.util.List;

import com.synergy.bqm.models.FolderDocumentHistoryVw;

public interface FolderDocumentHistoryVwService {

	public List<FolderDocumentHistoryVw> getFolderDocumentHistoryByFolderId(Integer folderId);
}
