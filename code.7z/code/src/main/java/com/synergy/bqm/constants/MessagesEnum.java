package com.synergy.bqm.constants;

import com.guvvala.framework.util.BasePropertyEnum;
/**
 * 
 * @author GUVALA
 *
 */
public enum MessagesEnum implements BasePropertyEnum {
	SYSTEMEXCEPTION("systemException"),
	UNEXPECTEDFAILURE("failure"),
	EXCELNODATA("excelNoData"),
	EXCELCELLERROR("excelCellError"),
	EXCELFILEINVALID("excelFileInvalid"),
	EXCELINVALIDHEADER("excelInvalidHeader"),
	EXCELCELLCONVERSIONERROR("excelCellConversionError"),
	EXCELINVALIDCOLUMN("excelInvalidColumn"),
	EXCELTYPEMISMATCH("excelTypeMisMatch"),
	EXCELBLANKROW("excelBlankRow"),
	EXCELNOADD("excelNoAdd"),
	EXCELNOOVERWRITE("excelNoOverwrite"),
	EXCELADDENTRIES("excelAddEntries"),
	INVALIDPRODUCTID("invalidProductId"),
	INVALIDEXCELPROPERTY("invalidExcelProperty"),
	DUPLICATEPRODUCTID("duplicateProductId"),
	DUPLICATEPARTYID("duplicatePartyId"),
	INVALIDPARTYID("invalidPartyId"),
	CONCURRENTMSG("conCurrentMsg"),
	LOGIN_NAME_ALREADY_EXISTS("useralreadyExist"),
	LOGIN_SUCCESS("Userloginsuccesfylly"),
	LOGIN_FAIL("YourEnterdUSerNameorPasswordisWrong"),
	DUPLICATEVEHICLENUMBER("inValidVehicleNumber"),
	CARID_NOTAVILABLE("Given car is Not Availbel."),
	EMAILSEND_FAILD("emaiSendFaild"),
	EMAIL_VALIDATION("givenEmailNotValid"),
	USERNAME_VALDATE("givenUserNamenotExist"),
	IMAGE_NOT_FOUND("imageNotFound"),
	DUPLICATE_TEMPLATE_NAME("duplicateTemplateName"),
	DUPLICATE_FOLDER_NAME("duplicateFolderName"),
	DUPLICATE_PROJECT_NAME("duplicateProjectName"),
	DOCUMENT_ALREADY_EXIST("documentAlreadyExist"),
	USER_DEACTIVATED("userdeactivated"),
	CHECKLIST_TEMPLATE_NAME_EXIST("checkListTemplateNamealreadyExist"),
	CHECKLIST_TEMPLATEIDNOTAVILABLE("givenCheckListTemaplteIdNotAvailable"),
	CLIENT_NAME_EXIST("clientNamealreadyexist"),
	INVALID_EMAIL("PleasegiveregisterdemailId"),
	DATA_IS_REQUIRED_FOR("Exceldataisrequired"),
	USER_EMAIL_EXIST("userEmailalreadyexist"),
	USER_INACTIVE("userInactivePleasecontactadmin"),
	PROJECT_TYPE_EXIST("projectTypeAleadyexisit"),
	CHEKLISTTEMPLATEEMPTY("checkListTemplateisempty"),
	DUPLICATCHECKLISTTEMPLATE("DuplicateCheckListTemplate"),
	DUPLICATECHECKLIST("DuplicateCheckList"),
	INVALID_CHECKLIST_TYPE("invalidChecklistType"),
	INVALID_CHECKLIST_SERVICE("invalidChecklistService"),
	DUPLICATE_ENTRY("duplicateEntry"),
	DUPLICATE_ROLE_NAME("duplicateRoleName"),
	ACCESS_DENIED("AccessDeniedfortheUser"),
	INVALID_SELECTION_TYPE("invalidSelectionType"),
	WORKFLOW_NAME_EXISTS("workflowNameExists"),
	ROLE_NAME_NOT_EXIST("UserDoesNotExistWithThis"),
	DUPLICATE_ACTIVITY_NAME("Activityalreadyexsist"),
	ACTIVITY_LOCKED("ActivityLocked"),
	PLEASE_ADD_AT_LEAST_ONE_TEAM_MEMBER("PleaseAddAtLeastOneTeamMember"),
	ACTIVITY_COMPLETED_SUCCESFULLY("Activitycompletedsuccesfully"),
	DOCUMENT_PERMISSION_REQUIRED("EditAcessdeniedforthisuser");

	
	public String key;
	public String bundleName = "com.synergy.bqm.messages";
	public Integer statusCode=501;
	
	

	MessagesEnum(String key) {
		this.key = key;
	}

	@Override
	public String getBundle() {
		return bundleName;
	}

	@Override
	public String getKey() {
		return key;
	}

	public Integer getStatusCode() {
		return statusCode;
	}

}
