package com.synergy.bqm.controllers;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.InputStreamSource;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.guvvala.framework.util.ThreadLocalUtil;
import com.mongodb.gridfs.GridFSDBFile;
import com.synergy.bqm.constants.BqmConstants;
import com.synergy.bqm.constants.MailTemplateEnum;
import com.synergy.bqm.constants.PDFTemplateEnum;
import com.synergy.bqm.exporter.PDFExporter;
import com.synergy.bqm.json.DocumentIndexDTO;
import com.synergy.bqm.json.DocumentMailDTO;
import com.synergy.bqm.json.FolderDocumentHistoryDTO;
import com.synergy.bqm.json.FolderTreeDTO;
import com.synergy.bqm.models.Folder;
import com.synergy.bqm.models.FolderDocument;
import com.synergy.bqm.models.FolderDocumentHistoryVw;
import com.synergy.bqm.models.FolderDownloadHistory;
import com.synergy.bqm.models.FolderHistoryVw;
import com.synergy.bqm.models.Project;
import com.synergy.bqm.services.FolderDocumentHistoryVwService;
import com.synergy.bqm.services.FolderDocumentService;
import com.synergy.bqm.services.FolderDownloadHistoryService;
import com.synergy.bqm.services.FolderHistoryVwService;
import com.synergy.bqm.services.FolderService;
import com.synergy.bqm.services.MailService;
import com.synergy.bqm.services.ProjectService;

@RestController
@RequestMapping("/api/folder")
public class FolderController {

	@Autowired
	FolderService folderService;

	@Autowired
	FolderDocumentService folderDocumentService;

	@Autowired
	ProjectService projectService;

	@Autowired
	FolderDocumentHistoryVwService folderDocumentHistoryVwService;

	@Autowired
	FolderHistoryVwService folderHistoryVwService;

	@Autowired
	FolderDownloadHistoryService folderDownloadHistoryService;

	@Autowired
	private PDFExporter pdfExporter;

	@Autowired
	MailService mailService;

	/*
	 * Upload Folders for Project
	 */
	@RequestMapping(value = "/importProjectTemplate/{projectId}", method = RequestMethod.POST)
	public void createFoldersForProject(@PathVariable("projectId") Integer projectId,
			@RequestBody List<FolderTreeDTO> folderTreeDTO) {
		folderService.createFoldersForProject(projectId, folderTreeDTO);
	}

	/**
	 * Retrieving the FolderObject by passing folderId
	 */
	@RequestMapping(value = "/folderById/{folderId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public Folder getFolderByFolderId(@PathVariable("folderId") Integer folderId) {
		return folderService.getFolderByFolderId(folderId);

	}

	/**
	 * Retrieving the FolderObject by passing folderId
	 */
	@RequestMapping(value = "/getFolderName/{folderId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public String getFolderName(@PathVariable("folderId") Integer folderId) {
		return folderService.getFolderName(folderId);

	}

	@RequestMapping(value = "/parentFolderById/{folderId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public Folder getParentFolderById(@PathVariable("folderId") Integer folderId) {
		Folder folder = folderService.getFolderByFolderId(folderId);
		folder.setFolders(null);
		folder.setFolderDocuments(null);
		return folder;
	}

	/**
	 * Creating New Folder For Project
	 */
	@RequestMapping(value = "/createFolder", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public FolderTreeDTO createFolder(@RequestBody Folder folder) {
		Folder newFolder = folderService.createFolder(folder);
		Folder folderObject = folderService.getFolderByFolderId(newFolder.getFolderId());

		FolderTreeDTO treeDTO = new FolderTreeDTO();
		treeDTO.setLabel(newFolder.getFolderName());
		treeDTO.setIcon("fa fa-folder");
		treeDTO.setFolderData(folderObject);
		treeDTO.setLeaf(true);
		treeDTO.setChildren(new HashSet<>());
		return treeDTO;
	}

	/**
	 * Updating FolderInfo For Project
	 */
	@RequestMapping(value = "/updateFolder", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public FolderTreeDTO UpdateFolder(@RequestBody Folder folder) {
		Folder newFolder = folderService.updateFolder(folder);
		FolderTreeDTO treeDTO = new FolderTreeDTO();
		treeDTO.setLabel(newFolder.getFolderName());
		treeDTO.setIcon("fa fa-folder");
		treeDTO.setFolderData(newFolder);
		treeDTO.setLeaf(true);
		treeDTO.setChildren(new HashSet<>());
		return treeDTO;
	}

	/*
	 * Moving child Folder
	 */
	@RequestMapping(value = "/moveChildFolder", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public Folder folderMoving(@RequestBody Folder folder) {
		return folderService.folderMoving(folder);

	}

	@RequestMapping(value = "/uploadMultipleFiles", method = RequestMethod.POST, produces = MediaType.MULTIPART_FORM_DATA_VALUE)
	public void saveMultipleFiles(@RequestParam("file") List<MultipartFile> filesList,
			@RequestParam("folderId") Integer folderId, @RequestParam("editMode") boolean editMode,
			@RequestParam("description") String description, @RequestParam("projectId") Integer projectId,
			@RequestParam("version") Double version) throws IOException {
		folderService.saveMultipleFiles(filesList, projectId, folderId, editMode, description, version);
	}

	/*
	 * Delete Folder and there Documents
	 */
	@RequestMapping(value = "/deleteFolder/{folderId}", method = RequestMethod.GET)
	public void deleteFolder(@PathVariable("folderId") Integer folderId) {
		Folder folder = folderService.getFolderByFolderId(folderId);
		folderService.deleteFolder(folder);
	}

	/*
	 * Delete folders or Folder Documents
	 */
	@RequestMapping(value = "/deleteFolderDocs", method = RequestMethod.POST)
	public void deleteFolderDocs(@RequestBody Folder folder) {

		// checking for folders
		if (!folder.getFolderIds().isEmpty()) {
			for (Integer folderId : folder.getFolderIds()) {
				Folder folderDoc = folderService.getFolderByFolderId(folderId);
				folderService.deleteFolder(folderDoc);

			}
		}
		// checking for DocumentIds
		if (!folder.getDocumentIds().isEmpty()) {
			folderService.deleteDocument(folder.getDocumentIds(), folder.getProjectId());

		}
	}

	/*
	 * import File in Folder For Creating you need to send editMode as False and
	 * For Replacing you need to send editMode as True
	 */
	@RequestMapping(value = "/uploadFile", method = RequestMethod.POST, produces = MediaType.MULTIPART_FORM_DATA_VALUE)
	public void saveFile(@RequestParam("file") MultipartFile file, @RequestParam("folderId") Integer folderId,
			@RequestParam("editMode") boolean editMode, @RequestParam("description") String description,
			@RequestParam("projectId") Integer projectId, @RequestParam("version") Double version) throws IOException {
		boolean indexFile = false;
		folderService.saveFile(file, folderId, projectId, editMode, description, version, indexFile);
	}

	/*
	 * Download Files by DocumentId
	 */
	@RequestMapping(value = "downloadFile/{documentIds}", method = RequestMethod.GET)
	public void downloadfile(HttpServletResponse response, @PathVariable("documentIds") Integer documentIds)
			throws IOException {
		folderService.downloadfile(response, documentIds);

	}

	/** Retrieving the files by folderId */

	@RequestMapping(value = "retriveFolderDocuments/{folderId}", method = RequestMethod.GET)
	public DocumentIndexDTO getFolderDocuments(@PathVariable("folderId") Integer folderId) {
		List<FolderDocument> documentlist = folderDocumentService.getFolderDocumentInfo(folderId);
		DocumentIndexDTO documentIndex = new DocumentIndexDTO();
		for (FolderDocument document : documentlist) {
			if (document.getIndexFile().equals(true)) {
				document.setVersion(null);
				documentIndex.getIndexFiles().add(document);
			} else {
				documentIndex.getNonIndexFiles().add(document);

			}
		}
		return documentIndex;
	}

	/*
	 * Retrieving Folder Info
	 */
	@RequestMapping(value = "/projectFolderInfo/{projectId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<FolderTreeDTO> getFolderNameByTemplateId(@PathVariable("projectId") Integer projectId) {
		List<Folder> folders = folderService.getFolderInfoByProjectId(projectId);
		Project orginalObject = projectService.getProjectByProjectId(projectId);
		List<FolderTreeDTO> dto = new ArrayList<>();
		for (Folder parentFolder : folders) {
			List<FolderDocument> documents = folderDocumentService
					.getFolderDocumentsByfolderId(parentFolder.getFolderId());
			Folder object = new Folder();
			object.setFolderName(parentFolder.getFolderName());
			object.setFolderId(parentFolder.getFolderId());
			object.setUpdatedDt(parentFolder.getUpdatedDt());
			object.setUpdatedBy(parentFolder.getUpdatedBy());
			object.setProject(orginalObject);
			FolderTreeDTO folderTreeDTO = new FolderTreeDTO();
			folderTreeDTO.setLabel(parentFolder.getFolderName());
			folderTreeDTO.setSelectable(true);
			folderTreeDTO.setFolderData(object);
			if (parentFolder.getFolders().isEmpty()) {
				if (!documents.isEmpty()) {
					folderTreeDTO.setIcon("fa fa-folder-open-o");
				} else {
					folderTreeDTO.setIcon("fa fa-folder");
				}
				folderTreeDTO.setLeaf(true);
				folderTreeDTO.setChildren(new HashSet<>());
			} else {
				folderTreeDTO.setIcon("fa fa-folder-open-o");
				Set<FolderTreeDTO> children = childrenFolders(parentFolder.getFolders(), orginalObject);
				folderTreeDTO.setChildren(children);
			}
			dto.add(folderTreeDTO);
		}
		return dto;

	}

	private Set<FolderTreeDTO> childrenFolders(Set<Folder> set, Project orginalObject) {
		// TODO Auto-generated method stub
		Set<FolderTreeDTO> dto = new LinkedHashSet<>();
		for (Folder folder : set) {
			List<FolderDocument> documents = folderDocumentService.getFolderDocumentsByfolderId(folder.getFolderId());
			Folder childFolder = new Folder();
			childFolder.setFolderName(folder.getFolderName());
			childFolder.setFolderId(folder.getFolderId());
			childFolder.setUpdatedDt(folder.getUpdatedDt());
			childFolder.setUpdatedBy(folder.getUpdatedBy());
			childFolder.setProject(orginalObject);
			FolderTreeDTO treeDTO = new FolderTreeDTO();
			treeDTO.setLabel(folder.getFolderName());
			treeDTO.setSelectable(true);
			treeDTO.setFolderData(childFolder);
			if (folder.getFolders().isEmpty()) {
				if (!documents.isEmpty()) {
					treeDTO.setIcon("fa fa-folder-open-o");
				} else {
					treeDTO.setIcon("fa fa-folder");
				}
				treeDTO.setChildren(new LinkedHashSet<>());
				treeDTO.setLeaf(true);
			} else {
				treeDTO.setIcon("fa fa-folder-open-o");
				treeDTO.setChildren(childrenFolders(folder.getFolders(), orginalObject));
			}

			dto.add(treeDTO);
		}
		return dto;
	}

	@RequestMapping(value = "/getChildFoldersByFolderId", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public FolderTreeDTO getChildFoldersByFolderId(@RequestParam("folderId") Integer folderId,
			@RequestParam("projectId") Integer projectId) {
		Folder parentFolder = folderService.getFolderByFolderId(folderId);
		Project orginalObject = projectService.getProjectByProjectId(projectId);

		Folder object = new Folder();
		object.setFolderName(parentFolder.getFolderName());
		object.setFolderId(parentFolder.getFolderId());
		object.setProject(orginalObject);
		object.setUpdatedDt(parentFolder.getUpdatedDt());
		object.setUpdatedBy(parentFolder.getUpdatedBy());
		FolderTreeDTO folderTreeDTO = new FolderTreeDTO();
		folderTreeDTO.setLabel(parentFolder.getFolderName());
		folderTreeDTO.setIcon("fa fa-folder-open-o");
		folderTreeDTO.setFolderData(object);
		if (parentFolder.getFolders().isEmpty()) {
			folderTreeDTO.setLeaf(true);
			folderTreeDTO.setChildren(new HashSet<>());
		} else {

			Set<FolderTreeDTO> children = childrenFolders(parentFolder.getFolders(), orginalObject);
			folderTreeDTO.setChildren(children);
		}
		return folderTreeDTO;
	}

	/*
	 * Retrieving ReferenceDocumentInfo Info With Documents
	 */
	@RequestMapping(value = "/getReferenceDocumentInfo/{projectId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<FolderTreeDTO> getReferenceDocumentInfo(@PathVariable("projectId") Integer projectId) {
		List<Folder> folders = folderService.getFolderInfo(projectId);
		Project orginalObject = projectService.getProjectByProjectId(projectId);
		List<FolderTreeDTO> dto = new ArrayList<>();
		for (Folder parentFolder : folders) {
			Folder object = new Folder();
			object.setFolderName(parentFolder.getFolderName());
			object.setFolderId(parentFolder.getFolderId());
			object.setUpdatedDt(parentFolder.getUpdatedDt());
			object.setUpdatedBy(parentFolder.getUpdatedBy());
			object.setProject(orginalObject);
			FolderTreeDTO folderTreeDTO = new FolderTreeDTO();
			folderTreeDTO.setLabel(parentFolder.getFolderName());
			folderTreeDTO.setIcon("fa fa-folder");
			folderTreeDTO.setFolderData(object);
			if (parentFolder.getFolders().isEmpty()) {
				folderTreeDTO.setLeaf(true);
				folderTreeDTO.setChildren(getfolderDocuments(parentFolder.getFolderId()));
			} else {
				Set<FolderTreeDTO> children = getfolderDocuments(parentFolder.getFolderId());
				children.addAll(childrenFoldersAndDocuments(parentFolder.getFolders(), orginalObject));
				folderTreeDTO.setChildren(children);

			}
			dto.add(folderTreeDTO);
		}
		return dto;

	}

	private Set<FolderTreeDTO> childrenFoldersAndDocuments(Set<Folder> set, Project orginalObject) {
		// TODO Auto-generated method stub
		Set<FolderTreeDTO> dto = new LinkedHashSet<>();
		for (Folder folder : set) {
			Folder childFolder = new Folder();
			childFolder.setFolderName(folder.getFolderName());
			childFolder.setFolderId(folder.getFolderId());
			childFolder.setUpdatedDt(folder.getUpdatedDt());
			childFolder.setUpdatedBy(folder.getUpdatedBy());
			childFolder.setProject(orginalObject);
			FolderTreeDTO treeDTO = new FolderTreeDTO();
			treeDTO.setLabel(folder.getFolderName());
			treeDTO.setIcon("fa fa-folder");
			treeDTO.setFolderData(childFolder);
			if (folder.getFolders().isEmpty()) {
				treeDTO.setChildren(getfolderDocuments(folder.getFolderId()));
				treeDTO.setLeaf(true);
			} else {
				Set<FolderTreeDTO> children = getfolderDocuments(folder.getFolderId());
				children.addAll(childrenFoldersAndDocuments(folder.getFolders(), orginalObject));
				treeDTO.setChildren(children);

			}
			dto.add(treeDTO);
			// dto.addAll(getfolderDocuments(folder.getFolderId()));

		}
		return dto;
	}

	private Set<FolderTreeDTO> getfolderDocuments(Integer folderId) {
		List<FolderDocument> documents = folderDocumentService.getFolderDocumentsByfolderId(folderId);
		Set<FolderTreeDTO> dto = new LinkedHashSet<>();
		for (FolderDocument document : documents) {
			FolderDocument folderDocument = new FolderDocument();
			folderDocument.setDocumentName(document.getDocumentName());
			folderDocument.setDocumentId(document.getDocumentId());
			FolderTreeDTO treeDTO = new FolderTreeDTO();
			treeDTO.setLabel(document.getDocumentName());
			treeDTO.setIcon("fa fa-file");
			treeDTO.setLeaf(true);
			treeDTO.setExpanded(false);
			treeDTO.setSelectable(true);
			treeDTO.setDocumentData(folderDocument);
			dto.add(treeDTO);
		}
		return dto;
	}

	/*
	 * Get FolderHistory Info
	 */
	@RequestMapping(value = "/getFolderDocumetHistoryByFolderId/{folderId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public FolderDocumentHistoryDTO getFolderDocumentHistoryByFolderId(@PathVariable("folderId") Integer folderId) {
		Folder folder = folderService.getFolderByFolderId(folderId);
		List<FolderDocumentHistoryVw> folderDocumentHistoryVws = folderDocumentHistoryVwService
				.getFolderDocumentHistoryByFolderId(folderId);
		List<FolderHistoryVw> folderHistoryVws = folderHistoryVwService.getFolderHistoryByParentId(folderId);

		FolderDocumentHistoryDTO folderDocumentHistoryDTO = new FolderDocumentHistoryDTO();
		folderDocumentHistoryDTO.setFolderName(folder.getFolderName());
		folderDocumentHistoryDTO.setCreatedBy(folder.getCreatedBy());
		folderDocumentHistoryDTO.setUpDatedBy(folder.getUpdatedBy());
		folderDocumentHistoryDTO.setUpDatedDate(folder.getUpdatedDt());
		folderDocumentHistoryDTO.setCreatedDate(folder.getCreatedDt());
		if (!folderDocumentHistoryVws.isEmpty()) {
			folderDocumentHistoryDTO.setFolderDocuments(folderDocumentHistoryVws);
		}
		if (!folderHistoryVws.isEmpty()) {
			folderDocumentHistoryDTO.setFolderHistory(folderHistoryVws);
		}
		return folderDocumentHistoryDTO;
	}

	@RequestMapping(value = "/createFolderHistoryDownloadedInfo", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	public void createFolderDownLoadInfo(@RequestBody FolderDownloadHistory downloadHistory) {
		folderDownloadHistoryService.createFolderDownloadInfo(downloadHistory);
	}

	@RequestMapping(value = "/getFolderHistoryByFolderId/{folderId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<FolderHistoryVw> getFolderHistoryByFolderId(@PathVariable("folderId") Integer folderId) {
		return folderHistoryVwService.getFolderHistoryByFolderId(folderId);

	}

	@RequestMapping(value = "/updateFolderDocumentInfo", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	public void updateFolderDocumentInfo(@RequestBody FolderDocument folderDocument) {
		folderDocumentService.updateFolderDocumentInfo(folderDocument);
	}

	/*
	 * Download folder document history in pdf format
	 */
	@RequestMapping(value = "/downloadFolderDocumentHistoryPdf/{folderId}", method = RequestMethod.GET)
	public void getFolderDocumentHistoryPdf(HttpServletResponse response, @PathVariable("folderId") Integer folderId) {
		try {
			Folder folder = folderService.getFolderByFolderId(folderId);
			List<FolderDocumentHistoryVw> folderDocumentHistoryVws = folderDocumentHistoryVwService
					.getFolderDocumentHistoryByFolderId(folderId);
			List<FolderHistoryVw> folderHistoryVws = folderHistoryVwService.getFolderHistoryByParentId(folderId);

			FolderDocumentHistoryDTO folderDocumentHistoryDTO = new FolderDocumentHistoryDTO();
			folderDocumentHistoryDTO.setFolderName(folder.getFolderName());
			folderDocumentHistoryDTO.setCreatedBy(folder.getCreatedBy());
			folderDocumentHistoryDTO.setUpDatedBy(folder.getUpdatedBy());
			folderDocumentHistoryDTO.setUpDatedDate(folder.getUpdatedDt());
			folderDocumentHistoryDTO.setCreatedDate(folder.getCreatedDt());
			if (!folderDocumentHistoryVws.isEmpty()) {
				folderDocumentHistoryDTO.setFolderDocuments(folderDocumentHistoryVws);
			}
			if (!folderHistoryVws.isEmpty()) {
				folderDocumentHistoryDTO.setFolderHistory(folderHistoryVws);
			}
			response.setContentType(MediaType.APPLICATION_PDF_VALUE);
			response.setHeader("Content-Disposition",
					"attachment; filename=" + folderDocumentHistoryDTO.getFolderName() + ".pdf");
			ByteArrayOutputStream baos = pdfExporter.export(PDFTemplateEnum.DOCUMENT_ACTIVITY,
					Arrays.asList(PDFTemplateEnum.FOLDER_DOCUMENT_HISTORY, PDFTemplateEnum.FOLDER_HISTORY),
					Arrays.asList(folderDocumentHistoryDTO));
			ByteArrayInputStream ini = new ByteArrayInputStream(baos.toByteArray());
			// OutputStream oos = new FileOutputStream("D:\\CheckList.pdf");
			ServletOutputStream oos = response.getOutputStream();

			byte[] buf = new byte[8192];
			int c = 0;
			while ((c = ini.read(buf, 0, buf.length)) > 0) {
				oos.write(buf, 0, c);
				oos.flush();
			}

			oos.close();
			ini.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@RequestMapping(value = "/mailOfSelectedDocuments", method = RequestMethod.POST)
	public void mailOfSelectedDocuments(HttpServletResponse response, @RequestBody DocumentMailDTO documentMailDTO) {
		try {
			String currentUser = ThreadLocalUtil.getUserName();
			List<GridFSDBFile> folderDocument = folderDocumentService
					.getListOfDocumentIds(documentMailDTO.getDocumentIds());
			Map<String, InputStreamSource> documents = new HashMap<>();

			for (GridFSDBFile gridFSDBFile : folderDocument) {
				InputStream fileInputStream = gridFSDBFile.getInputStream();

				ByteArrayOutputStream buffer = new ByteArrayOutputStream();
				int nRead;
				byte[] data = new byte[1024];
				while ((nRead = fileInputStream.read(data, 0, data.length)) != -1) {
					buffer.write(data, 0, nRead);
				}

				buffer.flush();
				byte[] byteArray = buffer.toByteArray();
				String fileWithType = gridFSDBFile.getFilename() + "?" + gridFSDBFile.getContentType();
				documents.put(fileWithType, new ByteArrayResource(byteArray));
			}
			List<String> toMail = documentMailDTO.getEmails();
			List<String> ccMail = documentMailDTO.getCcMails();
			String[] to = toMail.toArray(new String[toMail.size()]);
			String[] cc = ccMail.toArray(new String[ccMail.size()]);
			String subject = documentMailDTO.getSubject();
			Map<String, Object> values = new HashMap<String, Object>();
			values.put(BqmConstants.MESSAGE, documentMailDTO.getMessage());
			values.put(BqmConstants.FNAME, currentUser);
			mailService.sendEmailWithAttachmentsOfDifferentContentTypes(MailTemplateEnum.DOCUMENT_ATTACHED_MAIL, values,
					to, cc, subject, documents);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@RequestMapping(value = "/getVersion", method = RequestMethod.POST)
	public List<Double> getVersion(@RequestParam("documentfolderid") Integer documentfolderid,
			@RequestParam("documentName") String documentName) {
		return folderDocumentService.getVersion(documentfolderid, documentName);

	}

}
