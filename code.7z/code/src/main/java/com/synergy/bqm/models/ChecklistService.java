package com.synergy.bqm.models;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "checklist_service")
public class ChecklistService implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue
	@Column(name = "id")
	private Integer checkListServiceId;

	@Column(name = "service")
	private String service;

	// getters and setters

	public String getService() {
		return service;
	}

	public Integer getCheckListServiceId() {
		return checkListServiceId;
	}

	public void setCheckListServiceId(Integer checkListServiceId) {
		this.checkListServiceId = checkListServiceId;
	}

	public void setService(String service) {
		this.service = service;
	}

}
