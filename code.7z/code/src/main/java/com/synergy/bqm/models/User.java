package com.synergy.bqm.models;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.PostLoad;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import org.hibernate.annotations.Type;

import com.guvvala.framework.model.BaseModel;
import com.guvvala.framework.util.DateUtils;

/**
 * The persistent class for the user database table.
 * 
 */
@Entity
@Table(name = "user")
@NamedQuery(name = "User.findAll", query = "SELECT u FROM User u")
public class User extends BaseModel implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "USER_ID")
	private Long userId;

	@Column(name = "user_address")
	private String userAddress;

	@Column(name = "user_company")
	private String userCompany;

	@Column(name = "user_status")
	private Integer userStatus;

	@Column(name = "admin")
	@Type(type = "boolean")
	private Boolean admin;

	@Column(name = "access_to_create_project")
	@Type(type = "boolean")
	private Boolean accessToCreateProject;

	@Column(name = "department_id")
	private Integer departmentId;

	@Column(name = "user_designation")
	private String userDesignation;

	@Column(name = "user_email")
	private String userEmail;

	@Column(name = "LOGIN_ATTEMPTS")
	private Integer loginAttempts = 0;

	@Column(name = "LAST_LOGIN_DT")
	@Temporal(TemporalType.TIMESTAMP)
	private Date lastLoginDate;

	@Column(name = "user_fax_no")
	private String userFaxNo;

	@Column(name = "user_home_contact_no")
	private String userHomeContactNo;

	@Column(name = "user_name")
	private String userName;

	@Column(name = "user_first_name")
	private String userFirstName;

	@Column(name = "user_last_name")
	private String userLastName;

	@Column(name = "user_office_contact_no")
	private String userOfficeContactNo;

	@Column(name = "PW_EXPIRATION_DT")
	@Temporal(TemporalType.TIMESTAMP)
	private Date passwordExpirationDate;

	@Column(name = "user_salt")
	private String userSalt;

	@Column(name = "pwd_hash")
	private String pwdHash;
	
	@Column(name = "user_image")
	private String userImage;

	@Transient
	private String createdDt;

	@Transient
	private String updatedDt;
	
	
	
	public User(Long userId,String userName){
		
		this.userId=userId;
		this.userName=userName;
	}

	public User() {
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public String getUserAddress() {
		return this.userAddress;
	}

	public void setUserAddress(String userAddress) {
		this.userAddress = userAddress;
	}

	public String getUserCompany() {
		return this.userCompany;
	}

	public void setUserCompany(String userCompany) {
		this.userCompany = userCompany;
	}

	public String getUserDesignation() {
		return this.userDesignation;
	}

	public void setUserDesignation(String userDesignation) {
		this.userDesignation = userDesignation;
	}

	public String getUserEmail() {
		return this.userEmail;
	}

	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}

	public String getUserFaxNo() {
		return this.userFaxNo;
	}

	public void setUserFaxNo(String userFaxNo) {
		this.userFaxNo = userFaxNo;
	}

	public String getUserHomeContactNo() {
		return this.userHomeContactNo;
	}

	public void setUserHomeContactNo(String userHomeContactNo) {
		this.userHomeContactNo = userHomeContactNo;
	}

	public String getUserName() {
		return this.userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getUserOfficeContactNo() {
		return this.userOfficeContactNo;
	}

	public void setUserOfficeContactNo(String userOfficeContactNo) {
		this.userOfficeContactNo = userOfficeContactNo;
	}

	public String getUserFirstName() {
		return userFirstName;
	}

	public void setUserFirstName(String userFirstName) {
		this.userFirstName = userFirstName;
	}

	public String getUserLastName() {
		return userLastName;
	}

	public void setUserLastName(String userLastName) {
		this.userLastName = userLastName;
	}

	public String getUserSalt() {
		return userSalt;
	}

	public void setUserSalt(String userSalt) {
		this.userSalt = userSalt;
	}

	public String getPwdHash() {
		return pwdHash;
	}

	public void setPwdHash(String pwdHash) {
		this.pwdHash = pwdHash;
	}

	public Integer getUserStatus() {
		return userStatus;
	}

	public void setUserStatus(Integer userStatus) {
		this.userStatus = userStatus;
	}

	public Integer getDepartmentId() {
		return departmentId;
	}

	public void setDepartmentId(Integer departmentId) {
		this.departmentId = departmentId;
	}

	public String getCreatedDt() {
		return createdDt;
	}

	public void setCreatedDt(String createdDt) {
		this.createdDt = createdDt;
	}

	public String getUpdatedDt() {
		return updatedDt;
	}

	public void setUpdatedDt(String updatedDt) {
		this.updatedDt = updatedDt;
	}

	public Date getPasswordExpirationDate() {
		return passwordExpirationDate;
	}

	public void setPasswordExpirationDate(Date passwordExpirationDate) {
		this.passwordExpirationDate = passwordExpirationDate;
	}

	public boolean hasPasswordExpired() {
		Date today = new Date();
		return !getPasswordExpirationDate().after(today) || getUserStatus().equals(4);
	}

	public Integer getLoginAttempts() {
		return loginAttempts;
	}

	public void setLoginAttempts(Integer loginAttempts) {
		this.loginAttempts = loginAttempts;
	}

	public Date getLastLoginDate() {
		return lastLoginDate;
	}

	public void setLastLoginDate(Date lastLoginDate) {
		this.lastLoginDate = lastLoginDate;
	}

	public Boolean getAdmin() {
		return admin;
	}

	public void setAdmin(Boolean admin) {
		this.admin = admin;
	}

	public Boolean getAccessToCreateProject() {
		return accessToCreateProject;
	}

	public void setAccessToCreateProject(Boolean accessToCreateProject) {
		this.accessToCreateProject = accessToCreateProject;
	}
	public String getUserImage() {
		return userImage;
	}

	public void setUserImage(String userImage) {
		this.userImage = userImage;
	}
	@PostLoad
	void postload() {
		setCreatedDt(DateUtils.convertToSimpleDateTimeFormat(getCreatedDate()));
		setUpdatedDt(DateUtils.convertToSimpleDateTimeFormat(getUpdatedDate()));
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((userId == null) ? 0 : userId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		User other = (User) obj;
		if (userId == null) {
			if (other.userId != null)
				return false;
		} else if (!userId.equals(other.userId))
			return false;
		return true;
	}

}