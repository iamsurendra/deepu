package com.synergy.bqm.services;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.synergy.bqm.models.UserRoleMapping;
import com.synergy.bqm.repositories.UserRoleMappingDAO;

@Service("userRoleMapping")
public class UserRoleMappingServiceImpl implements UserRoleMappingService {
	
	@Autowired
	UserRoleMappingDAO userRoleMappingDAO;
	
	@Transactional
	public void createUserRoleMapping(UserRoleMapping userRoleMapping){
		userRoleMappingDAO.create(userRoleMapping);
	}

}
