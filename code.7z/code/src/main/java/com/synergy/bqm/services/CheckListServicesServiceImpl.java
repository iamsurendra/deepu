package com.synergy.bqm.services;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.synergy.bqm.json.CheckListServiceDTO;
import com.synergy.bqm.models.ChecklistService;
import com.synergy.bqm.repositories.CheckListServiceDAO;

@Service
public class CheckListServicesServiceImpl implements CheckListServicesService {

	@Autowired
	CheckListServiceDAO checkListServiceDAO;

	@Transactional
	public List<ChecklistService> getAllChecklistType() {
		return checkListServiceDAO.findAll();

	}

	@Transactional
	public List<String> getCheckListServices() {
		return checkListServiceDAO.getCheckListServices();

	}

	@Transactional
	public void createAndUpdateChecklistService(CheckListServiceDTO checkListServiceDTO) {

		if (!checkListServiceDTO.getCheckListServices().isEmpty()) {
			for (ChecklistService checklisttype : checkListServiceDTO.getCheckListServices()) {
				if (checklisttype.getCheckListServiceId() == null) {
					checkListServiceDAO.create(checklisttype);
				} else {
					checkListServiceDAO.update(checklisttype);
				}
			}

		}

		if ((checkListServiceDTO.getDeletedIds()!=null)&&(!checkListServiceDTO.getDeletedIds().isEmpty())) {
			List<ChecklistService> checklistServices = checkListServiceDAO
					.getCheckListServicesInfoById(checkListServiceDTO.getDeletedIds());

			for (ChecklistService checklistService : checklistServices) {
				checkListServiceDAO.delete(checklistService);
			}
		}
	}

}
