package com.synergy.bqm.repositories;

import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.guvvala.framework.dao.BaseDAOImpl;
import com.synergy.bqm.models.ActivityHistory;


@Repository
public class ActivityHistoryDAOImpl extends BaseDAOImpl<ActivityHistory, Integer>implements  ActivityHistoryDAO{

	public ActivityHistoryDAOImpl() {
		super(ActivityHistory.class);
	}
	
	public List<ActivityHistory> getActivityHistoryByIndexId(Integer  indexId) {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<ActivityHistory> criteriaQuery = criteriaBuilder.createQuery(ActivityHistory.class);
		Root<ActivityHistory> root = criteriaQuery.from(ActivityHistory.class);
		criteriaQuery.select(root);
		criteriaQuery.where(criteriaBuilder.equal((root.get("documentIndex").get("id")),indexId));
		return entityManager.createQuery(criteriaQuery).getResultList();

	}
	
	

}
