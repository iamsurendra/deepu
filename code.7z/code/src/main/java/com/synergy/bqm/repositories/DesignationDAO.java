package com.synergy.bqm.repositories;

import java.util.List;

import com.guvvala.framework.dao.BaseDAO;
import com.synergy.bqm.models.Designation;

public interface DesignationDAO extends BaseDAO<Designation, Integer>{
	
	
	public List<String> getDesignationNames();

	public void deleteDesignationIds(List<Integer> designationIds);
}
