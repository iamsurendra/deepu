package com.synergy.bqm.controllers;

import java.io.IOException;
import java.text.ParseException;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.synergy.bqm.json.ActivityTypesDTO;
import com.synergy.bqm.json.IndexDocumentDTO;
import com.synergy.bqm.json.NormalSearchDTO;
import com.synergy.bqm.models.ActivityHistory;
import com.synergy.bqm.models.ActivityTypes;
import com.synergy.bqm.models.DocumentIndex;
import com.synergy.bqm.models.DocumentIndexVw;
import com.synergy.bqm.models.FolderDocument;
import com.synergy.bqm.models.User;
import com.synergy.bqm.services.ActivityHistoryService;
import com.synergy.bqm.services.ActivityTypesService;
import com.synergy.bqm.services.DocumentIndexService;
import com.synergy.bqm.services.DocumentIndexVwService;
import com.synergy.bqm.services.FolderService;

@RestController
@RequestMapping("/api/activity")
public class ActivityController {

	@Autowired
	ActivityTypesService activityTypesService;

	@Autowired
	DocumentIndexService documentIndexService;

	@Autowired
	DocumentIndexVwService documentIndexVwService;

	@Autowired
	FolderService folderService;

	@Autowired
	ActivityHistoryService activityHistoryService;

	// List of MainActivities
	@RequestMapping(value = "/findAllActivities", method = RequestMethod.GET, consumes = MediaType.APPLICATION_JSON_VALUE)
	public List<ActivityTypes> findAllActivities() {
		return activityTypesService.findAllActivities();
	}

	// Create and update Main Activity
	@RequestMapping(value = "/createAndUpdateActivityTypes", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	public void saveActivityTypes(@RequestBody ActivityTypesDTO activityTypesDTO) {
		activityTypesService.createAndUpdateActivityTypes(activityTypesDTO);
	}

	// DocumentIndex by Id
	@RequestMapping(value = "/getDocumentIndexVwById", method = RequestMethod.POST, consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	public DocumentIndexVw getDocumentIndexVwById(@RequestParam("Id") Integer Id) {
		return documentIndexVwService.getDocumentIndexById(Id);
	}

	// create sub-Activity
	@RequestMapping(value = "/createDocumentIndex", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	public void createDocumentIndex(@RequestBody DocumentIndex documentIndex) {
		documentIndexService.createDocumentIndex(documentIndex);
	}

	// List of sub Activities by projectId for dash board
	@RequestMapping(value = "/getDocumentIndexListByProjectId", method = RequestMethod.POST, consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	public List<DocumentIndex> getDocumentIndexListByProjectId(@RequestParam("projectId") Integer projectId) {
		return documentIndexService.getDocumentIndexListByProjectId(projectId);
	}

	// List of sub Activities by projectId for dash board . And search
	@RequestMapping(value = "/getDocumentIndexListVwByProjectId", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	public List<DocumentIndexVw> getDocumentIndexVwByProjectId(@RequestBody NormalSearchDTO normalSearch)
			throws ParseException {

		if (normalSearch.getIsglobalsearch() != null && normalSearch.getIsglobalsearch()) {
			return documentIndexVwService.getFolderDocumentIndexSearch(normalSearch.getProjectId(),
					normalSearch.getGlobalsearchString());
		} else if (normalSearch.getIsglobalsearch() != null && !normalSearch.getIsglobalsearch()) {

			return documentIndexVwService.getFolderDocumentIndexNormalSearch(normalSearch);

		} else {
			return documentIndexVwService.getDocumentIndexVwByProjectId(normalSearch.getProjectId());
		}

	}

	// List of Empty Activities to add document
	@RequestMapping(value = "/getDocumentIndexListByProjectIdDocumentPathNull", method = RequestMethod.POST, consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	public List<DocumentIndex> getDocumentIndexListByProjectIdDocumentPathNull(
			@RequestParam("projectId") Integer projectId) {
		return documentIndexService.getDocumentIndexListByProjectIdDocumentPathNull(projectId);
	}

	// Get DocumentIndex By Id with work flow states and checklist(While Adding new Document)
	@RequestMapping(value = "/getDocumentIndexByIndexId", method = RequestMethod.POST, consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	public DocumentIndex getDocumentIndexByIndexId(@RequestParam("documentIndexid") Integer documentIndexid) {
		return documentIndexService.getDocumentIndexByIndexId(documentIndexid);
	}

	// Edit Activity By DocumentId with work flow states and checklist(While Editing Existing Document)
	@RequestMapping(value = "/getDocumentIndexByDocumentId", method = RequestMethod.POST, consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	public DocumentIndex getDocumentIndexByDocumentId(@RequestParam("documentId") Integer documentId) {
		return documentIndexService.getDocumentIndexByDocumentId(documentId);
	}

	// Get DocumentIndexView By Id with work flow states and checklist
	@RequestMapping(value = "/getDocumentIndexViewByIndexId", method = RequestMethod.POST, consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	public DocumentIndexVw getDocumentInexViewByIndexId(@RequestParam("documentIndexid") Integer documentIndexid) {
		return documentIndexVwService.getDocumentIndexViewByIndexId(documentIndexid);
	}

	// Get Responsible User List by stateId
	@RequestMapping(value = "/getResponsibleUsers", method = RequestMethod.POST, consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	public List<User> getResponsibleUsersList(@RequestParam("stateId") Integer stateId,
			@RequestParam("folderId") Integer folderId) {
		return documentIndexService.getResponsibleUsersList(stateId, folderId,false);
	}
	
	@RequestMapping(value = "/checkForDepartmentAccess", method = RequestMethod.POST, consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)	
	public void checkForDepartment(@RequestParam("folderId") Integer folderId){
		documentIndexService.checkForDepartmentAccess(folderId);
	}

	// Update Index at work flow Level
	@RequestMapping(value = "/updateIndex", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	public void updateIndex(@RequestBody DocumentIndex documentIndex) {
		documentIndexService.updateIndex(documentIndex);
	}

	// upload IndexFile With IndexData
	@RequestMapping(value = "/saveIndexData", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	public void saveIndexData(@RequestBody IndexDocumentDTO indexDocumentDTO) {
		indexDocumentDTO.getDocumentIndex().setFolderId(indexDocumentDTO.getFolderId());
		indexDocumentDTO.getDocumentIndex().setDocumentName(indexDocumentDTO.getFolderDocument().getDocumentName());
		indexDocumentDTO.getDocumentIndex().setDocumentId(indexDocumentDTO.getFolderDocument().getDocumentId());
		documentIndexService.updateIndex(indexDocumentDTO.getDocumentIndex());

	}

	// upload IndexFile
	@RequestMapping(value = "/saveIndexFile", method = RequestMethod.POST)
	public FolderDocument saveIndexFile(@RequestParam("file") MultipartFile file,
			@RequestParam("folderId") Integer folderId, @RequestParam("editMode") boolean editMode,
			@RequestParam("description") String description, @RequestParam("projectId") Integer projectId,
			@RequestParam("version") Double version) throws IOException {
		boolean indexFile = true;
		return folderService.saveIndexFile(file, folderId, projectId, editMode, description, version, indexFile);

	}

	// Activity Notification list by userId
	@RequestMapping(value = "/indexNotificationList", method = RequestMethod.POST, consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	public List<DocumentIndexVw> getDocumentIndexNotification(@RequestParam("userId") Integer userId) {
		return documentIndexVwService.getDocumentIndexNotification(userId);

	}

	@RequestMapping(value = "/getFolderDocumentListByMainActivityAndProjectId", method = RequestMethod.POST, consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	public List<DocumentIndexVw> getFolderDocumentListByMainActivityAndProjectId(
			@RequestParam("activityId") Integer activityId, @RequestParam("projectId") Integer projectId) {
		return documentIndexVwService.getFolderDocumentListByMainActivityAndProjectId(activityId, projectId);
	}

	@RequestMapping(value = "/getDocumentIndexByActivityId", method = RequestMethod.POST, consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	public List<DocumentIndex> getDocumentIndexByActivityId(@RequestParam("ActivityId") Integer activityId) {
		return documentIndexService.getDocumentIndexByActivityId(activityId);

	}

	@RequestMapping(value = "/documentIndexNormalSearch", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	public List<DocumentIndexVw> getFolderDocumentIndexNormalSearch(@RequestBody NormalSearchDTO normalSearch) {
		return documentIndexVwService.getFolderDocumentIndexNormalSearch(normalSearch);
	}

	@RequestMapping(value = "/updateActivity", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	public void updateActivity(@RequestBody DocumentIndex documentIndex) {
		documentIndexService.updateActivity(documentIndex);

	}

	@RequestMapping(value = "/countOfDocumentIndexByState", method = RequestMethod.POST, consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	public Map<Integer, Long> countOfDocumentIndexBystate(@RequestParam("projectId") Integer projectId) {
		return documentIndexVwService.countOfDocumentIndexBystate(projectId);

	}

	@RequestMapping(value = "/countOfDocumentIndexByDepartment", method = RequestMethod.POST, consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	public Map<String, Map<Integer, Long>> countOfDocumentIndexByDepartment(Integer projectId) {
		return documentIndexVwService.countOfDocumentIndexByDepartment(projectId);
	}
	
	@RequestMapping(value = "/getactivityHistoryByIndexId", method = RequestMethod.POST, consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	public List<ActivityHistory>getactivityHistoryByIndexId(Integer indexId){
		return activityHistoryService.getActivityHistoryByIndexId(indexId);
		
	}

}
