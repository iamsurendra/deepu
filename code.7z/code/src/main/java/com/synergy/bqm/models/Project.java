package com.synergy.bqm.models;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.PostLoad;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import org.hibernate.annotations.Type;

import com.guvvala.framework.model.BaseModel;
import com.guvvala.framework.model.BaseModelListener;
import com.guvvala.framework.util.DateUtils;

/**
 * The persistent class for the project database table.
 * 
 */
@Entity
@EntityListeners(BaseModelListener.class)
@Table(name = "project")
@NamedQuery(name = "Project.findAll", query = "SELECT p FROM Project p")
public class Project extends BaseModel implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue
	@Column(name = "project_id")
	private int projectId;

	@Temporal(TemporalType.DATE)
	@Column(name = "end_date")
	private Date endDate;

	@Column(name = "enquiry_no")
	private String enquiryNo;

	@Column(name = "job_no")
	private String jobNo;

	@Column(name = "po_ref")
	private String poRef;

	@Column(name = "project_client")
	private Integer projectClient;

	@Column(name = "project_manager")
	private int projectManager;

	@Column(name = "project_name")
	private String projectName;

	private String stage;

	@Column(name = "start_date")
	@Temporal(TemporalType.DATE)
	private Date startDate;

	@Column(name = "status")
	private String status;

	@Column(name = "sub_type")
	private String subType;

	@Column(name = "location")
	private String location;

	@Column(name = "archive")
	@Type(type = "boolean")
	private Boolean archive;

	@Column(name = "client_contact")
	private String clientContact;

	@Column(name = "role")
	private String role;

	@Column(name = "project_number")
	private int projectNumber;

	@Column(name = "type")
	private String type;

	@Column(name = "logo")
	private String logo;

	@Column(name = "template_loaded")
	@Type(type = "boolean")
	private Boolean template;

	@Transient
	private String createdDt;

	@Transient
	private String updatedDt;

	// bi-directional many-to-one association to User //@MapsId()

	// bi-directional many-to-one association to ProjectMember
	@OneToMany(mappedBy = "project", cascade = CascadeType.ALL, fetch = FetchType.EAGER, orphanRemoval = true)
	private Set<ProjectMember> projectMembers;

	// bi-directional many-to-one association to ProjectMember
	@OneToMany(mappedBy = "project", cascade = CascadeType.ALL, fetch = FetchType.EAGER, orphanRemoval = true)
	private Set<VendorProjectMapping> vendorProjectMapping;

	@Transient
	private String createdUser;

	@Transient
	private String upDatedUser;

	@Transient
	private String projectMngr;

	@Transient
	private String stringArchive;

	@Transient
	private List<Integer> deletedProjectMembers;

	@Transient
	private List<Integer> deletedVendors;

	public Project() {
	}

	public String getCreatedUser() {
		return createdUser;
	}

	public void setCreatedUser(String createdUser) {
		this.createdUser = createdUser;
	}

	public String getUpDatedUser() {
		return upDatedUser;
	}

	public void setUpDatedUser(String upDatedUser) {
		this.upDatedUser = upDatedUser;
	}

	public int getProjectId() {
		return this.projectId;
	}

	public void setProjectId(int projectId) {
		this.projectId = projectId;
	}

	public Date getEndDate() {
		return this.endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public String getEnquiryNo() {
		return this.enquiryNo;
	}

	public void setEnquiryNo(String enquiryNo) {
		this.enquiryNo = enquiryNo;
	}

	public String getJobNo() {
		return this.jobNo;
	}

	public void setJobNo(String jobNo) {
		this.jobNo = jobNo;
	}

	public String getPoRef() {
		return this.poRef;
	}

	public void setPoRef(String poRef) {
		this.poRef = poRef;
	}

	public Integer getProjectClient() {
		return projectClient;
	}

	public void setProjectClient(Integer projectClient) {
		this.projectClient = projectClient;
	}

	public int getProjectManager() {
		return this.projectManager;
	}

	public void setProjectManager(int projectManager) {
		this.projectManager = projectManager;
	}

	public String getProjectName() {
		return this.projectName;
	}

	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}

	public String getStage() {
		return this.stage;
	}

	public void setStage(String stage) {
		this.stage = stage;
	}

	public Date getStartDate() {
		return this.startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getSubType() {
		return this.subType;
	}

	public void setSubType(String subType) {
		this.subType = subType;
	}

	public String getType() {
		return this.type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public Boolean getArchive() {
		return archive;
	}

	public void setArchive(Boolean archive) {
		this.archive = archive;
	}

	public String getClientContact() {
		return clientContact;
	}

	public void setClientContact(String clientContact) {
		this.clientContact = clientContact;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public int getProjectNumber() {
		return projectNumber;
	}

	public void setProjectNumber(int projectNumber) {
		this.projectNumber = projectNumber;
	}

	public String getCreatedDt() {
		return createdDt;
	}

	public void setCreatedDt(String createdDt) {
		this.createdDt = createdDt;
	}

	public String getUpdatedDt() {
		return updatedDt;
	}

	public void setUpdatedDt(String updatedDt) {
		this.updatedDt = updatedDt;
	}

	public String getProjectMngr() {
		return projectMngr;
	}

	public void setProjectMngr(String projectMngr) {
		this.projectMngr = projectMngr;
	}

	public Boolean getTemplate() {
		return template;
	}

	public void setTemplate(Boolean template) {
		this.template = template;
	}

	public String getLogo() {
		return logo;
	}

	public void setLogo(String logo) {
		this.logo = logo;
	}

	public List<Integer> getDeletedProjectMembers() {
		return deletedProjectMembers;
	}

	public void setDeletedProjectMembers(List<Integer> deletedProjectMembers) {
		this.deletedProjectMembers = deletedProjectMembers;
	}

	public String getStringArchive() {
		return stringArchive;
	}

	public void setStringArchive(String stringArchive) {
		this.stringArchive = stringArchive;
	}

	public List<Integer> getDeletedVendors() {
		return deletedVendors;
	}

	public void setDeletedVendors(List<Integer> deletedVendors) {
		this.deletedVendors = deletedVendors;
	}

	public Set<VendorProjectMapping> getVendorProjectMapping() {
		return vendorProjectMapping;
	}

	public void setVendorProjectMapping(Set<VendorProjectMapping> vendorProjectMapping) {
		this.vendorProjectMapping = vendorProjectMapping;
	}

	public Set<ProjectMember> getProjectMembers() {
		return projectMembers;
	}

	public void setProjectMembers(Set<ProjectMember> projectMembers) {
		this.projectMembers = projectMembers;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	@PostLoad
	void postload() {
		setCreatedDt(DateUtils.convertToSimpleDateTimeFormat(getCreatedDate()));
		setUpdatedDt(DateUtils.convertToSimpleDateTimeFormat(getUpdatedDate()));

	}
}