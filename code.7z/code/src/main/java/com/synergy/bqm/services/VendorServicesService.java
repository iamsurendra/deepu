package com.synergy.bqm.services;

import java.util.List;

import com.synergy.bqm.models.VendorServices;

public interface VendorServicesService {

	public List<VendorServices> getAllVendorServices();
	
	public void createOrUpdateOrDeleteVendorService(List<VendorServices> vendorServices);
}
