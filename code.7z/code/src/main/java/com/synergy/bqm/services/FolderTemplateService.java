package com.synergy.bqm.services;

import java.util.List;

import com.synergy.bqm.models.FolderTemplate;

public interface FolderTemplateService {

	List<FolderTemplate> getFolderNameByTemplateId(Integer templateId);

	FolderTemplate createFolder(FolderTemplate folderTemplate);

	FolderTemplate updateFolder(FolderTemplate folderTemplate);

	List<FolderTemplate> getChildFolderNameByTemplateId(Integer templateId, Integer folderId);

	FolderTemplate folderMoving(FolderTemplate folderTemplate);
	
	public void deleteFolder(Integer folderId);
	
	public void reCreatFolderTemplate(Integer templateId,String templateName);
	
	public List<FolderTemplate> getFolderInfoListByFolderId(Integer folderId);
	
	 public List<FolderTemplate> getChildFolderByFolderId(Integer folderId);

}
