package com.synergy.bqm.constants;

public class EnvConstants {


	
}
