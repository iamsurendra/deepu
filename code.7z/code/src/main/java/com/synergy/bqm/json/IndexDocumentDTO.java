package com.synergy.bqm.json;

import com.synergy.bqm.models.DocumentIndex;
import com.synergy.bqm.models.FolderDocument;

public class IndexDocumentDTO {

	
	private DocumentIndex documentIndex;
	private Integer folderId;
	private Integer projectId;
	private FolderDocument folderDocument;

	// getters and setters

	public Integer getFolderId() {
		return folderId;
	}

	public void setFolderId(Integer folderId) {
		this.folderId = folderId;
	}

	public Integer getProjectId() {
		return projectId;
	}

	public void setProjectId(Integer projectId) {
		this.projectId = projectId;
	}

	public DocumentIndex getDocumentIndex() {
		return documentIndex;
	}

	public void setDocumentIndex(DocumentIndex documentIndex) {
		this.documentIndex = documentIndex;
	}

	public FolderDocument getFolderDocument() {
		return folderDocument;
	}

	public void setFolderDocument(FolderDocument folderDocument) {
		this.folderDocument = folderDocument;
	}

}
