package com.synergy.bqm.json;

import java.util.List;

import com.synergy.bqm.models.FolderDocumentHistoryVw;
import com.synergy.bqm.models.FolderHistoryVw;

public class FolderDocumentHistoryDTO {

	private String folderName;

	private String createdDate;

	private String upDatedDate;

	private String createdBy;

	private String upDatedBy;

	private List<FolderDocumentHistoryVw> folderDocuments;

	private List<FolderHistoryVw> folderHistory;

	// Getters && Setters

	public List<FolderDocumentHistoryVw> getFolderDocuments() {
		return folderDocuments;
	}

	public void setFolderDocuments(List<FolderDocumentHistoryVw> folderDocuments) {
		this.folderDocuments = folderDocuments;
	}

	public String getFolderName() {
		return folderName;
	}

	public void setFolderName(String folderName) {
		this.folderName = folderName;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public String getUpDatedDate() {
		return upDatedDate;
	}

	public void setUpDatedDate(String upDatedDate) {
		this.upDatedDate = upDatedDate;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getUpDatedBy() {
		return upDatedBy;
	}

	public void setUpDatedBy(String upDatedBy) {
		this.upDatedBy = upDatedBy;
	}

	public List<FolderHistoryVw> getFolderHistory() {
		return folderHistory;
	}

	public void setFolderHistory(List<FolderHistoryVw> folderHistory) {
		this.folderHistory = folderHistory;
	}

}
