package com.synergy.bqm.services;

import java.util.List;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.synergy.bqm.models.Department;
import com.synergy.bqm.repositories.DepartmentDAO;
import com.synergy.bqm.repositories.FolderDepartmentMappingDAO;

@Service
public class FolderDepartmentMappingServiceImpl implements FolderDepartmentMappingService {

	@Autowired
	FolderDepartmentMappingDAO folderDepartmentMappingDAO;

	@Autowired
	DepartmentDAO departmentDAO;

	@Transactional
	public Department getDepartmentNameById(Integer folderId) {
		Integer departmentId = folderDepartmentMappingDAO.findAll().stream()
				.filter(s -> s.getFolderId().equals((folderId.intValue()))).collect(Collectors.toList()).get(0)
				.getDepartmentId();
		return departmentDAO.findOne(departmentId);
	}
	
	@Transactional
	public List<Integer> getDepartmentIds(Integer folderId){
		return folderDepartmentMappingDAO.getDepartmentIds(folderId);
		
	}
}
