package com.synergy.bqm.repositories;

import java.util.List;

import com.guvvala.framework.dao.BaseDAO;
import com.synergy.bqm.models.Role;

public interface RolesDAO extends BaseDAO<Role, Integer>{
	
	 List<String> getRoleNames();
	 
	 public List<Role> getRoleInfoById(List<Integer> ids);
	 
	 public List<Role> findAllRoles();
	 
		public String getRoleNameById(Integer id);

}
