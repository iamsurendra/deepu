package com.synergy.bqm.documents;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

public class InfoQuestionTypeTemplate extends BaseQuestionTypeTemplate {

	public static final String QUESTION_TYPE = "INFO";

	public InfoQuestionTypeTemplate() {

	}

	@JsonCreator
	public InfoQuestionTypeTemplate(@JsonProperty("lineItemQuestion") String lineItemQuestion,
			@JsonProperty("lineItemToolTip") String lineItemToolTip,
			@JsonProperty("questionType") String questionType) {
		super(lineItemQuestion, lineItemToolTip, questionType);

	}
}
