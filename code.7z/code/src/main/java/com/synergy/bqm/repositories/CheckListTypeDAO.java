package com.synergy.bqm.repositories;

import java.util.List;

import com.guvvala.framework.dao.BaseDAO;
import com.synergy.bqm.models.CheckListType;

public interface CheckListTypeDAO extends BaseDAO<CheckListType, Integer> {

	public List<String> getCheckListTypeNames();

	public List<CheckListType> getCheckListTypeInfoById(List<Integer> Ids);
}
