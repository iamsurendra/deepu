package com.synergy.bqm.services;

import java.util.List;

import com.synergy.bqm.models.Department;

public interface FolderDepartmentMappingService {
	
	public Department getDepartmentNameById(Integer folderId);
	
	public List<Integer> getDepartmentIds(Integer folderId);

}
