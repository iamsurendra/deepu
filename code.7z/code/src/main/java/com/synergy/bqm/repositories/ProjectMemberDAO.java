package com.synergy.bqm.repositories;

import java.util.List;

import com.guvvala.framework.dao.BaseDAO;
import com.synergy.bqm.models.ProjectMember;

public interface ProjectMemberDAO extends BaseDAO<ProjectMember, Integer> {

	public List<ProjectMember> getProjectMemberInfo(Integer projectId);

	public List<ProjectMember> getProjectMemberInfoByDepartmentIdsNotInoperator(List<Integer> departmentIds);

	public List<ProjectMember> getProjectMemberInfoByDepartmentIdInOperator(List<Integer> departmentIds);

	public List<Long> getUserIdListByProjectId(Integer projectId);

	public List<Integer> getRoleIdsByProjectIdsAndUserIds(Integer projectId, Integer userId);

	public List<Integer> getProjectsIdByUserIds(Integer userId);
	
	public Integer getProjectMemberInfo(Integer projectId, Integer userId);
	
	public ProjectMember getProjectMember(Integer projectId, Integer userId);
	
	public List<Integer> getUserIdslist(Integer projectId, Integer roleId,Integer deptId);
	
	public Integer getRoleId(Integer projectId, Long userId,Integer deptId);
	
	public List<ProjectMember> getProjectMemberInfo(Integer projectId,Integer userId,List<Integer> departmentIds);
}
