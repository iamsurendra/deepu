package com.synergy.bqm.services;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.synergy.bqm.models.Project;
import com.synergy.bqm.models.ProjectStatus;
import com.synergy.bqm.repositories.ProjectDAO;
import com.synergy.bqm.repositories.ProjectStatusDAO;

@Service("projectStatusService")
public class ProjectStatusServiceImpl implements ProjectStatusService {

	@Autowired
	ProjectStatusDAO projectStatusDAO;

	@Autowired
	ProjectDAO projectDAO;

	@Transactional
	public List<String> getprojectStatusNames() {
		return projectStatusDAO.getprojectStatusNames();

	}

	@Transactional
	public List<ProjectStatus> getAllProjectStatus() {
		return projectStatusDAO.findAll();
	}

	@Transactional
	public void deleteProjectStatus(Integer Id) {
		ProjectStatus deletedProjectStatus = projectStatusDAO.findOne(Id);
		projectStatusDAO.delete(deletedProjectStatus);
	}

	@Transactional
	public void createOrUpdateProjectStatus(List<ProjectStatus> projectStatus,List<Integer> deletedIds) {
		
		if(!deletedIds.isEmpty()){
			List<String> status = projectStatusDAO.getProjectStatusInfoById(deletedIds);
			List<Project> projects = projectDAO.getProjectInfoByStatus(status);
			if(!projects.isEmpty()){
				for(Project project:projects){
					project.setStatus(null);
				}
			}
			for(Integer id:deletedIds){
				deleteProjectStatus(id);
			}
		}
		if(!projectStatus.isEmpty()){
			for(ProjectStatus status:projectStatus){
				if(status.getProjectStatusId()==null){
					projectStatusDAO.create(status);
				}else {
					projectStatusDAO.update(status);
				}
			}
		}
	}
}
