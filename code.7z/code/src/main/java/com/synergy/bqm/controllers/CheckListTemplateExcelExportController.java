package com.synergy.bqm.controllers;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;

import javax.servlet.http.HttpServletResponse;

import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.guvvala.framework.errorHandler.AppException;
import com.synergy.bqm.constants.MessagesEnum;
import com.synergy.bqm.documents.BaseQuestionTypeTemplate;
import com.synergy.bqm.documents.ChecklistTemplate;
import com.synergy.bqm.documents.SectionTemplate;
import com.synergy.bqm.documents.SubsectionTemplate;
import com.synergy.bqm.documents.TextQuestionTypeTemplate;
import com.synergy.bqm.mongoRepositories.CheckListTemplateRepository;

@RestController
@RequestMapping("/api/checkListTemplateExcel")
public class CheckListTemplateExcelExportController {
	@Autowired
	CheckListTemplateRepository checkListRepository;

	@RequestMapping(value = "downLoadExcel/{Id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public void doExport(@PathVariable("Id") String Id, HttpServletResponse response) throws IOException {
		ChecklistTemplate checklist = checkListRepository.findOne(Id);
		if (checklist == null) {

			throw new AppException(MessagesEnum.CHEKLISTTEMPLATEEMPTY);

		} else {
			XSSFWorkbook wb = new XSSFWorkbook();
			XSSFSheet sheet = wb.createSheet("Sheet1");
			XSSFRow rowhead = sheet.createRow((short) 0);
			rowhead.createCell((short) 0).setCellValue("CHECKLIST_NAME");
			rowhead.createCell((short) 1).setCellValue("CHECKLIST_SERVICE");
			rowhead.createCell((short) 2).setCellValue("CHECKLIST_TYPE");
			int i = 1;
			XSSFRow row = sheet.createRow((short) i);
			row.createCell((short) 0).setCellValue(checklist.getChecklistName());
			row.createCell((short) 1).setCellValue(checklist.getChecklistService());
			row.createCell((short) 2).setCellValue(checklist.getChecklistType());
			i++;
			XSSFSheet sheet1 = wb.createSheet("Sheet2");
			XSSFRow rowhead1 = sheet1.createRow((short) 0);
			rowhead1.createCell((short) 0).setCellValue("REFERENCE");
			rowhead1.createCell((short) 1).setCellValue("SECTION_NAME");
			rowhead1.createCell((short) 2).setCellValue("SECTION_INFO");
			rowhead1.createCell((short) 3).setCellValue("SUB_SECTION_NAME");
			rowhead1.createCell((short) 4).setCellValue("SUB_SECTION_INFO");
			rowhead1.createCell((short) 5).setCellValue("QUESTION_TYPE");
			int j = 1;
			int k = 1;
			int a = 1;
			for (SectionTemplate section : checklist.getSectionList()) {

				if ((section.getSubsectionList().isEmpty()) || (!checklist.getSectionList().isEmpty())) {
					XSSFRow row1 = sheet1.createRow(j);
					// row1.createCell(0).setCellValue(String.valueOf(a));
					row1.createCell(0).setCellValue(a);
					row1.createCell(1).setCellValue(section.getSectionName());
					row1.createCell(2).setCellValue(section.getSectionInfo());
					row1.createCell(5).setCellValue(section.getQuestionType());
					String d = String.valueOf(k);
					XSSFSheet sheet2 = wb.createSheet(d);
					XSSFRow rowhead2 = sheet2.createRow((short) 0);
					rowhead2.createCell((short) 0).setCellValue("S.NO");
					rowhead2.createCell((short) 1).setCellValue("QUESTION");
					rowhead2.createCell((short) 2).setCellValue("QUESTION_INFO");
					rowhead2.createCell((short) 3).setCellValue("QUESTION_TYPE");
					rowhead2.createCell((short) 4).setCellValue("LOWER_LIMIT");
					rowhead2.createCell((short) 5).setCellValue("UPPER_LIMIT");

					int m = 1;
					int s = 1;

					// section question list sheet created

					for (BaseQuestionTypeTemplate QuestionList : section.getQuestionList()) {
						XSSFRow row2 = sheet2.createRow(m);
						// row2.createCell(0).setCellValue(String.valueOf(s));
						row2.createCell(0).setCellValue(s);
						row2.createCell(1).setCellValue(QuestionList.getLineItemQuestion());
						row2.createCell(2).setCellValue(QuestionList.getLineItemToolTip());
						row2.createCell(3).setCellValue(QuestionList.getQuestionType());
						if (QuestionList.getQuestionType().equals("TEXT")) {
							TextQuestionTypeTemplate textQuestionType = (TextQuestionTypeTemplate) QuestionList;

							row2.createCell(4).setCellValue(textQuestionType.getLowerLimit());
							row2.createCell(5).setCellValue(textQuestionType.getUpperLimit());

						}
						s++;
						m++;
					}
					j++;
					k++;
					a++;
				}
				// subsection questionlist created

				for (SubsectionTemplate Subsection : section.getSubsectionList()) {
					XSSFRow row1 = sheet1.createRow(j);
					// row1.createCell(0).setCellValue(String.valueOf(a));
					row1.createCell(0).setCellValue(a);
					row1.createCell(1).setCellValue(section.getSectionName());
					row1.createCell(2).setCellValue(section.getSectionInfo());
					row1.createCell(3).setCellValue(Subsection.getSubsectionName());
					row1.createCell(4).setCellValue(Subsection.getSubsectionInfo());
					row1.createCell(5).setCellValue(Subsection.getQuestionType());
					String d = String.valueOf(k);
					XSSFSheet sheet2 = wb.createSheet(d);
					XSSFRow rowhead2 = sheet2.createRow((short) 0);
					rowhead2.createCell((short) 0).setCellValue("S.NO");
					rowhead2.createCell((short) 1).setCellValue("QUESTION");
					rowhead2.createCell((short) 2).setCellValue("QUESTION_INFO");
					rowhead2.createCell((short) 3).setCellValue("QUESTION_TYPE");
					rowhead2.createCell((short) 4).setCellValue("LOWER_LIMIT");
					rowhead2.createCell((short) 5).setCellValue("UPPER_LIMIT");
					int m = 1;
					int s = 1;
					// question added
					for (BaseQuestionTypeTemplate QuestionList : Subsection.getQuestionList()) {
						XSSFRow row2 = sheet2.createRow(m);
						// row2.createCell(0).setCellValue(String.valueOf(s));
						row2.createCell(0).setCellValue(s);
						row2.createCell(1).setCellValue(QuestionList.getLineItemQuestion());
						row2.createCell(2).setCellValue(QuestionList.getLineItemToolTip());
						row2.createCell(3).setCellValue(QuestionList.getQuestionType());
						if (QuestionList.getQuestionType().equals("TEXT")) {
							TextQuestionTypeTemplate textQuestionType = (TextQuestionTypeTemplate) QuestionList;

							row2.createCell(4).setCellValue(textQuestionType.getLowerLimit());
							row2.createCell(5).setCellValue(textQuestionType.getUpperLimit());

						}
						s++;
						m++;
					}

					j++;
					k++;
					a++;
				}

			}
			ByteArrayOutputStream outByteStream = new ByteArrayOutputStream();
			wb.write(outByteStream);
			byte[] outArray = outByteStream.toByteArray();
			response.setContentType(MediaType.APPLICATION_OCTET_STREAM_VALUE);
			response.setContentLength(outArray.length);
			response.setHeader("Expires:", "0"); // eliminates browser caching
			response.setHeader("Content-Disposition", "attachment; filename=" + checklist.getChecklistName() + ".xlsx");
			OutputStream outStream = response.getOutputStream();
			outStream.write(outArray);
			outStream.flush();

		}
	}

}
