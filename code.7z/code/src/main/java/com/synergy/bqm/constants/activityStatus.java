package com.synergy.bqm.constants;

import java.util.HashMap;
import java.util.Map;

public enum activityStatus {
	
	OPEN(0, "Open"),
	INPROGRESS(1,"InProgress"),
	COMPLETED(2,"Completed");
 
    public final int value;
    public final String stringValue;

    private static final Map<Integer, activityStatus> valueMap = new HashMap<Integer, activityStatus>();
    private static final Map<String, activityStatus> stringMap = new HashMap<String, activityStatus>();

    static {
        for (activityStatus constant : activityStatus.class.getEnumConstants()) {
            valueMap.put(constant.value, constant);
            stringMap.put(constant.stringValue, constant);
        }
    }

    private activityStatus(int value, String stringValue) {
        this.value = value;
        this.stringValue = stringValue;
    }

    
    public static activityStatus fromString(final String stringValue) {
        return stringMap.get(stringValue);
    }

    public static activityStatus fromInteger(final Integer intValue) {
        return valueMap.get(intValue);
    }

}
