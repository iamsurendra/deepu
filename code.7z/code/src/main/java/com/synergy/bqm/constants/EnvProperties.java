package com.synergy.bqm.constants;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Enumeration;
import java.util.Properties;
import java.util.ResourceBundle;

import com.guvvala.framework.logging.AppLogger;
import com.guvvala.framework.logging.AppLoggerFactory;
import com.guvvala.framework.util.AppBundle;
import com.guvvala.framework.util.StringUtils;

public enum EnvProperties {

	MONGODB_HOST("mongodbHost"),
	MONGODB_USER("mongodbUser"),
	MONGO_AUTHDB("mongoAuthdb"),
	MONGODB_PASSWORD("mongodbPassword");

	public String value;

	private static final AppLogger log = AppLoggerFactory.getLogger(EnvProperties.class.getName());

	private static final Properties properties = loadProperties();

	EnvProperties(String value) {
		this.value = value;
	}

	public static String findProperty(EnvProperties key) {
		return properties.getProperty(key.value);
	}

	private static Properties loadProperties() {
		InputStream is = null;
		Properties property = new Properties();
		String envConfig = System.getProperty("configPath");
		log.info("Config path :" + envConfig);
		try {
			if (StringUtils.isEmpty(envConfig)) {
				ResourceBundle resource = AppBundle.getBundle("com.synergy.bqm.envConfig");
				property = convertResourceBundleToProperties(resource);
			} else {
				StringBuilder filePath = new StringBuilder(envConfig);
				filePath.append("envConfig.properties");
				log.info("Full path :" + filePath);
				File configFile = new File(filePath.toString());
				is = new FileInputStream(configFile);
				property.load(is);
			}
		} catch (Exception th) {

		} finally {
			if (is != null) {
				try {
					is.close();
				} catch (IOException e) {

				}
			}
		}
		return property;
	}
	
	
	private static Properties convertResourceBundleToProperties(ResourceBundle resource) {
		Properties properties = new Properties();
		Enumeration<String> keys = resource.getKeys();
		while (keys.hasMoreElements()) {
			String key = keys.nextElement();
			properties.put(key, resource.getString(key));
		}
		return properties;
	}

}
