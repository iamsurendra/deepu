package com.synergy.bqm.repositories;

import java.util.List;

import com.guvvala.framework.dao.BaseDAO;
import com.synergy.bqm.models.VendorServices;

public interface VendorServicesDAO extends BaseDAO<VendorServices, Integer>{
	
	public List<VendorServices> getVendorServiceInfoById(List<Long> Id);

}
