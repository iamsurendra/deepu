package com.synergy.bqm.models;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 * The persistent class for the project_stage database table.
 * 
 */
@Entity
@Table(name = "project_stage")
@NamedQuery(name = "ProjectStage.findAll", query = "SELECT p FROM ProjectStage p")
public class ProjectStage implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue
	@Column(name = "project_stage_id")
	private Integer projectStageId;

	@Column(name = "project_stage_name")
	private String projectStageName;


	public ProjectStage() {
	}

	public Integer getProjectStageId() {
		return projectStageId;
	}

	public void setProjectStageId(Integer projectStageId) {
		this.projectStageId = projectStageId;
	}

	public String getProjectStageName() {
		return this.projectStageName;
	}

	public void setProjectStageName(String projectStageName) {
		this.projectStageName = projectStageName;
	}

	

}