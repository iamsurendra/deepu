package com.synergy.bqm.mongoRepositories;

import java.io.InputStream;
import java.util.List;

import org.springframework.data.repository.NoRepositoryBean;

import com.mongodb.DBObject;
import com.mongodb.gridfs.GridFSDBFile;

@NoRepositoryBean
public interface FileMongoDAO {

	public String store(InputStream inputStream, String fileName, String contentType, DBObject metaData);

	public GridFSDBFile retrive(String fileName);

	public GridFSDBFile getById(String id);

	public GridFSDBFile getByFilename(String filename);

	public List<GridFSDBFile> findAll();

	public void deletefiles(String id);

	public String storeImage(InputStream inputStream, DBObject metaData);
	
	public List<GridFSDBFile> getAllDocumentsByIds(List<String> documentId);
}
