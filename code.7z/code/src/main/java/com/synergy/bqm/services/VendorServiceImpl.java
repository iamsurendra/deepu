package com.synergy.bqm.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.synergy.bqm.models.Vendor;
import com.synergy.bqm.models.VendorProjectMapping;
import com.synergy.bqm.repositories.VendorDAO;
import com.synergy.bqm.repositories.VendorProjectMappingDAO;

@Service("VendorService")
public class VendorServiceImpl implements VendorService {

	@Autowired
	VendorDAO vendorDAO;
	
	@Autowired
	VendorProjectMappingDAO vendorProjectMappingDAO;

	public List<Vendor> findAllVendors() {

		return vendorDAO.findAll();

	}

	@Transactional
	public void createVendor(Vendor vendor) {
		vendorDAO.create(vendor);
	}

	@Transactional
	public void updateVendor(Vendor vendor) {
		
		vendorDAO.update(vendor);
	}

	@Transactional
	public void deleteVendor(Long Id) {
		List<VendorProjectMapping> vendorProjectMapping = vendorProjectMappingDAO.getVendorProjectMappingInfoByVendorId(Id);
		if(!vendorProjectMapping.isEmpty()){
			for(VendorProjectMapping mapping:vendorProjectMapping){
				mapping.setVendorId(null);
		}}
		Vendor deleteVendor = vendorDAO.findOne(Id);
		vendorDAO.delete(deleteVendor);

	}

	@Transactional
	public Vendor getvendorByVendorId(Long vendorId) {
		return vendorDAO.getVendorInfoByVendorId(vendorId);

	}

}
