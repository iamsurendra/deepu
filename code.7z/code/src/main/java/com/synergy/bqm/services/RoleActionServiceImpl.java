package com.synergy.bqm.services;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.synergy.bqm.models.RoleActions;
import com.synergy.bqm.repositories.RoleActionDAO;

@Service("roleActionService")
public class RoleActionServiceImpl implements RoleActionService {

	@Autowired
	RoleActionDAO roleActionDAO;

	@Transactional
	public List<RoleActions> findAll() {
		return roleActionDAO.findAll();

	}

}
