package com.synergy.bqm.services;

import java.util.List;

import com.mongodb.gridfs.GridFSDBFile;

public interface ChecklistService {
	
	public void importChecklistToParentHierarchy(Integer projectId, List<String> checklistIds,Integer projectHierarchyId,Boolean withChild) ;
	
	public GridFSDBFile getImageById(String id);

}
