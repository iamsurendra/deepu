package com.synergy.bqm.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.synergy.bqm.json.DepartmentDTO;
import com.synergy.bqm.models.Department;
import com.synergy.bqm.models.ProjectMember;
import com.synergy.bqm.repositories.DepartmentDAO;
import com.synergy.bqm.repositories.FolderTemplateDeptMappingDAO;
import com.synergy.bqm.repositories.ProjectMemberDAO;

@Service("departmentService")
public class DepartmentServiceImpl implements DepartmentService {
	@Autowired
	DepartmentDAO departmentDAO;

	@Autowired
	ProjectMemberDAO projectMemberDAO;
	
	@Autowired
	FolderTemplateDeptMappingDAO folderTemplateDeptMappingDAO;

	@Transactional
	public void createDepartment(Department department) {
		departmentDAO.create(department);

	}

	@Transactional
	public List<Department> findAllDepartments() {

		return departmentDAO.findAll();
	}
	
	@Transactional
	public List<Department> getAllDepartmentsByTemplateId(Integer folderTemplateId){
		List<Integer> deptIds=folderTemplateDeptMappingDAO.getDepartmentIds(folderTemplateId);
		List<Department>departments = departmentDAO.findAll();
		if(deptIds.isEmpty()){
		return departments;
		}else{
			for(Department department:departments){
				if(deptIds.contains(department.getDepartmentId())){
					department.setSelectedDept(true);
				}
			}
			return departments;
		}
	}

	@Transactional
	public List<String> getAlldepartmentNames() {
		return departmentDAO.getDepartmentNames();

	}

	@Transactional
	public void updateDepartment(Department department) {
		departmentDAO.update(department);

	}

	@Transactional
	public void deleteDepartmentById(Integer Id) {
		Department deleteDepartment = departmentDAO.findOne(Id);
		departmentDAO.delete(deleteDepartment);

	}

	@Transactional
	public void createAndUpdateDepartments(DepartmentDTO departmentDTO) {

		// create or update department
		if (!departmentDTO.getDepartmentList().isEmpty()) {
			for (Department departments : departmentDTO.getDepartmentList()) {
				if (departments.getDepartmentId() == null) {
					departmentDAO.create(departments);
				} else {
					departmentDAO.update(departments);
				}
			}
		}
		// delete departments
		if (!departmentDTO.getDeletedIds().isEmpty()) {
			List<ProjectMember> projectMemders = projectMemberDAO
					.getProjectMemberInfoByDepartmentIdInOperator(departmentDTO.getDeletedIds());
			// projcetMember deleted Department value set null
			for (ProjectMember allMembers : projectMemders) {
				allMembers.setDepartmentId(null);
			}
			List<Department> deletedDepartments = departmentDAO.getDepartmentInfoById(departmentDTO.getDeletedIds());
			for (Department removedepartment : deletedDepartments) {
				departmentDAO.delete(removedepartment);
			}
		}
	}
}
