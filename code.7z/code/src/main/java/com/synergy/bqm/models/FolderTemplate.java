package com.synergy.bqm.models;

import java.io.Serializable;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.PostLoad;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.guvvala.framework.model.BaseModel;
import com.guvvala.framework.util.DateUtils;

@Entity
@Table(name = "folder_templates")
@NamedQuery(name = "FolderTemplate.findAll", query = "SELECT f FROM FolderTemplate f")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class FolderTemplate extends BaseModel implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue
	@Column(name = "folder_id")
	private Integer folderId;

	@Column(name = "folder_name")
	private String folderName;

	@Column(name = "template_id")
	private Integer templateId;

	@Transient
	private String createdDt;

	@Transient
	private String updatedDt;

	// bi-directional many-to-one association to FolderTemplate
	@ManyToOne(fetch = FetchType.LAZY)
	@JsonIgnore
	@JoinColumn(name = "parent_folder_id")
	private FolderTemplate folderTemplate;

	// bi-directional many-to-one association to FolderTemplate

	@OneToMany(mappedBy = "folderTemplate", cascade = CascadeType.REMOVE, fetch = FetchType.EAGER)
	private List<FolderTemplate> folderTemplates;

	//// @ManyToOne(cascade = CascadeType.ALL)
	// @JoinTable(name="folder_template_names",joinColumns =
	//// @JoinColumn(name="template_id"),inverseJoinColumns = @JoinColumn(name =
	//// "template_id"))
	// @JoinColumn(name="template_id")
	// @JsonIgnore

	@Transient
	private List<Integer> folderIdList;

	@Transient
	private String templateName;

	@Transient
	private int parentId;

	public FolderTemplate() {
	}

	public String getFolderName() {
		return this.folderName;
	}

	public void setFolderName(String folderName) {
		this.folderName = folderName;
	}

	public FolderTemplate getFolderTemplate() {
		return this.folderTemplate;
	}

	public void setFolderTemplate(FolderTemplate folderTemplate) {
		this.folderTemplate = folderTemplate;
	}

	public List<FolderTemplate> getFolderTemplates() {
		return this.folderTemplates;
	}

	public void setFolderTemplates(List<FolderTemplate> folderTemplates) {
		this.folderTemplates = folderTemplates;
	}

	public int getParentId() {
		return parentId;
	}

	public void setParentId(int parentId) {
		this.parentId = parentId;
	}

	public void setFolderId(Integer folderId) {
		this.folderId = folderId;
	}

	public Integer getFolderId() {
		return folderId;
	}

	public Integer getTemplateId() {
		return templateId;
	}

	public void setTemplateId(Integer templateId) {
		this.templateId = templateId;
	}

	public List<Integer> getFolderIdList() {
		return folderIdList;
	}

	public void setFolderIdList(List<Integer> folderIdList) {
		this.folderIdList = folderIdList;
	}

	public String getCreatedDt() {
		return createdDt;
	}

	public void setCreatedDt(String createdDt) {
		this.createdDt = createdDt;
	}

	public String getUpdatedDt() {
		return updatedDt;
	}

	public void setUpdatedDt(String updatedDt) {
		this.updatedDt = updatedDt;
	}

	public String getTemplateName() {
		return templateName;
	}

	public void setTemplateName(String templateName) {
		this.templateName = templateName;
	}

	public FolderTemplate addFolderTemplate(FolderTemplate folderTemplate) {
		getFolderTemplates().add(folderTemplate);
		folderTemplate.setFolderTemplate(this);

		return folderTemplate;
	}

	public FolderTemplate removeFolderTemplate(FolderTemplate folderTemplate) {
		getFolderTemplates().remove(folderTemplate);
		folderTemplate.setFolderTemplate(null);

		return folderTemplate;
	}

	@PostLoad
	void postload() {
		setCreatedDt(DateUtils.convertToSimpleDateTimeFormat(getCreatedDate()));
		setUpdatedDt(DateUtils.convertToSimpleDateTimeFormat(getUpdatedDate()));

	}
}