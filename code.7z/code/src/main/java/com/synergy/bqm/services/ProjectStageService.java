package com.synergy.bqm.services;

import java.util.List;

import com.synergy.bqm.models.ProjectStage;

public interface ProjectStageService {
	
	List<String> getprojectStageNamesList();
	
    List<ProjectStage> getAllProjectStages();
    
    public void createOrUpdateProjectStages(List<ProjectStage> projectStages,List<Integer> deletedIds);
    
    public void deleteProjectStage(Integer Id);
}
