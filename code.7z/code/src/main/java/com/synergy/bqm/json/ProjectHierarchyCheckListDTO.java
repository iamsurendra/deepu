package com.synergy.bqm.json;

import java.util.List;

public class ProjectHierarchyCheckListDTO {

	private Integer projectId;

	private Integer hierarchyId;

	private List<String> checklistIds;

	private Boolean withChild;

	// Getters and Setters

	public Integer getProjectId() {
		return projectId;
	}

	public void setProjectId(Integer projectId) {
		this.projectId = projectId;
	}

	public Integer getHierarchyId() {
		return hierarchyId;
	}

	public void setHierarchyId(Integer hierarchyId) {
		this.hierarchyId = hierarchyId;
	}

	public List<String> getChecklistIds() {
		return checklistIds;
	}

	public void setChecklistIds(List<String> checklistIds) {
		this.checklistIds = checklistIds;
	}

	public Boolean getWithChild() {
		return withChild;
	}

	public void setWithChild(Boolean withChild) {
		this.withChild = withChild;
	}

}
