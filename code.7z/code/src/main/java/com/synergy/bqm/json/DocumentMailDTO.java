package com.synergy.bqm.json;

import java.util.List;

public class DocumentMailDTO {
	
	private List<String> emails;
	private List<String> ccMails;
	private String message;
	private String subject;
	private List<Integer>documentIds;
	
	
	public List<String> getEmails() {
		return emails;
	}
	public void setEmails(List<String> emails) {
		this.emails = emails;
	}
	public List<String> getCcMails() {
		return ccMails;
	}
	public void setCcMails(List<String> ccMails) {
		this.ccMails = ccMails;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public List<Integer> getDocumentIds() {
		return documentIds;
	}
	public void setDocumentIds(List<Integer> documentIds) {
		this.documentIds = documentIds;
	}
	
	
	
	

}
