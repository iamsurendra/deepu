package com.synergy.bqm.services;

import java.util.List;

import com.synergy.bqm.models.ProjectStatus;

public interface ProjectStatusService {

	public List<String> getprojectStatusNames();

	public List<ProjectStatus> getAllProjectStatus();

	public void createOrUpdateProjectStatus(List<ProjectStatus> projectStatus,List<Integer> ids);

	public void deleteProjectStatus(Integer Id);
}
