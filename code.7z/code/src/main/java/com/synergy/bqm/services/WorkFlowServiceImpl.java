package com.synergy.bqm.services;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.guvvala.framework.errorHandler.AppException;
import com.synergy.bqm.constants.MessagesEnum;
import com.synergy.bqm.models.Role;
import com.synergy.bqm.models.Workflow;
import com.synergy.bqm.models.WorkflowStates;
import com.synergy.bqm.repositories.RolesDAO;
import com.synergy.bqm.repositories.WorkFlowDAO;
import com.synergy.bqm.repositories.WorkflowNavigationDAO;
import com.synergy.bqm.repositories.WorkflowStatesDAO;

@Service
public class WorkFlowServiceImpl implements WorkFlowService {

	@Autowired
	WorkFlowDAO workFlowDAO;
	
	@Autowired
	WorkflowStatesDAO workflowStatesDAO;
	
	@Autowired
	RolesDAO rolesDAO;
	
	@Autowired
	WorkflowNavigationDAO workflowNavigationDAO;

	@Transactional
	public void deleteworkflowBYId(Integer Id) {
		Workflow deleteworkflow = workFlowDAO.findOne(Id);
		workFlowDAO.delete(deleteworkflow);
	}

	@Transactional
	@Override
	public List<Workflow> findAll() {
		return workFlowDAO.findAll();

	}
	
	@Transactional
	public Workflow findOne(Integer id){
		return workFlowDAO.findOne(id);
	}
	
	@Transactional
	public List<Workflow> getAllDesignWorkFlows(){
		return workFlowDAO.getAllDesignWorkFlows();
	}

	@Transactional
	public Workflow saveWorkflow(Workflow workflow) {
		if (workflow.getId()!=null) {
			return updateworkflow(workflow);
		} else {
			Long count = workFlowDAO.workflowNameExists(workflow.getName());
			if (count > 0 || count != 0) {
				throw new AppException(MessagesEnum.WORKFLOW_NAME_EXISTS);
			}
			return workFlowDAO.create(workflow);
		}
	}

	private Workflow updateworkflow(Workflow workflow) {
		List<String> names = workFlowDAO.getWorkFlowNamesList();
		names.add(workflow.getName());
		for (String str : names) {
			int i = Collections.frequency(names, str);
			if (i > 2) {
				throw new AppException(MessagesEnum.WORKFLOW_NAME_EXISTS);
			}

		}
		return workFlowDAO.update(workflow);
		
	}
	
	
	@Transactional
	public List<WorkflowStates> getWorkflowsInfo(Integer workFlowId) {
		List<WorkflowStates> workflowStates = workflowStatesDAO.getWorkflowStatesById(workFlowId);
		Map<Integer, String> roleNames = new HashMap<Integer, String>();
		List<Role> roleObj = rolesDAO.findAll();
		for (Role role : roleObj) {
			roleNames.put(role.getRoleId(), role.getRoleName());
		}
		for (WorkflowStates state : workflowStates) {
			state.setRoleName(roleNames.get(state.getRoleId()));
			List<Integer> navigationIds = workflowNavigationDAO.getworkFlowNavigationIdsBysourceId(state.getId());
			if (!navigationIds.isEmpty()) {
				List<String> workflowNames = workflowStatesDAO.getWorkflowStatesNames(navigationIds);
				state.setWorkflowStatesNames(workflowNames);
			}
		}
		return workflowStates;
	}
	@Transactional
	public List<WorkflowStates> getTargetStates(Integer stateId){
		List<Integer> navigationIds = workflowNavigationDAO.getworkFlowNavigationIdsBysourceId(stateId);
		if(!navigationIds.isEmpty()){
			return workflowStatesDAO.getWorkflowStates(navigationIds);
		}
		return new ArrayList<>();

	}
	
	

}
