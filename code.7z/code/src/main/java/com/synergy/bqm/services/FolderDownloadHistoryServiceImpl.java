package com.synergy.bqm.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.synergy.bqm.models.FolderDownloadHistory;
import com.synergy.bqm.repositories.FolderDownloadHistoryDAO;

@Service("folderDownloadHistoryService")
public class FolderDownloadHistoryServiceImpl implements FolderDownloadHistoryService{

	@Autowired
	FolderDownloadHistoryDAO folderDownloadHistoryDAO;
	
	
	@Transactional
	public List<FolderDownloadHistory> getFolderDownloadHistoryBydocumentFolderId(Integer Id){
		return folderDownloadHistoryDAO.getFolderDownloadHistoryBydocumentFolderId(Id);
		
	}
	
	@Transactional
	public void createFolderDownloadInfo(FolderDownloadHistory folderDownloadHistory){
		folderDownloadHistoryDAO.create(folderDownloadHistory);
	}

}
