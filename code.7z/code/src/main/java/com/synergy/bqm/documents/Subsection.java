package com.synergy.bqm.documents;

import java.util.ArrayList;
import java.util.List;

public class Subsection {

	private String subsectionName;
	private String subsectionInfo;
	private String answerType;
	private String reference;
	private List<BaseAnswerType> questionList = new ArrayList<BaseAnswerType>();

	public String getSubsectionName() {
		return subsectionName;
	}

	public void setSubsectionName(String subsectionName) {
		this.subsectionName = subsectionName;
	}

	public String getSubsectionInfo() {
		return subsectionInfo;
	}

	public void setSubsectionInfo(String subsectionInfo) {
		this.subsectionInfo = subsectionInfo;
	}

	public String getAnswerType() {
		return answerType;
	}

	public void setAnswerType(String answerType) {
		this.answerType = answerType;
	}

	public String getReference() {
		return reference;
	}

	public void setReference(String reference) {
		this.reference = reference;
	}

	public List<BaseAnswerType> getQuestionList() {
		return questionList;
	}

	public void setQuestionList(List<BaseAnswerType> questionList) {
		this.questionList = questionList;
	}

}
