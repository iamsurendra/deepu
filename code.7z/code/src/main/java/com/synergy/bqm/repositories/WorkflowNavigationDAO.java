package com.synergy.bqm.repositories;

import java.util.List;

import com.guvvala.framework.dao.BaseDAO;
import com.synergy.bqm.models.WorkflowNavigation;
import com.synergy.bqm.models.WorkflowNavigationKey;

public interface WorkflowNavigationDAO extends BaseDAO<WorkflowNavigation, WorkflowNavigationKey>{

	
	public List<WorkflowNavigation> getworkFlowNavigationBysourceId(Integer sourceId);
	
	public List<Integer> getworkFlowNavigationIdsBysourceId(Integer sourceId);
}
