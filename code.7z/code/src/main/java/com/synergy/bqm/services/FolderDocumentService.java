package com.synergy.bqm.services;

import java.util.List;

import com.mongodb.gridfs.GridFSDBFile;
import com.synergy.bqm.models.FolderDocument;

public interface FolderDocumentService {

	public Long checkDocumentNameExisit(Integer documentfolderid, String documentName,Double version);

	public FolderDocument getfolderDocumentObjcet(Integer documentfolderid, String documentName);
	
	public List<FolderDocument> getFolderDocumentInfo(Integer folderId);
	
	public void updateFolderDocumentInfo(FolderDocument folderDocument);
	
	public List<GridFSDBFile> getListOfDocumentIds(List<Integer> Ids);
	
	public List<Double> getVersion(Integer documentfolderid, String documentName);
	
	public List<FolderDocument> getFolderDocumentsByfolderId(Integer folderId);


}
