package com.synergy.bqm.services;

import java.util.List;
import javax.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.synergy.bqm.models.FolderTemplateDeptMapping;
import com.synergy.bqm.repositories.FolderTemplateDeptMappingDAO;

@Service
public class FolderTemplateDeptMappingServiceImpl implements FolderTemplateDeptMappingService {

	@Autowired
	FolderTemplateDeptMappingDAO deptMappingDAO;

	@Transactional
	public void createFolderTemplateMapping(List<FolderTemplateDeptMapping> deptMapping,Integer templateId) {
		List<FolderTemplateDeptMapping> mappings = deptMappingDAO
				.getDepartmentTemplateMapping(templateId);
		for (FolderTemplateDeptMapping deletedFolder : mappings) {
			deptMappingDAO.delete(deletedFolder);
		}
       if(!deptMapping.isEmpty())
		for (FolderTemplateDeptMapping newMapping : deptMapping) {
			deptMappingDAO.create(newMapping);
		}
	}
	
	@Transactional
	public List<Integer> getTemplateIds(Integer departmentId){
		return deptMappingDAO.getTemplateIds(departmentId);
		
	}
	public List<Integer> getFolderTemplateIds(){
		return deptMappingDAO.getFolderTemplateIds();
		
	}
	

}
