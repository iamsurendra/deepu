package com.synergy.bqm.models;

import java.util.List;

public class WorkflowDTO {
	private List<WorkflowType> workFlowTypeList;
	private List<Integer> ids;

	// Getters and Setters

	public List<Integer> getIds() {
		return ids;
	}

	public List<WorkflowType> getWorkFlowTypeList() {
		return workFlowTypeList;
	}

	public void setWorkFlowTypeList(List<WorkflowType> workFlowTypeList) {
		this.workFlowTypeList = workFlowTypeList;
	}

	public void setIds(List<Integer> ids) {
		this.ids = ids;
	}

}
