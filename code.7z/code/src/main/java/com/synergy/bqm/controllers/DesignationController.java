package com.synergy.bqm.controllers;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.synergy.bqm.json.DesignationDTO;
import com.synergy.bqm.models.Designation;
import com.synergy.bqm.services.DesignationService;

@RestController
@RequestMapping("/api/designation")
public class DesignationController {

	@Autowired
	DesignationService designationService;

	/*
	 * Find All Designations
	 */
	@RequestMapping(value = "/findAllDesignations", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<Designation> findAllDesignations() {
		return designationService.findAllDesignations();
	}

	/*
	 * Create New Designation
	 */
	@RequestMapping(value = "/createDesignation", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	public void createDesignation(Designation designation) {
		designationService.createDesignation(designation);

	}

	/*
	 * Get All DesignationNames
	 */
	@RequestMapping(value = "/getDesignationNames", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<String> getDesignationNames() {
		return designationService.getDesignationNames();
	}

	/*
	 * Update DesignationInfo
	 */
	@RequestMapping(value = "/updateDesignation", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	public void updateDesignation(@RequestBody Designation designation) {
		designationService.updateDesignation(designation);
	}

	/*
	 * Delete Designation By Id
	 */
	@RequestMapping(value = "/deleteDesignationById/{Id}", method = RequestMethod.GET, consumes = MediaType.APPLICATION_JSON_VALUE)
	public void deleteDesignationById(@PathVariable("Id") Designation designation) {
		designationService.deleteDesignationById(designation);
	}

	@RequestMapping(value = "/createOrUpdateDesignation", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	public void createAndUpdateDesignation(@RequestBody  DesignationDTO designationDTO) {
		designationService.createAndUpdateDesignation(designationDTO);

	}

}
