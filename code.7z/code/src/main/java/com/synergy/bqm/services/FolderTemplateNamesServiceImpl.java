package com.synergy.bqm.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.guvvala.framework.errorHandler.AppException;
import com.synergy.bqm.constants.MessagesEnum;
import com.synergy.bqm.models.FolderTemplateNames;
import com.synergy.bqm.repositories.FolderTemplateNamesDAO;

@Service("folderTemplateNamesService")
public class FolderTemplateNamesServiceImpl implements FolderTemplateNamesService {

	@Autowired
	FolderTemplateNamesDAO folderTemplateNamesDAO;

	/*
	 * Find All TemplateNames
	 */
	@Transactional
	public List<FolderTemplateNames> findAllTemplates() {
		return folderTemplateNamesDAO.findAll();

	}

	// get FolderTemplateNames By Id
	@Transactional
	public FolderTemplateNames getFolderTemplateInfoById(Integer Id) {
		return folderTemplateNamesDAO.findOne(Id);
	}

	/*
	 * To create Template
	 */
	@Transactional
	public FolderTemplateNames createTemplate(String templateName) {
		Long count = folderTemplateNamesDAO.folderTemplateNameExists(templateName);
		if (count == null || count == 0) {
			FolderTemplateNames entity = new FolderTemplateNames();
			entity.setTemplateName(templateName);
			return folderTemplateNamesDAO.create(entity);
		} else {
			throw new AppException(MessagesEnum.DUPLICATE_TEMPLATE_NAME);

		}
	}

	/*
	 * To update Template
	 */
	@Transactional
	public FolderTemplateNames updateTemplate(FolderTemplateNames folderTemplateNames) {
		Long count = folderTemplateNamesDAO.folderTemplateNameExists(folderTemplateNames.getTemplateName());
		if (count == null || count == 0) {
			FolderTemplateNames orginalObject = folderTemplateNamesDAO.findOne(folderTemplateNames.getTemplateId());
			orginalObject.setTemplateName(folderTemplateNames.getTemplateName());
			return folderTemplateNamesDAO.update(orginalObject);
		} else {
			throw new AppException(MessagesEnum.DUPLICATE_TEMPLATE_NAME);

		}

	}

	@Transactional
	public List<FolderTemplateNames> getFoldersInfoByFolderIds(List<Integer> templateIds) {
		return folderTemplateNamesDAO.getFoldersInfoByFolderIds(templateIds);

	}

	/*
	 * To update Template
	 */
	@Transactional
	public void deleteTemplate(Integer templateId) {
		FolderTemplateNames orginalEntity = folderTemplateNamesDAO.findOne(templateId);
		orginalEntity.getFolderTemplates().clear();
		folderTemplateNamesDAO.delete(orginalEntity);
	}
}
