package com.synergy.bqm.models;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;


/**
 * The persistent class for the checklist_line_item database table.
 * 
 */
@Entity
@Table(name="checklist_line_item")
@NamedQuery(name="ChecklistLineItem.findAll", query="SELECT c FROM ChecklistLineItem c")
public class ChecklistLineItem extends com.guvvala.framework.model.BaseModel implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="checklist_line_item_id")
	private int checklistLineItemId;

	@Column(name="checklist_line_item_image")
	private String checklistLineItemImage;

	@Column(name="checklist_line_item_info")
	private String checklistLineItemInfo;

	@Column(name="checklist_line_item_label")
	private String checklistLineItemLabel;

	@Column(name="checklist_line_item_notes")
	private String checklistLineItemNotes;

	@Column(name="checklist_line_item_result")
	private String checklistLineItemResult;

	@Column(name="checklist_line_item_type")
	private String checklistLineItemType;

	/*@Column(name="created_by")
	private int createdBy;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="created_dt")
	private Date createdDt;

	@Column(name="updated_by")
	private int updatedBy;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="updated_dt")
	private Date updatedDt;*/

	//bi-directional many-to-one association to ChecklistLineItem
	@ManyToOne
	@JoinColumn(name="checklist_line_item_parent_line_item_id")
	private ChecklistLineItem checklistLineItem;

	//bi-directional many-to-one association to ChecklistLineItem
	@OneToMany(mappedBy="checklistLineItem")
	private List<ChecklistLineItem> checklistLineItems;

	//bi-directional many-to-one association to Checklist
	@ManyToOne
	@JoinColumn(name="checklist_line_item_parent_id")
	private Checklist checklist;

	public ChecklistLineItem() {
	}

	public int getChecklistLineItemId() {
		return this.checklistLineItemId;
	}

	public void setChecklistLineItemId(int checklistLineItemId) {
		this.checklistLineItemId = checklistLineItemId;
	}

	public String getChecklistLineItemImage() {
		return this.checklistLineItemImage;
	}

	public void setChecklistLineItemImage(String checklistLineItemImage) {
		this.checklistLineItemImage = checklistLineItemImage;
	}

	public String getChecklistLineItemInfo() {
		return this.checklistLineItemInfo;
	}

	public void setChecklistLineItemInfo(String checklistLineItemInfo) {
		this.checklistLineItemInfo = checklistLineItemInfo;
	}

	public String getChecklistLineItemLabel() {
		return this.checklistLineItemLabel;
	}

	public void setChecklistLineItemLabel(String checklistLineItemLabel) {
		this.checklistLineItemLabel = checklistLineItemLabel;
	}

	public String getChecklistLineItemNotes() {
		return this.checklistLineItemNotes;
	}

	public void setChecklistLineItemNotes(String checklistLineItemNotes) {
		this.checklistLineItemNotes = checklistLineItemNotes;
	}

	public String getChecklistLineItemResult() {
		return this.checklistLineItemResult;
	}

	public void setChecklistLineItemResult(String checklistLineItemResult) {
		this.checklistLineItemResult = checklistLineItemResult;
	}

	public String getChecklistLineItemType() {
		return this.checklistLineItemType;
	}

	public void setChecklistLineItemType(String checklistLineItemType) {
		this.checklistLineItemType = checklistLineItemType;
	}

	/*public int getCreatedBy() {
		return this.createdBy;
	}

	public void setCreatedBy(int createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDt() {
		return this.createdDt;
	}

	public void setCreatedDt(Date createdDt) {
		this.createdDt = createdDt;
	}

	public int getUpdatedBy() {
		return this.updatedBy;
	}

	public void setUpdatedBy(int updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Date getUpdatedDt() {
		return this.updatedDt;
	}

	public void setUpdatedDt(Date updatedDt) {
		this.updatedDt = updatedDt;
	}
*/
	public ChecklistLineItem getChecklistLineItem() {
		return this.checklistLineItem;
	}

	public void setChecklistLineItem(ChecklistLineItem checklistLineItem) {
		this.checklistLineItem = checklistLineItem;
	}

	public List<ChecklistLineItem> getChecklistLineItems() {
		return this.checklistLineItems;
	}

	public void setChecklistLineItems(List<ChecklistLineItem> checklistLineItems) {
		this.checklistLineItems = checklistLineItems;
	}

	public ChecklistLineItem addChecklistLineItem(ChecklistLineItem checklistLineItem) {
		getChecklistLineItems().add(checklistLineItem);
		checklistLineItem.setChecklistLineItem(this);

		return checklistLineItem;
	}

	public ChecklistLineItem removeChecklistLineItem(ChecklistLineItem checklistLineItem) {
		getChecklistLineItems().remove(checklistLineItem);
		checklistLineItem.setChecklistLineItem(null);

		return checklistLineItem;
	}

	public Checklist getChecklist() {
		return this.checklist;
	}

	public void setChecklist(Checklist checklist) {
		this.checklist = checklist;
	}

}