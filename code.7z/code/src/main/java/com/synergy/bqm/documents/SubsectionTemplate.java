package com.synergy.bqm.documents;

import java.util.ArrayList;
import java.util.List;

public class SubsectionTemplate {

	private String subsectionName;
	private String subsectionInfo;
	private String questionType;
	private String reference;
	private List<BaseQuestionTypeTemplate> questionList = new ArrayList<BaseQuestionTypeTemplate>();

	public String getSubsectionName() {
		return subsectionName;
	}

	public String getReference() {
		return reference;
	}

	public void setReference(String reference) {
		this.reference = reference;
	}

	public void setSubsectionName(String subsectionName) {
		this.subsectionName = subsectionName;
	}


	public String getSubsectionInfo() {
		return subsectionInfo;
	}

	public void setSubsectionInfo(String subsectionInfo) {
		this.subsectionInfo = subsectionInfo;
	}

	public List<BaseQuestionTypeTemplate> getQuestionList() {
		return questionList;
	}

	public void setQuestionList(List<BaseQuestionTypeTemplate> questionList) {
		this.questionList = questionList;
	}

	public String getQuestionType() {
		return questionType;
	}

	public void setQuestionType(String questionType) {
		this.questionType = questionType;
	}


	
}
