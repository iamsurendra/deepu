package com.synergy.bqm.services;

import java.util.List;

import com.synergy.bqm.models.FolderTemplateNames;

public interface FolderTemplateNamesService {

	List<FolderTemplateNames> findAllTemplates();

	FolderTemplateNames createTemplate(String templateName);

	FolderTemplateNames updateTemplate(FolderTemplateNames folderTemplateNames);

	void deleteTemplate(Integer templateId);
	
   FolderTemplateNames getFolderTemplateInfoById(Integer Id);
   
   public List<FolderTemplateNames> getFoldersInfoByFolderIds(List<Integer> templateIds);
}
