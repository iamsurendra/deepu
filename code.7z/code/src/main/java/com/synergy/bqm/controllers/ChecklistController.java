package com.synergy.bqm.controllers;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.InputStreamSource;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.guvvala.framework.errorHandler.AppException;
import com.guvvala.framework.util.DateUtils;
import com.guvvala.framework.util.StringUtils;
import com.guvvala.framework.util.ThreadLocalUtil;
import com.synergy.bqm.constants.BqmConstants;
import com.synergy.bqm.constants.ChecklistStatus;
import com.synergy.bqm.constants.MailTemplateEnum;
import com.synergy.bqm.constants.MessagesEnum;
import com.synergy.bqm.constants.PDFTemplateEnum;
import com.synergy.bqm.documents.BaseAnswerType;
import com.synergy.bqm.documents.Checklist;
import com.synergy.bqm.documents.Section;
import com.synergy.bqm.documents.Subsection;
import com.synergy.bqm.exporter.PDFExporter;
import com.synergy.bqm.json.CheckListPDFDTO;
import com.synergy.bqm.json.CheckListTreeDTO;
import com.synergy.bqm.json.ProjectHierarchyCheckListDTO;
import com.synergy.bqm.mongoRepositories.CheckListRepository;
import com.synergy.bqm.mongoRepositories.CheckListTemplateRepository;
import com.synergy.bqm.services.ChecklistService;
import com.synergy.bqm.services.MailService;
import com.synergy.bqm.services.ProjectMemberService;
import com.synergy.bqm.services.QuestionOptionService;
import com.synergy.bqm.services.UserService;

@RestController
@RequestMapping("/api/checklist")
public class ChecklistController {

	@Autowired
	CheckListRepository checkListRepository;

	@Autowired
	CheckListTemplateRepository checkListTemplateRepository;

	@Autowired
	QuestionOptionService questionOptionService;

	@Autowired
	private PDFExporter pdfExporter;

	@Autowired
	ChecklistService checklistService;

	@Autowired
	MailService mailService;

	@Autowired
	ProjectMemberService projectMemberService;

	@Autowired
	UserService userService;

	/*
	 * Get All Checklist
	 */
	@RequestMapping(value = "/findAllCheckList", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<Checklist> findAllchecklist() {
		List<Checklist> checkList = checkListRepository.findAll();
		return checkList;

	}

	/*
	 * @RequestMapping(value = "/getChecklistInfo", method = RequestMethod.GET,
	 * produces = MediaType.APPLICATION_JSON_VALUE) public List<Checklist>
	 * getChecklistInfo(){ return checkListRepository.getchecklistInfo(); }
	 */

	/*
	 * Get Checklist By Id
	 */
	@RequestMapping(value = "/checkListById/{Id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public Checklist checklistById(@PathVariable("Id") String Id) {
		Checklist checkList = checkListRepository.findOne(Id);
		return checkList;

	}
	/*
	 * Get Checklist Name and Ids by HierarchyId
	 */

	@RequestMapping(value = "/getChecklistNameByHierarchyId/{hierarchyId}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<Checklist> getChecklist(@PathVariable("hierarchyId") Integer hierarchyId) {
		return checkListRepository.getChecklistById(hierarchyId);
	}

	/*
	 * Import ChecklistTemplate to Project
	 */
	@RequestMapping(value = "/importChecklistToHierarchy", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	public void importChecklistToProject(@RequestBody ProjectHierarchyCheckListDTO projectHierarchyDTO) {
		checklistService.importChecklistToParentHierarchy(projectHierarchyDTO.getProjectId(),
				projectHierarchyDTO.getChecklistIds(), projectHierarchyDTO.getHierarchyId(),
				projectHierarchyDTO.getWithChild());
	}

	/*
	 * s Create New CheckList
	 */

	@RequestMapping(value = "/createChecklist", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	public void createChecklist(@RequestBody Checklist checklist) {

		if (!checklist.getEditMode()) {
			checklist.setVersion(1.0);
			checkDuplicateCheckList(checklist);
			checklist.setId(null);
		}
		checklist.setUpdatedBy(ThreadLocalUtil.getUserName());
		checklist.setUpdatedOn(DateUtils.getCurrentISTDateTime().toString());
		checkListRepository.save(checklist);
	}

	@RequestMapping(value = "/reCheckChecklist", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
	public void reCheckChecklist(@RequestBody Checklist checklist) {

		Checklist checklistOldObject = checkListRepository.findOne(checklist.getId());
		checklistOldObject.setStatus(ChecklistStatus.COMPLETED.value);
		checkListRepository.save(checklistOldObject);
		checklist.setVersion(checklist.getVersion() + 1.0);
		checkDuplicateCheckList(checklist);
		checklist.setId(null);
		checklist.setRemarks(null);
		checklist.setStatus(ChecklistStatus.CHECK.value);
		checkListRepository.save(checklist);
	}

	@RequestMapping(value = "/deleteChecklist/{id}", method = RequestMethod.GET)
	public void deleteCheckList(@PathVariable("id") String id) {
		if (!StringUtils.isEmpty(id)) {
			checkListRepository.delete(checkListRepository.findOne(id));
		}
	}

	/*
	 * Download Checklist in pdf Format
	 */
	@RequestMapping(value = "/downloadCheckListPdf/{checkListId}", method = RequestMethod.GET)
	public void getCheckListPdf(HttpServletResponse response, @PathVariable("checkListId") String checkListId) {
		try {
			Checklist checklist = checkListRepository.findOne(checkListId);
			for (Section section : checklist.getSectionList()) {
				for (BaseAnswerType answerType : section.getQuestionList()) {
					getListOfImages(answerType);
				}
				for (Subsection subSection : section.getSubsectionList()) {
					for (BaseAnswerType answerType : subSection.getQuestionList()) {
						getListOfImages(answerType);
					}
				}
			}
			response.setContentType(MediaType.APPLICATION_PDF_VALUE);
			if (checklist.getLocation().equals("Template")) {
				response.setHeader("Content-Disposition",
						"attachment; filename=" + checklist.getChecklistName() + ".pdf");
			} else {
				response.setHeader("Content-Disposition", "attachment; filename=" + checklist.getLocation() + ".pdf");

			}
			ByteArrayOutputStream baos = pdfExporter.export(PDFTemplateEnum.CHECKLIST,
					Arrays.asList(PDFTemplateEnum.SECTION_LIST, PDFTemplateEnum.QUESTION_LIST,
							PDFTemplateEnum.SUB_SECTION_LIST),
					Arrays.asList(checklist));
			ByteArrayInputStream ini = new ByteArrayInputStream(baos.toByteArray());
			ServletOutputStream oos = response.getOutputStream();

			byte[] buf = new byte[8192];
			int c = 0;
			while ((c = ini.read(buf, 0, buf.length)) > 0) {
				oos.write(buf, 0, c);
				oos.flush();
			}

			oos.close();
			ini.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	// Mail the Attached pdf Document
	@RequestMapping(value = "/mailCheckListPDF", method = RequestMethod.POST)
	public void mailToPdf(HttpServletResponse response, @RequestBody CheckListPDFDTO checkLListPDFDTO) {
		try {

			Checklist checklist = checkListRepository.findOne(checkLListPDFDTO.getChecklistId());

			for (Section section : checklist.getSectionList()) {
				for (BaseAnswerType answerType : section.getQuestionList()) {
					getListOfImages(answerType);
				}
				for (Subsection subSection : section.getSubsectionList()) {
					for (BaseAnswerType answerType : subSection.getQuestionList()) {
						getListOfImages(answerType);
					}
				}
			}
			response.setContentType("application/pdf");
			response.setHeader("Content-Disposition", "attachment; filename=" + checklist.getChecklistName() + ".pdf");
			ByteArrayOutputStream baos = pdfExporter.export(PDFTemplateEnum.CHECKLIST,
					Arrays.asList(PDFTemplateEnum.SECTION_LIST, PDFTemplateEnum.QUESTION_LIST,
							PDFTemplateEnum.SUB_SECTION_LIST),
					Arrays.asList(checklist));
			ByteArrayInputStream ini = new ByteArrayInputStream(baos.toByteArray());
			ServletOutputStream oos = response.getOutputStream();
			// FileOutputStream oos = new FileOutputStream("D:\\CheckList.pdf");

			byte[] buf = new byte[8192];
			int c = 0;
			while ((c = ini.read(buf, 0, buf.length)) > 0) {
				oos.write(buf, 0, c);
				oos.flush();
			}

			oos.close();
			ini.close();
			List<String> toMail = checkLListPDFDTO.getEmails();
			List<String> ccMail = checkLListPDFDTO.getCcMails();
			String[] to = toMail.toArray(new String[toMail.size()]);
			String[] cc = ccMail.toArray(new String[ccMail.size()]);
			String subject = checkLListPDFDTO.getSubject();
			Map<String, Object> values = new HashMap<String, Object>();
			values.put(BqmConstants.MESSAGE, checkLListPDFDTO.getMessage());
			values.put(BqmConstants.FNAME, ThreadLocalUtil.getUserName());
			Map<String, InputStreamSource> pdf = new HashMap<>();

			pdf.put("checklist" + checklist.getChecklistName() + BqmConstants.PDF_TEMPLATE_TYPE,
					new ByteArrayResource(baos.toByteArray()));
			mailService.sendEmailWithAttachments(MailTemplateEnum.CHECKLIST_TEMPLATE, values, to, cc, subject, pdf,
					checklist.getChecklistName(), checklist.getChecklistType());
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	// common method for pdfDownload and mailService
	private BaseAnswerType getListOfImages(BaseAnswerType answerType) {

		if (answerType.getImage().size() > 0 && !StringUtils.isEmpty(answerType.getImage().get(0))) {
			byte[] image = Base64.getDecoder().decode(answerType.getImage().get(0)
					.substring(answerType.getImage().get(0).indexOf(',') + 1).getBytes(StandardCharsets.UTF_8));
			answerType.setFirstImage(new ByteArrayInputStream(image));
		}
		if (answerType.getImage().size() > 1 && !StringUtils.isEmpty(answerType.getImage().get(1))) {
			byte[] image = Base64.getDecoder().decode(answerType.getImage().get(1)
					.substring(answerType.getImage().get(1).indexOf(',') + 1).getBytes(StandardCharsets.UTF_8));
			answerType.setSecondImage(new ByteArrayInputStream(image));
		}
		if (answerType.getImage().size() > 2 && !StringUtils.isEmpty(answerType.getImage().get(2))) {
			byte[] image = Base64.getDecoder().decode(answerType.getImage().get(2)
					.substring(answerType.getImage().get(2).indexOf(',') + 1).getBytes(StandardCharsets.UTF_8));
			answerType.setThirdImage(new ByteArrayInputStream(image));
		}

		if (answerType.getImage().size() > 3 && !StringUtils.isEmpty(answerType.getImage().get(3))) {
			byte[] image = Base64.getDecoder().decode(answerType.getImage().get(3)
					.substring(answerType.getImage().get(3).indexOf(',') + 1).getBytes(StandardCharsets.UTF_8));
			answerType.setFourthImage(new ByteArrayInputStream(image));
		}
		if (answerType.getImage().size() > 4 && !StringUtils.isEmpty(answerType.getImage().get(4))) {
			byte[] image = Base64.getDecoder().decode(answerType.getImage().get(4)
					.substring(answerType.getImage().get(4).indexOf(',') + 1).getBytes(StandardCharsets.UTF_8));
			answerType.setFifthImage(new ByteArrayInputStream(image));

		}
		return answerType;
	}

	/*
	 * Find All Checklist By HierarchyId
	 */
	@RequestMapping(value = "getChecklistByHierarchyId/{hierarchyId}", method = RequestMethod.GET)
	public List<CheckListTreeDTO> getChecklistByHierarchyId(@PathVariable("hierarchyId") Integer hierarchyId) {
		List<Checklist> checkListByproject = checkListRepository.getChecklistByHierarchy(hierarchyId);
		return getChecklistByProjectId(checkListByproject);
	}

	/*
	 * GetAll QuestionOption
	 */

	@RequestMapping(value = "getQuestionOptions", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public Map<String, List<String>> getQuestionAnsInfo() {
		return questionOptionService.getQuestionAnsInfo();

	}

	// Checking for Duplicate
	private void checkDuplicateCheckList(Checklist checklist) {
		Checklist duplicateChecklist = checkListRepository.checkDuplicateCheckList(checklist.getLocation(),
				checklist.getChecklistName(), checklist.getChecklistType(), checklist.getChecklistService(),
				checklist.getProjectId(), checklist.getVersion(), checklist.getHierarchyId());
		if (duplicateChecklist != null) {
			throw new AppException(MessagesEnum.DUPLICATECHECKLIST);
		}
	}

	// Get Checklist By search parameter
	@RequestMapping(value = "checklistSearch", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<CheckListTreeDTO> getChecklistsByLocation(@RequestParam("name") String name,
			@RequestParam("projectId") Integer projectId) {
		List<Checklist> checklist = checkListRepository.getChecklists(name, projectId);
		return getChecklistByProjectId(checklist);
	}

	// common method for checklist By projectId and By search
	private List<CheckListTreeDTO> getChecklistByProjectId(List<Checklist> checkListByproject) {
		if (checkListByproject.isEmpty()) {
			return new ArrayList<>();

		} else {
			Map<String, Map<String, List<Checklist>>> mainMap = new LinkedHashMap<>();
			for (Checklist checklist : checkListByproject) {
				Map<String, List<Checklist>> type = mainMap.get(checklist.getChecklistService());
				if (type == null) {
					type = new HashMap<>();
				}
				List<Checklist> name = type.get(checklist.getChecklistType());
				if (name == null) {
					name = new ArrayList<>();
				}

				name.add(checklist);
				type.put(checklist.getChecklistType(), name);
				mainMap.put(checklist.getChecklistService(), type);
			}

			// Setting map value to CheckListTemplateTreeDTO
			List<CheckListTreeDTO> checkListDTO = new ArrayList<>();

			for (Entry<String, Map<String, List<Checklist>>> serviceMap : mainMap.entrySet()) {
				CheckListTreeDTO serviceDTO = new CheckListTreeDTO();
				serviceDTO.setLabel(serviceMap.getKey());
				serviceDTO.setLeaf(false);
				serviceDTO.setHierarchyType("SERVICE");
				serviceDTO.setIcon("fa fa-folder");
				serviceDTO.setSelectable(false);
				serviceDTO.setExpanded(true);
				List<CheckListTreeDTO> typeDTOList = new ArrayList<>();
				for (Entry<String, List<Checklist>> typeMap : serviceMap.getValue().entrySet()) {
					CheckListTreeDTO typeDTO = new CheckListTreeDTO();
					typeDTO.setLabel(typeMap.getKey());
					typeDTO.setLeaf(false);
					typeDTO.setHierarchyType("TYPE");
					typeDTO.setIcon("fa fa-folder");
					typeDTO.setSelectable(false);
					typeDTO.setExpanded(true);
					typeDTO.setChildren(new ArrayList<>());

					for (Checklist temp : typeMap.getValue()) {
						CheckListTreeDTO locationDTO = new CheckListTreeDTO();
						// to do
						String location = null;
						if (temp.getStatus() != -1) {
							location = temp.getLocation().concat("-")
									.concat(temp.getChecklistName().concat("_").concat(temp.getVersion().toString()));
						} else {
							location = temp.getLocation().concat("-").concat(temp.getChecklistName());
						}
						locationDTO.setLabel(location);
						locationDTO.setData(temp);
						locationDTO.setHierarchyType("LOCATION");
						locationDTO.setIcon("fa fa-file");
						locationDTO.setLeaf(true);
						locationDTO.setSelectable(true);
						locationDTO.setExpanded(true);
						locationDTO.setChildren(new ArrayList<>());
						typeDTO.getChildren().add(locationDTO);

					}
					Checklist data = new Checklist();
					data.setChecklistService(serviceMap.getKey());
					data.setChecklistType(typeMap.getKey());
					typeDTO.setData(data);
					typeDTOList.add(typeDTO);
				}
				Checklist data = new Checklist();
				data.setChecklistService(serviceMap.getKey());
				serviceDTO.setData(data);
				serviceDTO.setChildren(typeDTOList);
				checkListDTO.add(serviceDTO);
			}
			return checkListDTO;
		}

	}

}
