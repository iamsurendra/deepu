package com.synergy.bqm.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.synergy.bqm.json.DesignationDTO;
import com.synergy.bqm.models.Designation;
import com.synergy.bqm.repositories.DesignationDAO;

@Service("designationService")
public class DesignationServiceImpl implements DesignationService {
	@Autowired
	DesignationDAO designationDAO;

	@Transactional
	public void createDesignation(Designation designation) {
		designationDAO.create(designation);

	}

	@Transactional
	public List<String> getDesignationNames() {

		return designationDAO.getDesignationNames();
	}

	@Transactional
	public List<Designation> findAllDesignations() {
		return designationDAO.findAll();

	}

	@Transactional
	public void updateDesignation(Designation designation) {

		designationDAO.update(designation);

	}

	@Transactional
	public void deleteDesignationById(Designation designation) {
		Designation deleteDesignation = designationDAO.findOne(designation.getDesignationId());
		designationDAO.delete(deleteDesignation);

	}

	@Transactional
	public void createAndUpdateDesignation(DesignationDTO designationDTO) {

		// create or update department
		if (!designationDTO.getDesignationList().isEmpty()) {
			for (Designation designation : designationDTO.getDesignationList()) {
				if (designation.getDesignationId() == null) {
					designationDAO.create(designation);
				} else {
					designationDAO.update(designation);
				}
			}
		}
		// delete departments
		/*
		 * if (!designationDTO.getDeletedIds().isEmpty()) { List<User>
		 * usersObjList = userDAO
		 * .getUserInfoByDesignationIdInOperator(designationDTO.getDeletedIds())
		 * ; // projcetMember deleted Department value set null for (User
		 * allMembers : usersObjList) { allMembers.setUserDesignation(null); }
		 */
		if (!designationDTO.getDeletedIds().isEmpty() && designationDTO.getDeletedIds() != null) {
			designationDAO.deleteDesignationIds(designationDTO.getDeletedIds());
		}
	}

}
