package com.synergy.bqm.models;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.PostLoad;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.guvvala.framework.util.DateUtils;

@Entity
@Table(name = "activity_history")
public class ActivityHistory implements Serializable{
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue
	@Column(name = "id")
	private Integer id;
	
	//@Column(name = "index_id")
	//private Integer indexId;
	
	@Column(name = "workflow_name")
	private String workflowName;
	
	@Column(name = "state_name")
	private String stateName;
	
	@Column(name = "document_name")
	private String documentName;
	
	@Column(name = "updated_by")
	private String updatedBy;
	
	@Column(name = "updated_dt")
	@Temporal(TemporalType.TIMESTAMP)
	private Date updatedDate;
	
	
	@ManyToOne
	@JoinColumn(name = "index_id")
	@JsonIgnore
	private DocumentIndex documentIndex;
	
	
	@Transient
	public String dateString;

	//getters and setters
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}
	public String getWorkflowName() {
		return workflowName;
	}

	public void setWorkflowName(String workflowName) {
		this.workflowName = workflowName;
	}

	public String getStateName() {
		return stateName;
	}

	public void setStateName(String stateName) {
		this.stateName = stateName;
	}

	public String getDocumentName() {
		return documentName;
	}

	public void setDocumentName(String documentName) {
		this.documentName = documentName;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Date getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}

	public DocumentIndex getDocumentIndex() {
		return documentIndex;
	}

	public void setDocumentIndex(DocumentIndex documentIndex) {
		this.documentIndex = documentIndex;
	}

	public String getDateString() {
		return dateString;
	}

	public void setDateString(String dateString) {
		this.dateString = dateString;
	}
	
	@PostLoad
	void postload() {
		setDateString((DateUtils.convertToSimpleDateTimeFormat(getUpdatedDate())));
	}
	
}


