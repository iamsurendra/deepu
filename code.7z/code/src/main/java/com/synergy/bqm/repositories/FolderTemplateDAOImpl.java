package com.synergy.bqm.repositories;

import java.util.List;

import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;

import com.guvvala.framework.dao.BaseDAOImpl;
import com.synergy.bqm.models.FolderTemplate;

@Repository
public class FolderTemplateDAOImpl extends BaseDAOImpl<FolderTemplate, Integer> implements FolderTemplateDAO {

	public FolderTemplateDAOImpl() {
		super(FolderTemplate.class);
		// TODO Auto-generated constructor stub
	}

	public List<FolderTemplate> getFolderNameByTemplateId(Integer templateId) {
		TypedQuery<FolderTemplate> query = entityManager
				.createQuery("SELECT f from FolderTemplate f where templateId ='" + templateId
						+ "' and parent_folder_id is null and folderId is not null ", FolderTemplate.class);

		return query.getResultList();
	}

	public List<FolderTemplate> getFolderInfoByTemplateIdandFolderName(Integer templateId, String folderName) {
		TypedQuery<FolderTemplate> query = entityManager
				.createQuery("SELECT f from FolderTemplate f where templateId ='" + templateId + "'and folderName ='"
						+ folderName + "' and parent_folder_id is null ", FolderTemplate.class);

		return query.getResultList();
	}

	public List<FolderTemplate> getChildFolderNameByTemplateId(Integer templateId, Integer folderId) {
		TypedQuery<FolderTemplate> query = entityManager
				.createQuery("SELECT f from FolderTemplate f where templateId ='" + templateId
						+ "' and parent_folder_id ='" + folderId + "' ", FolderTemplate.class);

		return query.getResultList();
	}
	
	public Long checkFolderNameExists(Integer templateId, String folderName) {
		TypedQuery<Long> query = entityManager.createQuery("SELECT count(*) from FolderTemplate  where templateId ='"
				+ templateId + "'and folderName ='" + folderName + "' and parent_folder_id is null ", Long.class);
		return query.getSingleResult();
	}

	public Long checkChildFolderNameExits( Integer parentFolderId, String folderName) {
		TypedQuery<Long> query = entityManager.createQuery(
				"SELECT count(*) from FolderTemplate  where parent_folder_id ='"
						+ parentFolderId + "' and folderName = '" + folderName + "' ",
				Long.class);

		return query.getSingleResult();
	}

	public List<FolderTemplate> getFolderInfoByParentId(Integer folderId) {
		TypedQuery<FolderTemplate> query = entityManager.createQuery(
				"SELECT f from FolderTemplate f where parent_folder_id ='" + folderId + "'", FolderTemplate.class);

		return query.getResultList();
	}

	public List<Integer> getFoldersInfoByFolderIds(List<Integer> folderIds) {
		TypedQuery<Integer> query = entityManager.createQuery(
				"SELECT f.folderId from FolderTemplate f where parent_folder_id IN :folderIds", Integer.class);
		query.setParameter("folderIds", folderIds);
		return query.getResultList();
	}

	public void delete(Integer folderId) {
		Query query = entityManager.createQuery("delete from FolderTemplate f where folderId = :folderId");
		query.setParameter("folderId", folderId);
		query.executeUpdate();
	}

	public List<FolderTemplate> getFolderInfoByFolderIdAndTemplateId(Integer templateId, Integer folderId) {
		CriteriaBuilder criteriaBuilder = entityManager.getCriteriaBuilder();
		CriteriaQuery<FolderTemplate> criteriaQuery = criteriaBuilder.createQuery(FolderTemplate.class);
		Root<FolderTemplate> root = criteriaQuery.from(FolderTemplate.class);
		criteriaQuery.select(root);
		criteriaQuery.where(criteriaBuilder.equal(root.get("folderId"), folderId));
		return entityManager.createQuery(criteriaQuery).getResultList();
	}

	public List<FolderTemplate> getFolderTemplateByTemplateId(Integer templateId) {
		CriteriaBuilder builder = entityManager.getCriteriaBuilder();
		CriteriaQuery<FolderTemplate> criteriaQuery = builder.createQuery(FolderTemplate.class);
		Root<FolderTemplate> root = criteriaQuery.from(FolderTemplate.class);
		criteriaQuery.select(root).where(builder.equal(root.get("templateId"), templateId));
		return entityManager.createQuery(criteriaQuery).getResultList();
	}

	public Integer getMaxTemplateId() {
		CriteriaBuilder builder = entityManager.getCriteriaBuilder();
		CriteriaQuery<Integer> criteriaQuery = builder.createQuery(Integer.class);
		Root<FolderTemplate> root = criteriaQuery.from(FolderTemplate.class);
		criteriaQuery.select(builder.max(root.get("templateId")));
		return entityManager.createQuery(criteriaQuery).getSingleResult();
	}

	public Integer getMaxFolderId() {
		CriteriaBuilder builder = entityManager.getCriteriaBuilder();
		CriteriaQuery<Integer> criteriaQuery = builder.createQuery(Integer.class);
		Root<FolderTemplate> root = criteriaQuery.from(FolderTemplate.class);
		criteriaQuery.select(builder.max(root.get("folderId")));
		return entityManager.createQuery(criteriaQuery).getSingleResult();
	}

	public List<String> findByTemplateName(String templateName) {
		CriteriaBuilder builder = entityManager.getCriteriaBuilder();
		CriteriaQuery<String> criteriaQuery = builder.createQuery(String.class);
		Root<FolderTemplate> root = criteriaQuery.from(FolderTemplate.class);
		criteriaQuery.select(root.get("templateName")).where(builder.equal(root.get("templateName"), templateName));
		return entityManager.createQuery(criteriaQuery).getResultList();
	}



	public FolderTemplate getFolderInfoByFolderId(Integer folderId) {
		CriteriaBuilder builder = entityManager.getCriteriaBuilder();
		CriteriaQuery<FolderTemplate> criteriaQuery = builder.createQuery(FolderTemplate.class);
		Root<FolderTemplate> root = criteriaQuery.from(FolderTemplate.class);
		criteriaQuery.select(root).where(builder.equal(root.get("folderId"), folderId));
		return entityManager.createQuery(criteriaQuery).getSingleResult();
	}

	public List<FolderTemplate> getFolderInfoListByFolderId(Integer folderId) {
		CriteriaBuilder builder = entityManager.getCriteriaBuilder();
		CriteriaQuery<FolderTemplate> criteriaQuery = builder.createQuery(FolderTemplate.class);
		Root<FolderTemplate> root = criteriaQuery.from(FolderTemplate.class);
		criteriaQuery.select(root).where(builder.equal(root.get("folderId"), folderId));

		return entityManager.createQuery(criteriaQuery).getResultList();

	}

	public void deleteFolderTemplate(Integer templateId) {

	}

	public List<FolderTemplate> getFirstLevelFolderInfoByTemplateId(Integer templateId) {
		TypedQuery<FolderTemplate> query = entityManager.createQuery(
				"SELECT f from FolderTemplate f where templateId ='" + templateId + "' and parent_folder_id is null ",
				FolderTemplate.class);

		return query.getResultList();
	}

	public FolderTemplate getFolderInfoByTemplateIdAndFolderId(Integer templateId,Integer folderId){
		TypedQuery<FolderTemplate> query = entityManager.createQuery(
				"SELECT f from FolderTemplate f where templateId ='" + templateId + "' and folderId ='"+folderId+ "'",
				FolderTemplate.class);

		return query.getSingleResult();
	}	
	
	public List<String> getFoldeNamesByParentIds(Integer parentFolderId) {
		CriteriaBuilder builder = entityManager.getCriteriaBuilder();
		CriteriaQuery<String> criteriaQuery = builder.createQuery(String.class);
		Root<FolderTemplate> root = criteriaQuery.from(FolderTemplate.class);
		criteriaQuery.select(root.get("folderName"))
				.where(builder.equal(root.get("folderTemplate").get("folderId"), parentFolderId));
		return entityManager.createQuery(criteriaQuery).getResultList();
	}


	/*
	 * public List<FolderTemplate> getFoldersInfoByFolderIds(List<Integer>
	 * folderIds){ CriteriaBuilder builder = entityManager.getCriteriaBuilder();
	 * CriteriaQuery<FolderTemplate> criteriaQuery =
	 * builder.createQuery(FolderTemplate.class); Root<FolderTemplate> root =
	 * criteriaQuery.from(FolderTemplate.class); criteriaQuery.select(root);
	 * criteriaQuery.where(root.get("folderId").in(folderIds)); return
	 * entityManager.createQuery(criteriaQuery).getResultList(); }
	 */

}
