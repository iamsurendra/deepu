package com.synergy.bqm.services;

import java.io.File;
import java.io.IOException;
import java.io.StringWriter;
import java.text.MessageFormat;
import java.util.Date;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamSource;
import org.springframework.http.MediaType;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

import com.guvvala.framework.errorHandler.AppException;
import com.guvvala.framework.logging.AppLogger;
import com.guvvala.framework.logging.Log;
import com.guvvala.framework.util.AppBundle;
import com.guvvala.framework.util.ThreadLocalUtil;
import com.synergy.bqm.constants.MailTemplateEnum;
import com.synergy.bqm.constants.MessagesEnum;

import freemarker.template.Configuration;
import freemarker.template.Template;
import freemarker.template.TemplateException;
import freemarker.template.TemplateExceptionHandler;

@Service("mailService")
public class MailServiceImpl implements MailService {

	protected static final String MIME_TYPE_PDF = "application/octet-stream";

	@Autowired
	private JavaMailSenderImpl mailSender;

	private Configuration cfg;

	private static @Log AppLogger logger;

	@PostConstruct
	public void init() {
		try {
			logger.debug("Setting up the mail Service");
			cfg = new Configuration(Configuration.VERSION_2_3_23);
			String path = Thread.currentThread().getContextClassLoader().getResource("/mailTemplate").getPath();
			cfg.setDirectoryForTemplateLoading(new File(path));
			cfg.setDefaultEncoding("UTF-8");
			cfg.setTemplateExceptionHandler(TemplateExceptionHandler.RETHROW_HANDLER);
			cfg.setLogTemplateExceptions(false);
			logger.debug("mail service set up successful");
		} catch (IOException ioe) {
			logger.error(ioe);
			throw new AppException(ioe);
		}
	}

	public void sendEmail(MailTemplateEnum mailTemplate, Map<String, Object> values, String[] to, Object... subject) {
		try {
			final String userName = mailSender.getSession().getProperty("username");
			final MimeMessage msg = mailSender.createMimeMessage();
			msg.setFrom(new InternetAddress(userName));
			InternetAddress recipients[] = buildRecipients(to);
			msg.setRecipients(Message.RecipientType.TO, recipients);
			msg.setSubject(getSubject(mailTemplate, subject));
			msg.setSentDate(new Date());
			msg.setContent(getContent(mailTemplate, values), MediaType.TEXT_HTML.toString());
			mailSender.send(msg);
		} catch (IOException ioe) {
			logger.error(ioe);
			throw new AppException(MessagesEnum.EMAILSEND_FAILD, ioe);
		} catch (TemplateException te) {
			logger.error(te);
			throw new AppException(MessagesEnum.EMAILSEND_FAILD, te);
		} catch (MessagingException me) {
			logger.error(me);
			throw new AppException(MessagesEnum.EMAILSEND_FAILD, me);
		}
	}

	public void sendEmailWithAttachments(MailTemplateEnum mailTemplate, Map<String, Object> values, String[] to,
			String[] cc, String userSpecSubject, Map<String, InputStreamSource> attachMents, Object... params) {
		try {
			final String userName = mailSender.getSession().getProperty("username");
			final MimeMessage msg = mailSender.createMimeMessage();
			//AppUser appUser = ThreadLocalUtil.getAppUser();
			final MimeMessageHelper msgHelper = new MimeMessageHelper(msg, true);
			InternetAddress recipients[] = buildRecipients(to);
			msgHelper.setTo(recipients);
			if (!cc[0].isEmpty()) {
				msgHelper.setCc(cc);
			}
			msgHelper.setFrom(new InternetAddress(userName));
			msg.setSubject(userSpecSubject != null ? getUserSpecSubject(userSpecSubject, params)
					: getSubject(mailTemplate, params));
			msgHelper.setText(getContent(mailTemplate, values), true);
			msgHelper.setSentDate(new Date());
			for (Map.Entry<String, InputStreamSource> source : attachMents.entrySet()) {
				msgHelper.addAttachment(source.getKey(), source.getValue(), MIME_TYPE_PDF);
			}
			mailSender.send(msg);
		} catch (IOException ioe) {
			logger.error(ioe);
			throw new AppException(MessagesEnum.EMAILSEND_FAILD, ioe);
		} catch (TemplateException te) {
			logger.error(te);
			throw new AppException(MessagesEnum.EMAILSEND_FAILD, te);
		} catch (MessagingException me) {
			logger.error(me);
			throw new AppException(MessagesEnum.EMAILSEND_FAILD, me);
		}
	}

	public void sendEmailWithAttachmentsOfDifferentContentTypes(MailTemplateEnum mailTemplate,
			Map<String, Object> values, String[] to, String[] cc, String userSpecSubject,
			Map<String, InputStreamSource> attachMents, Object... params) {
		try {
			final String userName = mailSender.getSession().getProperty("username");
			final MimeMessage msg = mailSender.createMimeMessage();
			// AppUser appUser = ThreadLocalUtil.getAppUser();
			final MimeMessageHelper msgHelper = new MimeMessageHelper(msg, true);
			InternetAddress recipients[] = buildRecipients(to);
			msgHelper.setTo(recipients);
			// msgHelper.setFrom(appUser.getUserObject().getUserEmail());
			if (!cc[0].isEmpty()) {
				msgHelper.setCc(cc);
			}
			msgHelper.setFrom(new InternetAddress(userName));
			msg.setSubject(userSpecSubject != null ? getUserSpecSubject(userSpecSubject, params)
					: getSubject(mailTemplate, params));
			msgHelper.setText(getContent(mailTemplate, values), true);
			msgHelper.setSentDate(new Date());
			for (Map.Entry<String, InputStreamSource> source : attachMents.entrySet()) {
				String[] fileName = source.getKey().split("\\?");
				msgHelper.addAttachment(fileName[0], source.getValue(), fileName[1]);
			}
			mailSender.send(msg);
		} catch (IOException ioe) {
			logger.error(ioe);
			throw new AppException(MessagesEnum.EMAILSEND_FAILD, ioe);
		} catch (TemplateException te) {
			logger.error(te);
			throw new AppException(MessagesEnum.EMAILSEND_FAILD, te);
		} catch (MessagingException me) {
			logger.error(me);
			throw new AppException(MessagesEnum.EMAILSEND_FAILD, me);
		}
	}

	private String getSubject(MailTemplateEnum mailTemplate, Object... subject) {
		return AppBundle.getString(mailTemplate, subject);
	}

	private String getUserSpecSubject(String userSpecSubject, Object... params) {
		String subject = "";
		if (userSpecSubject != null) {
			subject = userSpecSubject;
			if (params != null) {
				subject = MessageFormat.format(subject, params);
			}
		}
		return subject;
	}

	private String getContent(MailTemplateEnum mailTemplate, Map<String, Object> values)
			throws IOException, TemplateException {
		StringBuilder tname = new StringBuilder();
		tname.append(mailTemplate.filename);
		tname.append("_");
		if (ThreadLocalUtil.getLocale() == null) {
			tname.append("en");
		} else {
			tname.append(ThreadLocalUtil.getLocale());
		}
		tname.append(".html");
		Template temp = cfg.getTemplate(tname.toString());
		StringWriter outputWriter = new StringWriter();
		temp.process(values, outputWriter);
		return outputWriter.toString();
	}

	private InternetAddress[] buildRecipients(String[] to) throws AddressException {
		InternetAddress recipients[] = new InternetAddress[to.length];
		int i = 0;
		for (String rec : to) {
			recipients[i++] = new InternetAddress(rec);
		}
		return recipients;
	}

}
